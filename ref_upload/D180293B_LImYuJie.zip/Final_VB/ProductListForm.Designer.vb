﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductListForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ProductListForm))
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.ConfirmButton = New System.Windows.Forms.Button()
        Me.UsernameLabel = New System.Windows.Forms.Label()
        Me.TitleLabel = New System.Windows.Forms.Label()
        Me.Item1Button = New System.Windows.Forms.Button()
        Me.Item2Button = New System.Windows.Forms.Button()
        Me.Item3Button = New System.Windows.Forms.Button()
        Me.TextLabel = New System.Windows.Forms.Label()
        Me.PointLabel = New System.Windows.Forms.Label()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.Image = CType(resources.GetObject("LogoPictureBox.Image"), System.Drawing.Image)
        Me.LogoPictureBox.Location = New System.Drawing.Point(31, 37)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(161, 90)
        Me.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.LogoPictureBox.TabIndex = 16
        Me.LogoPictureBox.TabStop = False
        '
        'ConfirmButton
        '
        Me.ConfirmButton.Enabled = False
        Me.ConfirmButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.ConfirmButton.Location = New System.Drawing.Point(587, 352)
        Me.ConfirmButton.Name = "ConfirmButton"
        Me.ConfirmButton.Size = New System.Drawing.Size(138, 38)
        Me.ConfirmButton.TabIndex = 7
        Me.ConfirmButton.Text = "&Confirm"
        Me.ConfirmButton.UseVisualStyleBackColor = True
        '
        'UsernameLabel
        '
        Me.UsernameLabel.AutoSize = True
        Me.UsernameLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.UsernameLabel.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.UsernameLabel.Location = New System.Drawing.Point(432, 118)
        Me.UsernameLabel.Name = "UsernameLabel"
        Me.UsernameLabel.Size = New System.Drawing.Size(55, 29)
        Me.UsernameLabel.TabIndex = 1
        Me.UsernameLabel.Text = "nan"
        '
        'TitleLabel
        '
        Me.TitleLabel.AutoSize = True
        Me.TitleLabel.Font = New System.Drawing.Font("Vladimir Script", 25.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TitleLabel.Location = New System.Drawing.Point(210, 55)
        Me.TitleLabel.Name = "TitleLabel"
        Me.TitleLabel.Size = New System.Drawing.Size(515, 51)
        Me.TitleLabel.TabIndex = 0
        Me.TitleLabel.Text = "Dryper Point Redemtion System"
        '
        'Item1Button
        '
        Me.Item1Button.Image = CType(resources.GetObject("Item1Button.Image"), System.Drawing.Image)
        Me.Item1Button.Location = New System.Drawing.Point(74, 168)
        Me.Item1Button.Name = "Item1Button"
        Me.Item1Button.Size = New System.Drawing.Size(175, 142)
        Me.Item1Button.TabIndex = 2
        Me.Item1Button.UseVisualStyleBackColor = True
        '
        'Item2Button
        '
        Me.Item2Button.Image = CType(resources.GetObject("Item2Button.Image"), System.Drawing.Image)
        Me.Item2Button.Location = New System.Drawing.Point(312, 168)
        Me.Item2Button.Name = "Item2Button"
        Me.Item2Button.Size = New System.Drawing.Size(175, 142)
        Me.Item2Button.TabIndex = 3
        Me.Item2Button.UseVisualStyleBackColor = True
        '
        'Item3Button
        '
        Me.Item3Button.Image = CType(resources.GetObject("Item3Button.Image"), System.Drawing.Image)
        Me.Item3Button.Location = New System.Drawing.Point(550, 168)
        Me.Item3Button.Name = "Item3Button"
        Me.Item3Button.Size = New System.Drawing.Size(175, 142)
        Me.Item3Button.TabIndex = 4
        Me.Item3Button.UseVisualStyleBackColor = True
        '
        'TextLabel
        '
        Me.TextLabel.AutoSize = True
        Me.TextLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.TextLabel.Location = New System.Drawing.Point(71, 366)
        Me.TextLabel.Name = "TextLabel"
        Me.TextLabel.Size = New System.Drawing.Size(94, 20)
        Me.TextLabel.TabIndex = 5
        Me.TextLabel.Text = "Total Point:"
        '
        'PointLabel
        '
        Me.PointLabel.AutoSize = True
        Me.PointLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.PointLabel.Location = New System.Drawing.Point(166, 366)
        Me.PointLabel.Name = "PointLabel"
        Me.PointLabel.Size = New System.Drawing.Size(36, 20)
        Me.PointLabel.TabIndex = 6
        Me.PointLabel.Text = "nan"
        '
        'ProductListForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.PointLabel)
        Me.Controls.Add(Me.TextLabel)
        Me.Controls.Add(Me.Item3Button)
        Me.Controls.Add(Me.Item2Button)
        Me.Controls.Add(Me.Item1Button)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.ConfirmButton)
        Me.Controls.Add(Me.UsernameLabel)
        Me.Controls.Add(Me.TitleLabel)
        Me.Name = "ProductListForm"
        Me.Text = "Product List Menu"
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LogoPictureBox As PictureBox
    Friend WithEvents ConfirmButton As Button
    Friend WithEvents UsernameLabel As Label
    Friend WithEvents TitleLabel As Label
    Friend WithEvents Item1Button As Button
    Friend WithEvents Item2Button As Button
    Friend WithEvents Item3Button As Button
    Friend WithEvents TextLabel As Label
    Friend WithEvents PointLabel As Label
End Class
