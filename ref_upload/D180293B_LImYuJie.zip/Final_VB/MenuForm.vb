﻿Public Class MenuForm
    Private Sub RegisterCodeButton_Click(sender As Object, e As EventArgs) Handles RegisterCodeButton.Click
        RegisterCodeForm.UsernameLabel.Text = UsernameLabel.Text
        RegisterCodeForm.Show()
        Me.Close()
    End Sub



    Private Sub ViewProductButton_Click(sender As Object, e As EventArgs) Handles ViewProductButton.Click
        ProductListForm.UsernameLabel.Text = UsernameLabel.Text
        ProductListForm.PointLabel.Text = LoginForm.detail.point
        ProductListForm.Show()
        Me.Close()
    End Sub
End Class