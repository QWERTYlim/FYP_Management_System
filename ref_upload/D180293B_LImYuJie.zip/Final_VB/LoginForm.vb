﻿Public Class LoginForm
    Public userdata(1, 2)
    Private Sub ForgotLabel_Click(sender As Object, e As EventArgs) Handles ForgotLabel.Click
        ForgotPasswordForm.Show()
        Me.Close()
    End Sub

    Private Sub ResetButton_Click(sender As Object, e As EventArgs) Handles ResetButton.Click
        UsernameTextBox.Clear()
        PasswordTextBox.Clear()
    End Sub

    Private Sub LoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim filename As String = "..\..\users\mary123.txt"
        Dim objreader As IO.StreamReader
        Dim row As Integer = 0
        objreader = IO.File.OpenText(filename)

        userdata(row, 0) = objreader.ReadLine
        userdata(row, 1) = objreader.ReadLine
        userdata(row, 2) = objreader.ReadLine

        objreader.Close()
        row += 1
        filename = "..\..\users\ali123.txt"
        Dim objreader2 As IO.StreamReader
        objreader2 = IO.File.OpenText(filename)

        userdata(row, 0) = objreader2.ReadLine
        userdata(row, 1) = objreader2.ReadLine
        userdata(row, 2) = objreader2.ReadLine

        objreader2.Close()

    End Sub

    Public Structure Member
        Public username As String
        Public password As String
        Public name As String
        Public point As String
    End Structure

    Public detail As Member

    Private Sub LoginButton_Click(sender As Object, e As EventArgs) Handles LoginButton.Click

        If UsernameTextBox.Text = "mary123" And PasswordTextBox.Text = userdata(0, 1) Then
            detail.username = "mary123"
            detail.name = userdata(0, 0)
            detail.password = userdata(0, 1)
            detail.point = userdata(0, 2)
            MessageBox.Show("Login Sucessful!!")
            MenuForm.UsernameLabel.Text = detail.name + "(" + detail.username + ")"
            MenuForm.Show()
            Me.Hide()
        ElseIf UsernameTextBox.Text = "ali123" And PasswordTextBox.Text = userdata(1, 1) Then
            detail.username = "ali123"
            detail.name = userdata(1, 0)
            detail.password = userdata(1, 1)
            detail.point = userdata(1, 2)
            MessageBox.Show("Login Sucessful!!")
            MenuForm.UsernameLabel.Text = detail.name + "(" + detail.username + ")"
            MenuForm.Show()
            Me.Hide()
        Else
            MessageBox.Show("Error")
            UsernameTextBox.Text = String.Empty
            PasswordTextBox.Text = String.Empty
        End If

    End Sub
End Class
