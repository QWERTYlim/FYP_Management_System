﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductDetaiForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.NameTitleLabel = New System.Windows.Forms.Label()
        Me.DescriptionTitleLabel = New System.Windows.Forms.Label()
        Me.NameLabel = New System.Windows.Forms.Label()
        Me.DescriptionLabel = New System.Windows.Forms.Label()
        Me.PointTitleLabel = New System.Windows.Forms.Label()
        Me.PointLabel = New System.Windows.Forms.Label()
        Me.QuantityTextBox = New System.Windows.Forms.TextBox()
        Me.AddButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'NameTitleLabel
        '
        Me.NameTitleLabel.AutoSize = True
        Me.NameTitleLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.NameTitleLabel.Location = New System.Drawing.Point(0, 28)
        Me.NameTitleLabel.Name = "NameTitleLabel"
        Me.NameTitleLabel.Size = New System.Drawing.Size(142, 25)
        Me.NameTitleLabel.TabIndex = 0
        Me.NameTitleLabel.Text = "Product Name:"
        '
        'DescriptionTitleLabel
        '
        Me.DescriptionTitleLabel.AutoSize = True
        Me.DescriptionTitleLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.DescriptionTitleLabel.Location = New System.Drawing.Point(0, 72)
        Me.DescriptionTitleLabel.Name = "DescriptionTitleLabel"
        Me.DescriptionTitleLabel.Size = New System.Drawing.Size(187, 25)
        Me.DescriptionTitleLabel.TabIndex = 2
        Me.DescriptionTitleLabel.Text = "Product Description:"
        '
        'NameLabel
        '
        Me.NameLabel.AutoSize = True
        Me.NameLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.NameLabel.Location = New System.Drawing.Point(235, 28)
        Me.NameLabel.Name = "NameLabel"
        Me.NameLabel.Size = New System.Drawing.Size(45, 25)
        Me.NameLabel.TabIndex = 1
        Me.NameLabel.Text = "nan"
        '
        'DescriptionLabel
        '
        Me.DescriptionLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.DescriptionLabel.Location = New System.Drawing.Point(235, 72)
        Me.DescriptionLabel.Name = "DescriptionLabel"
        Me.DescriptionLabel.Size = New System.Drawing.Size(553, 266)
        Me.DescriptionLabel.TabIndex = 3
        Me.DescriptionLabel.Text = "nan"
        '
        'PointTitleLabel
        '
        Me.PointTitleLabel.AutoSize = True
        Me.PointTitleLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.PointTitleLabel.Location = New System.Drawing.Point(0, 338)
        Me.PointTitleLabel.Name = "PointTitleLabel"
        Me.PointTitleLabel.Size = New System.Drawing.Size(134, 25)
        Me.PointTitleLabel.TabIndex = 4
        Me.PointTitleLabel.Text = "Product Point:"
        '
        'PointLabel
        '
        Me.PointLabel.AutoSize = True
        Me.PointLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.PointLabel.Location = New System.Drawing.Point(235, 338)
        Me.PointLabel.Name = "PointLabel"
        Me.PointLabel.Size = New System.Drawing.Size(45, 25)
        Me.PointLabel.TabIndex = 5
        Me.PointLabel.Text = "nan"
        '
        'QuantityTextBox
        '
        Me.QuantityTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.QuantityTextBox.Location = New System.Drawing.Point(12, 392)
        Me.QuantityTextBox.Multiline = True
        Me.QuantityTextBox.Name = "QuantityTextBox"
        Me.QuantityTextBox.Size = New System.Drawing.Size(175, 33)
        Me.QuantityTextBox.TabIndex = 6
        '
        'AddButton
        '
        Me.AddButton.Location = New System.Drawing.Point(219, 392)
        Me.AddButton.Name = "AddButton"
        Me.AddButton.Size = New System.Drawing.Size(124, 33)
        Me.AddButton.TabIndex = 7
        Me.AddButton.Text = "Add to Cart"
        Me.AddButton.UseVisualStyleBackColor = True
        '
        'ProductDetaiForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.AddButton)
        Me.Controls.Add(Me.QuantityTextBox)
        Me.Controls.Add(Me.PointLabel)
        Me.Controls.Add(Me.PointTitleLabel)
        Me.Controls.Add(Me.DescriptionLabel)
        Me.Controls.Add(Me.NameLabel)
        Me.Controls.Add(Me.DescriptionTitleLabel)
        Me.Controls.Add(Me.NameTitleLabel)
        Me.Name = "ProductDetaiForm"
        Me.Text = "Product Detail Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents NameTitleLabel As Label
    Friend WithEvents DescriptionTitleLabel As Label
    Friend WithEvents NameLabel As Label
    Friend WithEvents DescriptionLabel As Label
    Friend WithEvents PointTitleLabel As Label
    Friend WithEvents PointLabel As Label
    Friend WithEvents QuantityTextBox As TextBox
    Friend WithEvents AddButton As Button
End Class
