﻿Public Class ProductDetaiForm
    Public index As Integer
    Dim detail As product

    Public Structure product
        Dim name As String
        Dim description As String
        Dim point As Double
        Dim imagename As String
    End Structure

    Private Sub ProductDetaiForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim details(2, 3)
        Dim objreader As IO.StreamReader
        Dim filename As String = "..\..\productdetail\product.txt"

        objreader = IO.File.OpenText(filename)

        For i = 0 To 2
            details(i, 0) = objreader.ReadLine
            details(i, 1) = objreader.ReadLine
            details(i, 2) = objreader.ReadLine
            details(i, 3) = objreader.ReadLine
        Next
        objreader.Close()
        detail.name = details(index, 0)
        detail.description = details(index, 1)
        detail.point = details(index, 2)
        detail.imagename = details(index, 3)
        NameLabel.Text = detail.name
        DescriptionLabel.Text = detail.description
        PointLabel.Text = detail.point
    End Sub



    Private Sub AddButton_Click(sender As Object, e As EventArgs) Handles AddButton.Click

        If Char.IsDigit(QuantityTextBox.Text) Then
            Dim pointperitem As Integer = PointLabel.Text
            Dim pointneeded As Integer = pointperitem * QuantityTextBox.Text

            If LoginForm.detail.point < pointneeded Then
                MessageBox.Show("You just left " + LoginForm.detail.point + " point")
                QuantityTextBox.Text = String.Empty
            Else
                LoginForm.detail.point -= pointneeded
                ProductListForm.ConfirmButton.Enabled = True
                ProductListForm.PointLabel.Text = LoginForm.detail.point
                ProductListForm.Show()
                Me.Close()
            End If
        Else
            MessageBox.Show("Error!Number Only!")
            QuantityTextBox.Text = String.Empty
        End If


    End Sub
End Class