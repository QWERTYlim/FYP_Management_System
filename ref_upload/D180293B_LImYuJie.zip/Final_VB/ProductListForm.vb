﻿Public Class ProductListForm
    Private Sub Item1Button_Click(sender As Object, e As EventArgs) Handles Item1Button.Click
        ProductDetaiForm.index = 0
        ProductDetaiForm.Show()
        Me.Close()
    End Sub

    Private Sub Item2Button_Click(sender As Object, e As EventArgs) Handles Item2Button.Click
        ProductDetaiForm.index = 1
        ProductDetaiForm.Show()
        Me.Close()
    End Sub

    Private Sub Item3Button_Click(sender As Object, e As EventArgs) Handles Item3Button.Click
        ProductDetaiForm.index = 2
        ProductDetaiForm.Show()
        Me.Close()
    End Sub

    Private Sub RegisterCodeButton_Click(sender As Object, e As EventArgs) Handles ConfirmButton.Click
        Dim filename As String = "..\..\users\" + LoginForm.detail.username + ".txt"
        Dim objWritter As New System.IO.StreamWriter(filename)
        objWritter.WriteLine(LoginForm.detail.name)
        objWritter.WriteLine(LoginForm.detail.password)
        objWritter.WriteLine(LoginForm.detail.point)
        objWritter.Close()
        MessageBox.Show(LoginForm.detail.name & vbNewLine & LoginForm.detail.password & vbNewLine & LoginForm.detail.point)
    End Sub
End Class