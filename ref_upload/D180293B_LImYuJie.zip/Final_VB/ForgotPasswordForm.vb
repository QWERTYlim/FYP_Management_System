﻿Public Class ForgotPasswordForm
    Private Sub ResetButton_Click(sender As Object, e As EventArgs) Handles ResetButton.Click
        If UsernameTextBox.Text = "ali123" Then
            MessageBox.Show("123")
            LoginForm.Show()
            Me.Close()
        ElseIf UsernameTextBox.Text = "mary123" Then
            MessageBox.Show("123")
            LoginForm.Show()
            Me.Close()
        ElseIf UsernameTextBox.Text = String.Empty Then
            MessageBox.Show("Enter Something")
        Else
            MessageBox.Show("Error!")
            UsernameTextBox.Text = String.Empty
        End If
    End Sub
End Class