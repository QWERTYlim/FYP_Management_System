﻿Public Class RegisterCodeForm
    Public detail As LoginForm.Member = LoginForm.detail
    Private Sub SubmitButton_Click(sender As Object, e As EventArgs) Handles SubmitButton.Click
        Dim strcode As String = CodeTextBox.Text.ToUpper
        If strcode.Length = 10 Then
            Dim code() As Char = strcode.ToCharArray()
            If code(9) <> "A" And code(9) <> "E" And code(9) <> "I" And code(9) <> "O" And code(9) <> "U" Then
                MessageBox.Show("Last Word Must Be Vowel Letters")
                CodeTextBox.Text = String.Empty
            Else
                If Not Char.IsLetter(code(0)) Then
                    MessageBox.Show("First Word Must Be Alphabet")
                    CodeTextBox.Text = String.Empty
                Else
                    Dim totaladdedpoint As Integer = 0
                    Dim divide As Integer = 100
                    For i As Integer = 0 To code.Length - 1
                        If Char.IsDigit(code(i)) Then
                            totaladdedpoint += (Integer.Parse(code(i)) * divide)
                            divide /= 10
                        End If
                    Next
                    detail.point += totaladdedpoint
                    Dim filename As String = "..\..\users\" + detail.username + ".txt"
                    Dim objWritter As New System.IO.StreamWriter(filename)
                    objWritter.WriteLine(detail.name)
                    objWritter.WriteLine(detail.password)
                    objWritter.WriteLine(detail.point)
                    objWritter.Close()
                    MessageBox.Show(detail.name & vbNewLine & detail.password & vbNewLine & detail.point)
                End If
            End If
        Else
            MessageBox.Show("Error")
            CodeTextBox.Text = String.Empty
        End If



    End Sub
End Class