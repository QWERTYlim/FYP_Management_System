/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Chp12;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        Fruit f = new Orange();
//        System.out.println(f.howToEat());
//        Apple a = new Apple();
//        System.out.println(a.howToEat());
       
    Object[] objects = {new Tiger(), new Chicken(), new Apple(),new Orange(),new Animal()};
    for (int i = 0; i < objects.length; i++){
      if (objects[i] instanceof Edible){
        System.out.println(((Edible)objects[i]).howToEat());
      }
    }
        
    }
    
}
