package Chp12;

/**
 * @(#)Orange.java
 *
 *
 * @author 
 * @version 1.00 2010/10/25
 */


public class Orange extends Fruit {
	public String howToEat() {
		return "Make orange juice";
	}
}