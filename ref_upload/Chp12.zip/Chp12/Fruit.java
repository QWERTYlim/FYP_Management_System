package Chp12;

/**
 * @(#)Fruit.java
 *
 *
 * @author 
 * @version 1.00 2010/10/25
 */


public class Fruit implements Edible {
	public String howToEat() {
		return "Eat it fresh";
	}
}