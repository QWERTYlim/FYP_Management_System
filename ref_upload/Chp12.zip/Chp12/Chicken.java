package Chp12;

/**
 * @(#)Chicken.java
 *
 *
 * @author 
 * @version 1.00 2010/10/25
 */


public class Chicken extends Animal  implements Edible {
	public String howToEat() {
		return "Fry it";  
	}
}