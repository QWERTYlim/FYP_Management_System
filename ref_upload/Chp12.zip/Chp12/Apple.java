package Chp12;

/**
 * @(#)Apple.java
 *
 *
 * @author 
 * @version 1.00 2010/10/25
 */


public class Apple extends Fruit {
	public String howToEat() {
		return "Make apple cider";
	}
}