package Chp12;

/**
 * @(#)Animal.java
 *
 *
 * @author 
 * @version 1.00 2010/10/25
 */


public class Animal {

    public Animal() {
    }
    
    
}