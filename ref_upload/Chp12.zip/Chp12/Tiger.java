package Chp12;

/**
 * @(#)Tiger.java
 *
 *
 * @author 
 * @version 1.00 2010/10/25
 */


public class Tiger extends Animal {

    public Tiger() {
    }
    
    
}