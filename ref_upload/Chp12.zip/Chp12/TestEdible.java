package Chp12;

public class TestEdible {
  public static void main(String[] args) {
    Object[] objects = {new Tigers(), new Chickens(), new Apples()};
    for (int i = 0; i < objects.length; i++)
      if (objects[i] instanceof Edible)
        System.out.println(((Edible)objects[i]).howToEat());
  }
}

class Animals {
  // Data fields, constructors, and methods omitted here
}

class Chickens extends Animals implements Edible {
  public String howToEat() {
    return "Chicken: Fry it";
  }
}

class Tigers extends Animals {
}

abstract class Fruits implements Edible {
  // Data fields, constructors, and methods omitted here
}

class Apples extends Fruits {
  public String howToEat() {
    return "Apple: Make apple cider";
  }
}

class Oranges extends Fruits {
  public String howToEat() {
    return "Orange: Make orange juice";
  }
}
