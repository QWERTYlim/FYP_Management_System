/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzaorderingsystem;

/**
 *
 * @author User
 */
public class member {
    String name,password,contactNum,address;
    int memPiont;
    public member(String name,String password,String contactNum,String address){
        this.name=name;
        this.password=password;
        this.contactNum=contactNum;
        this.address=address;
        
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getContactNum() {
        return contactNum;
    }

    public void setContactNum(String contactNum) {
        this.contactNum = contactNum;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getMemPoint() {
        return memPiont;
    }

    public void setMemPiont(int memPiont) {
        this.memPiont += memPiont;
    }
    
}
