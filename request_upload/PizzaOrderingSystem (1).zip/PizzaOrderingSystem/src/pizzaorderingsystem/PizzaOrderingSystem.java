/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzaorderingsystem;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class PizzaOrderingSystem {

    /**
     * @param args the command line arguments
     */
    public static int isMember=0;
    public static String mname ;  
    public static String mpassword;
    public static String name ;  
    public static String contactNum ;  
    public static String address ;  
    public static ArrayList<pizza> addpizza=new ArrayList<pizza>();
    public static int count=0;
    public static int TotalPrice;
     public static String receipt;
     public static int tempMember;
     public static   member a = new member("hongkai","123","01234567","tmn pulai utama");
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
      
        System.out.println("Are you member? Choose 1:yes 2:no");
           int  choose =input.nextInt();
       
        do{
            if(choose<1||choose>2){
             System.out.println("Please choose 1 or 2!! Are you member? Choose 1:yes 2:no");
             choose =input.nextInt();
            }
        if(choose==1){
            System.out.println("Enter your name");
            mname=input.next();
            if(!mname.equals(a.getName())){
                 System.out.println("Invlid Name!Enter your name");
                 mname=input.next();
                 
            }else if(mname.equals(a.getName())){
                System.out.println("Enter your password");
                mpassword=input.next();
                 
            }
            if(!mpassword.equals(a.getPassword())){
               System.out.println("Invlid Password!Enter your password");
               mpassword=input.next();
               
            }else if(mpassword.equals(a.getPassword())){
                 addpizza.add(new pizza());
                 isMember=1;
                OrderPizza();
           
             
            }
        }else if(choose==2){
            System.out.println("Enter your name");
            name=input.next();
            System.out.println("Enter your contact number");
            contactNum =input.next();
            System.out.println("Enter your address");
            address =input.next();
            addpizza.add(new pizza());
            OrderPizza();
        }
        }while(choose<1||choose>2 );


    }
  
    public static void OrderPizza(){
        Scanner input = new Scanner(System.in);
    
       System.out.println("Choose the size of pizza");
       System.out.println("1:SMALL");
       System.out.println("2.MEDIUM");
       System.out.println("3.LARGE");
       int choose=input.nextInt();
        switch(choose){
            case 1:
                 addpizza.get(count).setSize(1);
                 Topping();
                 break;
            case 2:
                 addpizza.get(count).setSize(2);
               Topping();
                 break;
            case 3:
                 addpizza.get(count).setSize(3);
               Topping();
                 break;
        }
    }
    public static void Topping(){
      Scanner input = new Scanner(System.in);
      int a=0;int b=0;int c=0;
        System.out.println("Do you want to add ingredients?");
         System.out.println("1.Pepperoni 2.No");
          a=input.nextInt();
        if(a==1){
              addpizza.get(count).addTopping(0);   
        }
        System.out.println("1.Sausage 2.No");
          b=input.nextInt();
         if(b==1){
              addpizza.get(count).addTopping(1);       
        }
        System.out.println("1.Mushroom 2.No");
          c=input.nextInt();
         if(c==1){
              addpizza.get(count).addTopping(2);    
        }
            TotalPrice+=addpizza.get(count).getPrice();
             morePizza();
        
    }
    public static void morePizza(){
        Scanner input = new Scanner(System.in);
       System.out.println("Do you want to order more pizza? 1.order more 2.no");
       int choose =input.nextInt();
       if(choose==2){
           if(isMember==1){
           a.setMemPiont(TotalPrice);   
       }
           address();
       }
       else if(choose==1){
           count++;
           addpizza.add(new pizza());
           OrderPizza();
       }else{
           System.out.println("Invalid!Do you want to order more pizza? 1.order more 2.no");
           morePizza();
       }
    }
    public static void address(){
          Scanner input = new Scanner(System.in);
        if(isMember==1){
           System.out.println("Use the same address "+a.getAddress()+"? 1.Yes 2.No");
           int choose=input.nextInt();
            if(choose==1){
                receipt();
                 }else if(choose==2){
                  enterAddress();
                 }
            
        }else{
            receipt();
        }
  
    }
    public static void enterAddress(){
            Scanner input = new Scanner(System.in);
         System.out.println("Enter your address");
         address = input.next();
        
             receipt();
                  
    }      
    public static void receipt(){
         if(isMember==1){
                receipt="Receipt\nName: "+a.getName()+"\nTotal Points: "+a.getMemPoint()+"(+"+TotalPrice+")\nTotal Prices: RM"+TotalPrice+"\nAddress: "+a.getAddress()+"\nContact number:"+a.getContactNum();
            
          }else{
              receipt="Receipt\nName : "+name+"\nTotal Prices: RM"+TotalPrice+"\nContact Number: "+contactNum+"\nAddress: "+address;  
          }
          System.out.println(receipt);
                
    }
}
