/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzaorderingsystem;

/**
 *
 * @author User
 */

public class pizza {
    int[] topping = new int[3];
    int price,size;

   
   

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price += price;
    }


    public void setSize(int size) {
        this.size = size;
        switch(size){
           case 1:
                    setPrice(8);
                    break;
           case 2:
                    setPrice(10);
                    break;
           case 3:
                   setPrice(12);
                   break;
        }
    }
     public void addTopping(int add) {
        topping[add]=1;
        this.setPrice(2);
    }
}
