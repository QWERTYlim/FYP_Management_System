﻿Public Class ValueMeal
    Private Sub Label22_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub exitButton_Click(sender As Object, e As EventArgs) 
        Application.Exit()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte1PictureBox.Click
        quantitys(0)
        Quantity.Show()
        Quantity.set_choosen = 18
    End Sub

    Public Sub quantitys(ByVal setnum As Integer)
        Dim picture() = {valueMealAndAlacarte1PictureBox, valueMealAndAlacarte2PictureBox, valueMealAndAlacarte3PictureBox， valueMealAndAlacarte4PictureBox, valueMealAndAlacarte5PictureBox, valueMealAndAlacarte6PictureBox, valueMealAndAlacarte7PictureBox, valueMealAndAlacarte8PictureBox, valueMealAndAlacarte9PictureBox, valueMealAndAlacarte10PictureBox, valueMealAndAlacarte11PictureBox, valueMealAndAlacarte12PictureBox, valueMealAndAlacarte13PictureBox, valueMealAndAlacarte14PictureBox, valueMealAndAlacarte15PictureBox}
        Dim price() = {17.92, 16.03, 16.03, 14.62, 16.51, 14.62, 18.4, 10.37, 16.03, 11.31, 17.45, 12.25, 18.4, 15.57, 8.49}
        Dim setname() = {valueMealAndAlacarte1Label.Text, valueMealAndAlacarte2Label.Text, valueMealAndAlacarte3Label.Text, valueMealAndAlacarte4Label.Text, valueMealAndAlacarte5Label.Text, valueMealAndAlacarte6Label.Text, valueMealAndAlacarte7Label.Text, valueMealAndAlacarte8Label.Text, valueMealAndAlacarte9Label.Text, valueMealAndAlacarte10Label.Text, valueMealAndAlacarte11Label.Text, valueMealAndAlacarte12Label.Text, valueMealAndAlacarte13Label.Text, valueMealAndAlacarte14Label.Text, valueMealAndAlacarte15Label.Text}
        Quantity.SetPictureBox.Image = picture(setnum).Image
        Quantity.Label2.Text = price(setnum)
        Quantity.Label1.Text = setname(setnum)
        Quantity.one_set_price = price(setnum)
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte2PictureBox.Click
        quantitys(1)
        Quantity.Show()
        Quantity.set_choosen = 19
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte3PictureBox.Click
        quantitys(2)
        Quantity.Show()
        Quantity.set_choosen = 20
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte4PictureBox.Click
        quantitys(3)
        Quantity.Show()
        Quantity.set_choosen = 21
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte5PictureBox.Click
        quantitys(4)
        Quantity.Show()
        Quantity.set_choosen = 22
    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte6PictureBox.Click
        quantitys(5)
        Quantity.Show()
        Quantity.set_choosen = 23
    End Sub

    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte7PictureBox.Click
        quantitys(6)
        Quantity.Show()
        Quantity.set_choosen = 24
    End Sub

    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte8PictureBox.Click
        quantitys(7)
        Quantity.Show()
        Quantity.set_choosen = 25
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte9PictureBox.Click
        quantitys(8)
        Quantity.Show()
        Quantity.set_choosen = 26
    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte10PictureBox.Click
        quantitys(9)
        Quantity.Show()
        Quantity.set_choosen = 27
    End Sub

    Private Sub PictureBox11_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte11PictureBox.Click
        quantitys(10)
        Quantity.Show()
        Quantity.set_choosen = 28
    End Sub

    Private Sub PictureBox12_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte12PictureBox.Click
        quantitys(11)
        Quantity.Show()
        Quantity.set_choosen = 29
    End Sub

    Private Sub PictureBox13_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte13PictureBox.Click
        quantitys(12)
        Quantity.Show()
        Quantity.set_choosen = 30
    End Sub

    Private Sub PictureBox14_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte14PictureBox.Click
        quantitys(13)
        Quantity.Show()
        Quantity.set_choosen = 31
    End Sub

    Private Sub PictureBox15_Click(sender As Object, e As EventArgs) Handles valueMealAndAlacarte15PictureBox.Click
        quantitys(14)
        Quantity.Show()
        Quantity.set_choosen = 32
    End Sub
End Class
