﻿Public Class Dessert
    Private Sub exitButton_Click(sender As Object, e As EventArgs) 
        Application.Exit()
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles dessertPanel.Paint

    End Sub
    Public Sub quantitys(ByVal setnum As Integer)
        Dim picture() = {dessert1PictureBox, dessert2PictureBox, dessert3PictureBox, dessert4PictureBox, dessert5PictureBox, dessert6PictureBox, dessert7PictureBox, dessert8PictureBox}
        Dim price() = {5.19, 7.08, 4.25, 4.25, 6.6, 4.53, 4.53, 3.77}
        Dim setname() = {desert1Label.Text, dessert2Label.Text, dessert3Label.Text, dessert4Label.Text, dessert5Label.Text, dessert6Label.Text, dessert7Label.Text, dessert8Label.Text}
        Quantity.SetPictureBox.Image = picture(setnum).Image
        Quantity.Label2.Text = price(setnum)
        Quantity.Label1.Text = setname(setnum)
        Quantity.one_set_price = price(setnum)
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles dessert1PictureBox.Click
        quantitys(0)
        Quantity.Show()
        Quantity.set_choosen = 73
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles dessert2PictureBox.Click
        quantitys(1)
        Quantity.Show()
        Quantity.set_choosen = 74
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles dessert3PictureBox.Click
        quantitys(2)
        Quantity.Show()
        Quantity.set_choosen = 75
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles dessert4PictureBox.Click
        quantitys(3)
        Quantity.Show()
        Quantity.set_choosen = 76
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles dessert5PictureBox.Click
        quantitys(4)
        Quantity.Show()
        Quantity.set_choosen = 77
    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles dessert6PictureBox.Click
        quantitys(5)
        Quantity.Show()
        Quantity.set_choosen = 78
    End Sub

    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles dessert7PictureBox.Click
        quantitys(6)
        Quantity.Show()
        Quantity.set_choosen = 79
    End Sub

    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles dessert8PictureBox.Click
        quantitys(7)
        Quantity.Show()
        Quantity.set_choosen = 80
    End Sub
End Class
