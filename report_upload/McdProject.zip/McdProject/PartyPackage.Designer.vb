﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PartyPackage
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PartyPackage))
        Me.partyPackageLabel = New System.Windows.Forms.Label()
        Me.partyPackagePanel = New System.Windows.Forms.Panel()
        Me.partyPackage4PictureBox = New System.Windows.Forms.PictureBox()
        Me.partyPackagePrice5Label = New System.Windows.Forms.Label()
        Me.partyPackage1PictureBox = New System.Windows.Forms.PictureBox()
        Me.partyPackage5Label = New System.Windows.Forms.Label()
        Me.partyPackagePrice4Label = New System.Windows.Forms.Label()
        Me.partyPackage2PictureBox = New System.Windows.Forms.PictureBox()
        Me.partyPackage4Label = New System.Windows.Forms.Label()
        Me.partyPackage3PictureBox = New System.Windows.Forms.PictureBox()
        Me.partyPackage3Label = New System.Windows.Forms.Label()
        Me.partyPackage5PictureBox = New System.Windows.Forms.PictureBox()
        Me.partyPackage2Label = New System.Windows.Forms.Label()
        Me.partyPackagePrice1Label = New System.Windows.Forms.Label()
        Me.partyPackagePrice2Label = New System.Windows.Forms.Label()
        Me.partyPackage1Label = New System.Windows.Forms.Label()
        Me.partyPackagePrice3Label = New System.Windows.Forms.Label()
        Me.partyPackagePanel.SuspendLayout()
        CType(Me.partyPackage4PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.partyPackage1PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.partyPackage2PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.partyPackage3PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.partyPackage5PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'partyPackageLabel
        '
        Me.partyPackageLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.partyPackageLabel.Font = New System.Drawing.Font("Segoe UI", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.partyPackageLabel.Location = New System.Drawing.Point(3, 10)
        Me.partyPackageLabel.Name = "partyPackageLabel"
        Me.partyPackageLabel.Size = New System.Drawing.Size(1670, 99)
        Me.partyPackageLabel.TabIndex = 50
        Me.partyPackageLabel.Text = "Party Package"
        '
        'partyPackagePanel
        '
        Me.partyPackagePanel.Controls.Add(Me.partyPackage4PictureBox)
        Me.partyPackagePanel.Controls.Add(Me.partyPackagePrice5Label)
        Me.partyPackagePanel.Controls.Add(Me.partyPackage1PictureBox)
        Me.partyPackagePanel.Controls.Add(Me.partyPackage5Label)
        Me.partyPackagePanel.Controls.Add(Me.partyPackagePrice4Label)
        Me.partyPackagePanel.Controls.Add(Me.partyPackage2PictureBox)
        Me.partyPackagePanel.Controls.Add(Me.partyPackage4Label)
        Me.partyPackagePanel.Controls.Add(Me.partyPackage3PictureBox)
        Me.partyPackagePanel.Controls.Add(Me.partyPackage3Label)
        Me.partyPackagePanel.Controls.Add(Me.partyPackage5PictureBox)
        Me.partyPackagePanel.Controls.Add(Me.partyPackage2Label)
        Me.partyPackagePanel.Controls.Add(Me.partyPackagePrice1Label)
        Me.partyPackagePanel.Controls.Add(Me.partyPackagePrice2Label)
        Me.partyPackagePanel.Controls.Add(Me.partyPackage1Label)
        Me.partyPackagePanel.Controls.Add(Me.partyPackagePrice3Label)
        Me.partyPackagePanel.Location = New System.Drawing.Point(12, 112)
        Me.partyPackagePanel.Name = "partyPackagePanel"
        Me.partyPackagePanel.Size = New System.Drawing.Size(1650, 521)
        Me.partyPackagePanel.TabIndex = 92
        '
        'partyPackage4PictureBox
        '
        Me.partyPackage4PictureBox.Image = CType(resources.GetObject("partyPackage4PictureBox.Image"), System.Drawing.Image)
        Me.partyPackage4PictureBox.Location = New System.Drawing.Point(1056, 10)
        Me.partyPackage4PictureBox.Name = "partyPackage4PictureBox"
        Me.partyPackage4PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.partyPackage4PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.partyPackage4PictureBox.TabIndex = 85
        Me.partyPackage4PictureBox.TabStop = False
        '
        'partyPackagePrice5Label
        '
        Me.partyPackagePrice5Label.AutoSize = True
        Me.partyPackagePrice5Label.Location = New System.Drawing.Point(1357, 196)
        Me.partyPackagePrice5Label.Name = "partyPackagePrice5Label"
        Me.partyPackagePrice5Label.Size = New System.Drawing.Size(73, 17)
        Me.partyPackagePrice5Label.TabIndex = 90
        Me.partyPackagePrice5Label.Text = "From RM9"
        '
        'partyPackage1PictureBox
        '
        Me.partyPackage1PictureBox.Image = CType(resources.GetObject("partyPackage1PictureBox.Image"), System.Drawing.Image)
        Me.partyPackage1PictureBox.Location = New System.Drawing.Point(16, 10)
        Me.partyPackage1PictureBox.Name = "partyPackage1PictureBox"
        Me.partyPackage1PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.partyPackage1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.partyPackage1PictureBox.TabIndex = 76
        Me.partyPackage1PictureBox.TabStop = False
        '
        'partyPackage5Label
        '
        Me.partyPackage5Label.AutoSize = True
        Me.partyPackage5Label.Location = New System.Drawing.Point(1357, 179)
        Me.partyPackage5Label.Name = "partyPackage5Label"
        Me.partyPackage5Label.Size = New System.Drawing.Size(89, 17)
        Me.partyPackage5Label.TabIndex = 89
        Me.partyPackage5Label.Text = "Party Pack C"
        '
        'partyPackagePrice4Label
        '
        Me.partyPackagePrice4Label.AutoSize = True
        Me.partyPackagePrice4Label.Location = New System.Drawing.Point(1053, 196)
        Me.partyPackagePrice4Label.Name = "partyPackagePrice4Label"
        Me.partyPackagePrice4Label.Size = New System.Drawing.Size(73, 17)
        Me.partyPackagePrice4Label.TabIndex = 88
        Me.partyPackagePrice4Label.Text = "From RM9"
        '
        'partyPackage2PictureBox
        '
        Me.partyPackage2PictureBox.Image = CType(resources.GetObject("partyPackage2PictureBox.Image"), System.Drawing.Image)
        Me.partyPackage2PictureBox.Location = New System.Drawing.Point(369, 10)
        Me.partyPackage2PictureBox.Name = "partyPackage2PictureBox"
        Me.partyPackage2PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.partyPackage2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.partyPackage2PictureBox.TabIndex = 77
        Me.partyPackage2PictureBox.TabStop = False
        '
        'partyPackage4Label
        '
        Me.partyPackage4Label.AutoSize = True
        Me.partyPackage4Label.Location = New System.Drawing.Point(1053, 179)
        Me.partyPackage4Label.Name = "partyPackage4Label"
        Me.partyPackage4Label.Size = New System.Drawing.Size(89, 17)
        Me.partyPackage4Label.TabIndex = 87
        Me.partyPackage4Label.Text = "Party Pack B"
        '
        'partyPackage3PictureBox
        '
        Me.partyPackage3PictureBox.Image = CType(resources.GetObject("partyPackage3PictureBox.Image"), System.Drawing.Image)
        Me.partyPackage3PictureBox.Location = New System.Drawing.Point(719, 10)
        Me.partyPackage3PictureBox.Name = "partyPackage3PictureBox"
        Me.partyPackage3PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.partyPackage3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.partyPackage3PictureBox.TabIndex = 78
        Me.partyPackage3PictureBox.TabStop = False
        '
        'partyPackage3Label
        '
        Me.partyPackage3Label.AutoSize = True
        Me.partyPackage3Label.Location = New System.Drawing.Point(716, 179)
        Me.partyPackage3Label.Name = "partyPackage3Label"
        Me.partyPackage3Label.Size = New System.Drawing.Size(89, 17)
        Me.partyPackage3Label.TabIndex = 81
        Me.partyPackage3Label.Text = "Party Pack A"
        '
        'partyPackage5PictureBox
        '
        Me.partyPackage5PictureBox.Image = CType(resources.GetObject("partyPackage5PictureBox.Image"), System.Drawing.Image)
        Me.partyPackage5PictureBox.Location = New System.Drawing.Point(1360, 10)
        Me.partyPackage5PictureBox.Name = "partyPackage5PictureBox"
        Me.partyPackage5PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.partyPackage5PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.partyPackage5PictureBox.TabIndex = 86
        Me.partyPackage5PictureBox.TabStop = False
        '
        'partyPackage2Label
        '
        Me.partyPackage2Label.AutoSize = True
        Me.partyPackage2Label.Location = New System.Drawing.Point(370, 179)
        Me.partyPackage2Label.Name = "partyPackage2Label"
        Me.partyPackage2Label.Size = New System.Drawing.Size(154, 17)
        Me.partyPackage2Label.TabIndex = 79
        Me.partyPackage2Label.Text = "Home Party Package B"
        '
        'partyPackagePrice1Label
        '
        Me.partyPackagePrice1Label.AutoSize = True
        Me.partyPackagePrice1Label.Location = New System.Drawing.Point(17, 196)
        Me.partyPackagePrice1Label.Name = "partyPackagePrice1Label"
        Me.partyPackagePrice1Label.Size = New System.Drawing.Size(101, 17)
        Me.partyPackagePrice1Label.TabIndex = 84
        Me.partyPackagePrice1Label.Text = "From RM94.34"
        '
        'partyPackagePrice2Label
        '
        Me.partyPackagePrice2Label.AutoSize = True
        Me.partyPackagePrice2Label.Location = New System.Drawing.Point(370, 196)
        Me.partyPackagePrice2Label.Name = "partyPackagePrice2Label"
        Me.partyPackagePrice2Label.Size = New System.Drawing.Size(109, 17)
        Me.partyPackagePrice2Label.TabIndex = 80
        Me.partyPackagePrice2Label.Text = "From RM141.51"
        '
        'partyPackage1Label
        '
        Me.partyPackage1Label.AutoSize = True
        Me.partyPackage1Label.Location = New System.Drawing.Point(17, 179)
        Me.partyPackage1Label.Name = "partyPackage1Label"
        Me.partyPackage1Label.Size = New System.Drawing.Size(154, 17)
        Me.partyPackage1Label.TabIndex = 83
        Me.partyPackage1Label.Text = "Home Party Package A"
        '
        'partyPackagePrice3Label
        '
        Me.partyPackagePrice3Label.AutoSize = True
        Me.partyPackagePrice3Label.Location = New System.Drawing.Point(716, 196)
        Me.partyPackagePrice3Label.Name = "partyPackagePrice3Label"
        Me.partyPackagePrice3Label.Size = New System.Drawing.Size(73, 17)
        Me.partyPackagePrice3Label.TabIndex = 82
        Me.partyPackagePrice3Label.Text = "From RM9"
        '
        'PartyPackage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.partyPackagePanel)
        Me.Controls.Add(Me.partyPackageLabel)
        Me.Name = "PartyPackage"
        Me.Size = New System.Drawing.Size(1676, 1038)
        Me.partyPackagePanel.ResumeLayout(False)
        Me.partyPackagePanel.PerformLayout()
        CType(Me.partyPackage4PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.partyPackage1PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.partyPackage2PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.partyPackage3PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.partyPackage5PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents partyPackageLabel As Label
    Friend WithEvents partyPackagePanel As Panel
    Friend WithEvents partyPackage4PictureBox As PictureBox
    Friend WithEvents partyPackagePrice5Label As Label
    Friend WithEvents partyPackage1PictureBox As PictureBox
    Friend WithEvents partyPackage5Label As Label
    Friend WithEvents partyPackagePrice4Label As Label
    Friend WithEvents partyPackage2PictureBox As PictureBox
    Friend WithEvents partyPackage4Label As Label
    Friend WithEvents partyPackage3PictureBox As PictureBox
    Friend WithEvents partyPackage3Label As Label
    Friend WithEvents partyPackage5PictureBox As PictureBox
    Friend WithEvents partyPackage2Label As Label
    Friend WithEvents partyPackagePrice1Label As Label
    Friend WithEvents partyPackagePrice2Label As Label
    Friend WithEvents partyPackage1Label As Label
    Friend WithEvents partyPackagePrice3Label As Label
End Class
