﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ViewOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ViewOrder))
        Me.mcdLogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.backButton = New System.Windows.Forms.Button()
        Me.foodOrderFlowLayoutPanel = New System.Windows.Forms.FlowLayoutPanel()
        Me.foodNameQuantityPricePanel = New System.Windows.Forms.Panel()
        Me.quantityLabel = New System.Windows.Forms.Label()
        Me.priceLabel = New System.Windows.Forms.Label()
        Me.nameLabel = New System.Windows.Forms.Label()
        Me.Beverage1 = New McdProject.Beverage()
        Me.foodPanel = New System.Windows.Forms.Panel()
        Me.FoodsPriceLabel = New System.Windows.Forms.Label()
        Me.FoodsQuantityLabel = New System.Windows.Forms.Label()
        Me.FoodNameLabel = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.totalPriceLabel = New System.Windows.Forms.Label()
        Me.totalLabel = New System.Windows.Forms.Label()
        CType(Me.mcdLogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.foodOrderFlowLayoutPanel.SuspendLayout()
        Me.foodNameQuantityPricePanel.SuspendLayout()
        Me.foodPanel.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'mcdLogoPictureBox
        '
        Me.mcdLogoPictureBox.Image = CType(resources.GetObject("mcdLogoPictureBox.Image"), System.Drawing.Image)
        Me.mcdLogoPictureBox.Location = New System.Drawing.Point(779, 46)
        Me.mcdLogoPictureBox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.mcdLogoPictureBox.Name = "mcdLogoPictureBox"
        Me.mcdLogoPictureBox.Size = New System.Drawing.Size(389, 194)
        Me.mcdLogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcdLogoPictureBox.TabIndex = 1
        Me.mcdLogoPictureBox.TabStop = False
        '
        'backButton
        '
        Me.backButton.AutoSize = True
        Me.backButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.backButton.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.backButton.ForeColor = System.Drawing.Color.White
        Me.backButton.Location = New System.Drawing.Point(1685, 46)
        Me.backButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.backButton.Name = "backButton"
        Me.backButton.Size = New System.Drawing.Size(156, 58)
        Me.backButton.TabIndex = 189
        Me.backButton.Text = "Back"
        Me.backButton.UseVisualStyleBackColor = False
        '
        'foodOrderFlowLayoutPanel
        '
        Me.foodOrderFlowLayoutPanel.BackColor = System.Drawing.Color.White
        Me.foodOrderFlowLayoutPanel.Controls.Add(Me.foodNameQuantityPricePanel)
        Me.foodOrderFlowLayoutPanel.Controls.Add(Me.Beverage1)
        Me.foodOrderFlowLayoutPanel.Controls.Add(Me.foodPanel)
        Me.foodOrderFlowLayoutPanel.Controls.Add(Me.Panel3)
        Me.foodOrderFlowLayoutPanel.Location = New System.Drawing.Point(467, 274)
        Me.foodOrderFlowLayoutPanel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.foodOrderFlowLayoutPanel.Name = "foodOrderFlowLayoutPanel"
        Me.foodOrderFlowLayoutPanel.Size = New System.Drawing.Size(1080, 597)
        Me.foodOrderFlowLayoutPanel.TabIndex = 191
        '
        'foodNameQuantityPricePanel
        '
        Me.foodNameQuantityPricePanel.BackColor = System.Drawing.Color.Yellow
        Me.foodNameQuantityPricePanel.Controls.Add(Me.quantityLabel)
        Me.foodNameQuantityPricePanel.Controls.Add(Me.priceLabel)
        Me.foodNameQuantityPricePanel.Controls.Add(Me.nameLabel)
        Me.foodNameQuantityPricePanel.Location = New System.Drawing.Point(3, 2)
        Me.foodNameQuantityPricePanel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.foodNameQuantityPricePanel.Name = "foodNameQuantityPricePanel"
        Me.foodNameQuantityPricePanel.Size = New System.Drawing.Size(1077, 70)
        Me.foodNameQuantityPricePanel.TabIndex = 192
        '
        'quantityLabel
        '
        Me.quantityLabel.AutoSize = True
        Me.quantityLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.quantityLabel.Location = New System.Drawing.Point(664, 25)
        Me.quantityLabel.Name = "quantityLabel"
        Me.quantityLabel.Size = New System.Drawing.Size(80, 23)
        Me.quantityLabel.TabIndex = 23
        Me.quantityLabel.Text = "Quantity"
        '
        'priceLabel
        '
        Me.priceLabel.AutoSize = True
        Me.priceLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.priceLabel.Location = New System.Drawing.Point(875, 25)
        Me.priceLabel.Name = "priceLabel"
        Me.priceLabel.Size = New System.Drawing.Size(49, 23)
        Me.priceLabel.TabIndex = 193
        Me.priceLabel.Text = "Price"
        '
        'nameLabel
        '
        Me.nameLabel.AutoSize = True
        Me.nameLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.nameLabel.Location = New System.Drawing.Point(37, 25)
        Me.nameLabel.Name = "nameLabel"
        Me.nameLabel.Size = New System.Drawing.Size(107, 23)
        Me.nameLabel.TabIndex = 22
        Me.nameLabel.Text = "Food Name "
        '
        'Beverage1
        '
        Me.Beverage1.Location = New System.Drawing.Point(3, 76)
        Me.Beverage1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Beverage1.Name = "Beverage1"
        Me.Beverage1.Size = New System.Drawing.Size(8, 7)
        Me.Beverage1.TabIndex = 193
        '
        'foodPanel
        '
        Me.foodPanel.AutoScroll = True
        Me.foodPanel.Controls.Add(Me.FoodsPriceLabel)
        Me.foodPanel.Controls.Add(Me.FoodsQuantityLabel)
        Me.foodPanel.Controls.Add(Me.FoodNameLabel)
        Me.foodPanel.Location = New System.Drawing.Point(3, 87)
        Me.foodPanel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.foodPanel.Name = "foodPanel"
        Me.foodPanel.Size = New System.Drawing.Size(1072, 522)
        Me.foodPanel.TabIndex = 194
        '
        'FoodsPriceLabel
        '
        Me.FoodsPriceLabel.AutoSize = True
        Me.FoodsPriceLabel.BackColor = System.Drawing.Color.White
        Me.FoodsPriceLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FoodsPriceLabel.ForeColor = System.Drawing.Color.Black
        Me.FoodsPriceLabel.Location = New System.Drawing.Point(831, -2)
        Me.FoodsPriceLabel.Name = "FoodsPriceLabel"
        Me.FoodsPriceLabel.Size = New System.Drawing.Size(0, 32)
        Me.FoodsPriceLabel.TabIndex = 194
        Me.FoodsPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'FoodsQuantityLabel
        '
        Me.FoodsQuantityLabel.AutoSize = True
        Me.FoodsQuantityLabel.BackColor = System.Drawing.Color.White
        Me.FoodsQuantityLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FoodsQuantityLabel.ForeColor = System.Drawing.Color.Black
        Me.FoodsQuantityLabel.Location = New System.Drawing.Point(684, 0)
        Me.FoodsQuantityLabel.Name = "FoodsQuantityLabel"
        Me.FoodsQuantityLabel.Size = New System.Drawing.Size(0, 32)
        Me.FoodsQuantityLabel.TabIndex = 193
        Me.FoodsQuantityLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'FoodNameLabel
        '
        Me.FoodNameLabel.AutoSize = True
        Me.FoodNameLabel.BackColor = System.Drawing.Color.White
        Me.FoodNameLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FoodNameLabel.ForeColor = System.Drawing.Color.Black
        Me.FoodNameLabel.Location = New System.Drawing.Point(13, 0)
        Me.FoodNameLabel.Name = "FoodNameLabel"
        Me.FoodNameLabel.Size = New System.Drawing.Size(0, 32)
        Me.FoodNameLabel.TabIndex = 192
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Location = New System.Drawing.Point(3, 613)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(965, 75)
        Me.Panel3.TabIndex = 197
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.Label2.Location = New System.Drawing.Point(823, 25)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(101, 23)
        Me.Label2.TabIndex = 196
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.Label1.Location = New System.Drawing.Point(724, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 23)
        Me.Label1.TabIndex = 195
        Me.Label1.Text = "Total: "
        '
        'totalPriceLabel
        '
        Me.totalPriceLabel.AutoSize = True
        Me.totalPriceLabel.BackColor = System.Drawing.Color.White
        Me.totalPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.totalPriceLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.totalPriceLabel.Location = New System.Drawing.Point(1307, 891)
        Me.totalPriceLabel.Name = "totalPriceLabel"
        Me.totalPriceLabel.Size = New System.Drawing.Size(45, 27)
        Me.totalPriceLabel.TabIndex = 195
        Me.totalPriceLabel.Text = "test"
        '
        'totalLabel
        '
        Me.totalLabel.AutoSize = True
        Me.totalLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.totalLabel.ForeColor = System.Drawing.Color.Yellow
        Me.totalLabel.Location = New System.Drawing.Point(1229, 892)
        Me.totalLabel.Name = "totalLabel"
        Me.totalLabel.Size = New System.Drawing.Size(56, 25)
        Me.totalLabel.TabIndex = 196
        Me.totalLabel.Text = "Total"
        '
        'ViewOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1942, 1071)
        Me.Controls.Add(Me.totalLabel)
        Me.Controls.Add(Me.foodOrderFlowLayoutPanel)
        Me.Controls.Add(Me.totalPriceLabel)
        Me.Controls.Add(Me.backButton)
        Me.Controls.Add(Me.mcdLogoPictureBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "ViewOrder"
        Me.Text = "Form2"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.mcdLogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.foodOrderFlowLayoutPanel.ResumeLayout(False)
        Me.foodNameQuantityPricePanel.ResumeLayout(False)
        Me.foodNameQuantityPricePanel.PerformLayout()
        Me.foodPanel.ResumeLayout(False)
        Me.foodPanel.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents mcdLogoPictureBox As PictureBox
    Friend WithEvents backButton As Button
    Friend WithEvents foodOrderFlowLayoutPanel As FlowLayoutPanel
    Friend WithEvents foodNameQuantityPricePanel As Panel
    Friend WithEvents quantityLabel As Label
    Friend WithEvents priceLabel As Label
    Friend WithEvents nameLabel As Label
    Friend WithEvents Beverage1 As Beverage
    Friend WithEvents foodPanel As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents FoodNameLabel As Label
    Friend WithEvents FoodsQuantityLabel As Label
    Friend WithEvents FoodsPriceLabel As Label
    Friend WithEvents totalPriceLabel As Label
    Friend WithEvents totalLabel As Label
End Class
