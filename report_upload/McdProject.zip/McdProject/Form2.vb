﻿Public Class Form2
    Private Sub yesButton_Click(sender As Object, e As EventArgs) Handles yesButton.Click
        menus.Show()
        Me.Close()

    End Sub

    Private Sub noButton_Click(sender As Object, e As EventArgs) Handles noButton.Click
        menus.Show()
        Me.Close()
    End Sub
End Class