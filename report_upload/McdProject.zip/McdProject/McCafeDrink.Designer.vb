﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class McCafeDrink
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(McCafeDrink))
        Me.mcCafeDrinkLabel = New System.Windows.Forms.Label()
        Me.mcCafeDrinkPanel = New System.Windows.Forms.Panel()
        Me.mcCafeDrink1PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeDrinkPrice11Label = New System.Windows.Forms.Label()
        Me.mcCafeDrinkPrice10Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink11Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink2PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeDrinkPrice13Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink10Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink13Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink3PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeDrinkPrice12Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink10PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeDrink12Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink2Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink13PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeDrinkPrice2Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink12PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeDrink3Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink11PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeDrinkPrice3Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink1Label = New System.Windows.Forms.Label()
        Me.mcCafeDrinkPrice1Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink4PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeDrink5PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeDrink4Label = New System.Windows.Forms.Label()
        Me.mcCafeDrinkPrice4Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink5Label = New System.Windows.Forms.Label()
        Me.mcCafeDrinkPrice9Label = New System.Windows.Forms.Label()
        Me.mcCafeDrinkPrice8Label = New System.Windows.Forms.Label()
        Me.mcCafeDrinkPrice7Label = New System.Windows.Forms.Label()
        Me.mcCafeDrinkPrice6Label = New System.Windows.Forms.Label()
        Me.mcCafeDrinkPrice5Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink6Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink6PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeDrink9Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink7PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeDrink8PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeDrink9PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeDrink7Label = New System.Windows.Forms.Label()
        Me.mcCafeDrink8Label = New System.Windows.Forms.Label()
        Me.mcCafeDrinkPanel.SuspendLayout()
        CType(Me.mcCafeDrink1PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeDrink2PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeDrink3PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeDrink10PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeDrink13PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeDrink12PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeDrink11PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeDrink4PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeDrink5PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeDrink6PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeDrink7PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeDrink8PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeDrink9PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mcCafeDrinkLabel
        '
        Me.mcCafeDrinkLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.mcCafeDrinkLabel.Font = New System.Drawing.Font("Segoe UI", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mcCafeDrinkLabel.Location = New System.Drawing.Point(3, 10)
        Me.mcCafeDrinkLabel.Name = "mcCafeDrinkLabel"
        Me.mcCafeDrinkLabel.Size = New System.Drawing.Size(1670, 99)
        Me.mcCafeDrinkLabel.TabIndex = 50
        Me.mcCafeDrinkLabel.Text = "McCafe Drink"
        '
        'mcCafeDrinkPanel
        '
        Me.mcCafeDrinkPanel.AutoScroll = True
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink1PictureBox)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrinkPrice11Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrinkPrice10Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink11Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink2PictureBox)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrinkPrice13Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink10Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink13Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink3PictureBox)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrinkPrice12Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink10PictureBox)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink12Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink2Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink13PictureBox)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrinkPrice2Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink12PictureBox)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink3Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink11PictureBox)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrinkPrice3Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink1Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrinkPrice1Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink4PictureBox)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink5PictureBox)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink4Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrinkPrice4Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink5Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrinkPrice9Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrinkPrice8Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrinkPrice7Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrinkPrice6Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrinkPrice5Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink6Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink6PictureBox)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink9Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink7PictureBox)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink8PictureBox)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink9PictureBox)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink7Label)
        Me.mcCafeDrinkPanel.Controls.Add(Me.mcCafeDrink8Label)
        Me.mcCafeDrinkPanel.Location = New System.Drawing.Point(12, 112)
        Me.mcCafeDrinkPanel.Name = "mcCafeDrinkPanel"
        Me.mcCafeDrinkPanel.Size = New System.Drawing.Size(1650, 625)
        Me.mcCafeDrinkPanel.TabIndex = 119
        '
        'mcCafeDrink1PictureBox
        '
        Me.mcCafeDrink1PictureBox.Image = CType(resources.GetObject("mcCafeDrink1PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeDrink1PictureBox.Location = New System.Drawing.Point(16, 10)
        Me.mcCafeDrink1PictureBox.Name = "mcCafeDrink1PictureBox"
        Me.mcCafeDrink1PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeDrink1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeDrink1PictureBox.TabIndex = 76
        Me.mcCafeDrink1PictureBox.TabStop = False
        '
        'mcCafeDrinkPrice11Label
        '
        Me.mcCafeDrinkPrice11Label.AutoSize = True
        Me.mcCafeDrinkPrice11Label.Location = New System.Drawing.Point(19, 683)
        Me.mcCafeDrinkPrice11Label.Name = "mcCafeDrinkPrice11Label"
        Me.mcCafeDrinkPrice11Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeDrinkPrice11Label.TabIndex = 114
        Me.mcCafeDrinkPrice11Label.Text = "From RM12.25"
        '
        'mcCafeDrinkPrice10Label
        '
        Me.mcCafeDrinkPrice10Label.AutoSize = True
        Me.mcCafeDrinkPrice10Label.Location = New System.Drawing.Point(1357, 436)
        Me.mcCafeDrinkPrice10Label.Name = "mcCafeDrinkPrice10Label"
        Me.mcCafeDrinkPrice10Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeDrinkPrice10Label.TabIndex = 117
        Me.mcCafeDrinkPrice10Label.Text = "From RM12.25"
        '
        'mcCafeDrink11Label
        '
        Me.mcCafeDrink11Label.AutoSize = True
        Me.mcCafeDrink11Label.Location = New System.Drawing.Point(17, 666)
        Me.mcCafeDrink11Label.Name = "mcCafeDrink11Label"
        Me.mcCafeDrink11Label.Size = New System.Drawing.Size(191, 17)
        Me.mcCafeDrink11Label.TabIndex = 113
        Me.mcCafeDrink11Label.Text = "Classic Cheesecake + Coffee"
        '
        'mcCafeDrink2PictureBox
        '
        Me.mcCafeDrink2PictureBox.Image = CType(resources.GetObject("mcCafeDrink2PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeDrink2PictureBox.Location = New System.Drawing.Point(369, 10)
        Me.mcCafeDrink2PictureBox.Name = "mcCafeDrink2PictureBox"
        Me.mcCafeDrink2PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeDrink2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeDrink2PictureBox.TabIndex = 77
        Me.mcCafeDrink2PictureBox.TabStop = False
        '
        'mcCafeDrinkPrice13Label
        '
        Me.mcCafeDrinkPrice13Label.AutoSize = True
        Me.mcCafeDrinkPrice13Label.Location = New System.Drawing.Point(716, 683)
        Me.mcCafeDrinkPrice13Label.Name = "mcCafeDrinkPrice13Label"
        Me.mcCafeDrinkPrice13Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeDrinkPrice13Label.TabIndex = 112
        Me.mcCafeDrinkPrice13Label.Text = "From RM12.25"
        '
        'mcCafeDrink10Label
        '
        Me.mcCafeDrink10Label.AutoSize = True
        Me.mcCafeDrink10Label.Location = New System.Drawing.Point(1357, 419)
        Me.mcCafeDrink10Label.Name = "mcCafeDrink10Label"
        Me.mcCafeDrink10Label.Size = New System.Drawing.Size(182, 17)
        Me.mcCafeDrink10Label.TabIndex = 116
        Me.mcCafeDrink10Label.Text = "Belgium Chocolate + Coffee"
        '
        'mcCafeDrink13Label
        '
        Me.mcCafeDrink13Label.AutoSize = True
        Me.mcCafeDrink13Label.Location = New System.Drawing.Point(716, 666)
        Me.mcCafeDrink13Label.Name = "mcCafeDrink13Label"
        Me.mcCafeDrink13Label.Size = New System.Drawing.Size(170, 17)
        Me.mcCafeDrink13Label.TabIndex = 111
        Me.mcCafeDrink13Label.Text = "Red Velvet Cake + Coffee"
        '
        'mcCafeDrink3PictureBox
        '
        Me.mcCafeDrink3PictureBox.Image = CType(resources.GetObject("mcCafeDrink3PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeDrink3PictureBox.Location = New System.Drawing.Point(719, 10)
        Me.mcCafeDrink3PictureBox.Name = "mcCafeDrink3PictureBox"
        Me.mcCafeDrink3PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeDrink3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeDrink3PictureBox.TabIndex = 78
        Me.mcCafeDrink3PictureBox.TabStop = False
        '
        'mcCafeDrinkPrice12Label
        '
        Me.mcCafeDrinkPrice12Label.AutoSize = True
        Me.mcCafeDrinkPrice12Label.Location = New System.Drawing.Point(369, 683)
        Me.mcCafeDrinkPrice12Label.Name = "mcCafeDrinkPrice12Label"
        Me.mcCafeDrinkPrice12Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeDrinkPrice12Label.TabIndex = 110
        Me.mcCafeDrinkPrice12Label.Text = "From RM12.25"
        '
        'mcCafeDrink10PictureBox
        '
        Me.mcCafeDrink10PictureBox.Image = CType(resources.GetObject("mcCafeDrink10PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeDrink10PictureBox.Location = New System.Drawing.Point(1360, 250)
        Me.mcCafeDrink10PictureBox.Name = "mcCafeDrink10PictureBox"
        Me.mcCafeDrink10PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeDrink10PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeDrink10PictureBox.TabIndex = 115
        Me.mcCafeDrink10PictureBox.TabStop = False
        '
        'mcCafeDrink12Label
        '
        Me.mcCafeDrink12Label.AutoSize = True
        Me.mcCafeDrink12Label.Location = New System.Drawing.Point(369, 666)
        Me.mcCafeDrink12Label.Name = "mcCafeDrink12Label"
        Me.mcCafeDrink12Label.Size = New System.Drawing.Size(246, 17)
        Me.mcCafeDrink12Label.TabIndex = 109
        Me.mcCafeDrink12Label.Text = "Cookies & Cream Cheesecake + Coffee"
        '
        'mcCafeDrink2Label
        '
        Me.mcCafeDrink2Label.AutoSize = True
        Me.mcCafeDrink2Label.Location = New System.Drawing.Point(367, 179)
        Me.mcCafeDrink2Label.Name = "mcCafeDrink2Label"
        Me.mcCafeDrink2Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeDrink2Label.TabIndex = 79
        Me.mcCafeDrink2Label.Text = "Iced Chocolate"
        '
        'mcCafeDrink13PictureBox
        '
        Me.mcCafeDrink13PictureBox.Image = CType(resources.GetObject("mcCafeDrink13PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeDrink13PictureBox.Location = New System.Drawing.Point(719, 497)
        Me.mcCafeDrink13PictureBox.Name = "mcCafeDrink13PictureBox"
        Me.mcCafeDrink13PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeDrink13PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeDrink13PictureBox.TabIndex = 108
        Me.mcCafeDrink13PictureBox.TabStop = False
        '
        'mcCafeDrinkPrice2Label
        '
        Me.mcCafeDrinkPrice2Label.AutoSize = True
        Me.mcCafeDrinkPrice2Label.Location = New System.Drawing.Point(367, 196)
        Me.mcCafeDrinkPrice2Label.Name = "mcCafeDrinkPrice2Label"
        Me.mcCafeDrinkPrice2Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeDrinkPrice2Label.TabIndex = 80
        Me.mcCafeDrinkPrice2Label.Text = "From RM10.37"
        '
        'mcCafeDrink12PictureBox
        '
        Me.mcCafeDrink12PictureBox.Image = CType(resources.GetObject("mcCafeDrink12PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeDrink12PictureBox.Location = New System.Drawing.Point(369, 497)
        Me.mcCafeDrink12PictureBox.Name = "mcCafeDrink12PictureBox"
        Me.mcCafeDrink12PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeDrink12PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeDrink12PictureBox.TabIndex = 107
        Me.mcCafeDrink12PictureBox.TabStop = False
        '
        'mcCafeDrink3Label
        '
        Me.mcCafeDrink3Label.AutoSize = True
        Me.mcCafeDrink3Label.Location = New System.Drawing.Point(716, 179)
        Me.mcCafeDrink3Label.Name = "mcCafeDrink3Label"
        Me.mcCafeDrink3Label.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.mcCafeDrink3Label.Size = New System.Drawing.Size(70, 17)
        Me.mcCafeDrink3Label.TabIndex = 81
        Me.mcCafeDrink3Label.Text = "Iced Latte"
        '
        'mcCafeDrink11PictureBox
        '
        Me.mcCafeDrink11PictureBox.Image = CType(resources.GetObject("mcCafeDrink11PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeDrink11PictureBox.Location = New System.Drawing.Point(16, 497)
        Me.mcCafeDrink11PictureBox.Name = "mcCafeDrink11PictureBox"
        Me.mcCafeDrink11PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeDrink11PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeDrink11PictureBox.TabIndex = 106
        Me.mcCafeDrink11PictureBox.TabStop = False
        '
        'mcCafeDrinkPrice3Label
        '
        Me.mcCafeDrinkPrice3Label.AutoSize = True
        Me.mcCafeDrinkPrice3Label.Location = New System.Drawing.Point(716, 196)
        Me.mcCafeDrinkPrice3Label.Name = "mcCafeDrinkPrice3Label"
        Me.mcCafeDrinkPrice3Label.Size = New System.Drawing.Size(93, 17)
        Me.mcCafeDrinkPrice3Label.TabIndex = 82
        Me.mcCafeDrinkPrice3Label.Text = "From RM8.96"
        '
        'mcCafeDrink1Label
        '
        Me.mcCafeDrink1Label.AutoSize = True
        Me.mcCafeDrink1Label.Location = New System.Drawing.Point(17, 179)
        Me.mcCafeDrink1Label.Name = "mcCafeDrink1Label"
        Me.mcCafeDrink1Label.Size = New System.Drawing.Size(80, 17)
        Me.mcCafeDrink1Label.TabIndex = 83
        Me.mcCafeDrink1Label.Text = "Iced Mocha"
        '
        'mcCafeDrinkPrice1Label
        '
        Me.mcCafeDrinkPrice1Label.AutoSize = True
        Me.mcCafeDrinkPrice1Label.Location = New System.Drawing.Point(17, 196)
        Me.mcCafeDrinkPrice1Label.Name = "mcCafeDrinkPrice1Label"
        Me.mcCafeDrinkPrice1Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeDrinkPrice1Label.TabIndex = 84
        Me.mcCafeDrinkPrice1Label.Text = "From RM10.37"
        '
        'mcCafeDrink4PictureBox
        '
        Me.mcCafeDrink4PictureBox.Image = CType(resources.GetObject("mcCafeDrink4PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeDrink4PictureBox.Location = New System.Drawing.Point(1056, 10)
        Me.mcCafeDrink4PictureBox.Name = "mcCafeDrink4PictureBox"
        Me.mcCafeDrink4PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeDrink4PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeDrink4PictureBox.TabIndex = 85
        Me.mcCafeDrink4PictureBox.TabStop = False
        '
        'mcCafeDrink5PictureBox
        '
        Me.mcCafeDrink5PictureBox.Image = CType(resources.GetObject("mcCafeDrink5PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeDrink5PictureBox.Location = New System.Drawing.Point(1360, 10)
        Me.mcCafeDrink5PictureBox.Name = "mcCafeDrink5PictureBox"
        Me.mcCafeDrink5PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeDrink5PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeDrink5PictureBox.TabIndex = 86
        Me.mcCafeDrink5PictureBox.TabStop = False
        '
        'mcCafeDrink4Label
        '
        Me.mcCafeDrink4Label.AutoSize = True
        Me.mcCafeDrink4Label.Location = New System.Drawing.Point(1053, 179)
        Me.mcCafeDrink4Label.Name = "mcCafeDrink4Label"
        Me.mcCafeDrink4Label.Size = New System.Drawing.Size(105, 17)
        Me.mcCafeDrink4Label.TabIndex = 87
        Me.mcCafeDrink4Label.Text = "Iced Americano"
        '
        'mcCafeDrinkPrice4Label
        '
        Me.mcCafeDrinkPrice4Label.AutoSize = True
        Me.mcCafeDrinkPrice4Label.Location = New System.Drawing.Point(1053, 196)
        Me.mcCafeDrinkPrice4Label.Name = "mcCafeDrinkPrice4Label"
        Me.mcCafeDrinkPrice4Label.Size = New System.Drawing.Size(93, 17)
        Me.mcCafeDrinkPrice4Label.TabIndex = 88
        Me.mcCafeDrinkPrice4Label.Text = "From RM8.96"
        '
        'mcCafeDrink5Label
        '
        Me.mcCafeDrink5Label.AutoSize = True
        Me.mcCafeDrink5Label.Location = New System.Drawing.Point(1357, 179)
        Me.mcCafeDrink5Label.Name = "mcCafeDrink5Label"
        Me.mcCafeDrink5Label.Size = New System.Drawing.Size(71, 17)
        Me.mcCafeDrink5Label.TabIndex = 89
        Me.mcCafeDrink5Label.Text = "Flat White"
        '
        'mcCafeDrinkPrice9Label
        '
        Me.mcCafeDrinkPrice9Label.AutoSize = True
        Me.mcCafeDrinkPrice9Label.Location = New System.Drawing.Point(1053, 436)
        Me.mcCafeDrinkPrice9Label.Name = "mcCafeDrinkPrice9Label"
        Me.mcCafeDrinkPrice9Label.Size = New System.Drawing.Size(93, 17)
        Me.mcCafeDrinkPrice9Label.TabIndex = 103
        Me.mcCafeDrinkPrice9Label.Text = "From RM4.72"
        '
        'mcCafeDrinkPrice8Label
        '
        Me.mcCafeDrinkPrice8Label.AutoSize = True
        Me.mcCafeDrinkPrice8Label.Location = New System.Drawing.Point(716, 436)
        Me.mcCafeDrinkPrice8Label.Name = "mcCafeDrinkPrice8Label"
        Me.mcCafeDrinkPrice8Label.Size = New System.Drawing.Size(93, 17)
        Me.mcCafeDrinkPrice8Label.TabIndex = 97
        Me.mcCafeDrinkPrice8Label.Text = "From RM7.54"
        '
        'mcCafeDrinkPrice7Label
        '
        Me.mcCafeDrinkPrice7Label.AutoSize = True
        Me.mcCafeDrinkPrice7Label.Location = New System.Drawing.Point(369, 436)
        Me.mcCafeDrinkPrice7Label.Name = "mcCafeDrinkPrice7Label"
        Me.mcCafeDrinkPrice7Label.Size = New System.Drawing.Size(93, 17)
        Me.mcCafeDrinkPrice7Label.TabIndex = 95
        Me.mcCafeDrinkPrice7Label.Text = "From RM7.54"
        '
        'mcCafeDrinkPrice6Label
        '
        Me.mcCafeDrinkPrice6Label.AutoSize = True
        Me.mcCafeDrinkPrice6Label.Location = New System.Drawing.Point(17, 436)
        Me.mcCafeDrinkPrice6Label.Name = "mcCafeDrinkPrice6Label"
        Me.mcCafeDrinkPrice6Label.Size = New System.Drawing.Size(93, 17)
        Me.mcCafeDrinkPrice6Label.TabIndex = 99
        Me.mcCafeDrinkPrice6Label.Text = "From RM7.54"
        '
        'mcCafeDrinkPrice5Label
        '
        Me.mcCafeDrinkPrice5Label.AutoSize = True
        Me.mcCafeDrinkPrice5Label.Location = New System.Drawing.Point(1357, 196)
        Me.mcCafeDrinkPrice5Label.Name = "mcCafeDrinkPrice5Label"
        Me.mcCafeDrinkPrice5Label.Size = New System.Drawing.Size(93, 17)
        Me.mcCafeDrinkPrice5Label.TabIndex = 90
        Me.mcCafeDrinkPrice5Label.Text = "From RM7.54"
        '
        'mcCafeDrink6Label
        '
        Me.mcCafeDrink6Label.AutoSize = True
        Me.mcCafeDrink6Label.Location = New System.Drawing.Point(17, 419)
        Me.mcCafeDrink6Label.Name = "mcCafeDrink6Label"
        Me.mcCafeDrink6Label.Size = New System.Drawing.Size(40, 17)
        Me.mcCafeDrink6Label.TabIndex = 98
        Me.mcCafeDrink6Label.Text = "Latte"
        '
        'mcCafeDrink6PictureBox
        '
        Me.mcCafeDrink6PictureBox.Image = CType(resources.GetObject("mcCafeDrink6PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeDrink6PictureBox.Location = New System.Drawing.Point(16, 250)
        Me.mcCafeDrink6PictureBox.Name = "mcCafeDrink6PictureBox"
        Me.mcCafeDrink6PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeDrink6PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeDrink6PictureBox.TabIndex = 91
        Me.mcCafeDrink6PictureBox.TabStop = False
        '
        'mcCafeDrink9Label
        '
        Me.mcCafeDrink9Label.AutoSize = True
        Me.mcCafeDrink9Label.Location = New System.Drawing.Point(1053, 419)
        Me.mcCafeDrink9Label.Name = "mcCafeDrink9Label"
        Me.mcCafeDrink9Label.Size = New System.Drawing.Size(149, 17)
        Me.mcCafeDrink9Label.TabIndex = 102
        Me.mcCafeDrink9Label.Text = "Premium Roast Coffee"
        '
        'mcCafeDrink7PictureBox
        '
        Me.mcCafeDrink7PictureBox.Image = CType(resources.GetObject("mcCafeDrink7PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeDrink7PictureBox.Location = New System.Drawing.Point(369, 250)
        Me.mcCafeDrink7PictureBox.Name = "mcCafeDrink7PictureBox"
        Me.mcCafeDrink7PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeDrink7PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeDrink7PictureBox.TabIndex = 92
        Me.mcCafeDrink7PictureBox.TabStop = False
        '
        'mcCafeDrink8PictureBox
        '
        Me.mcCafeDrink8PictureBox.Image = CType(resources.GetObject("mcCafeDrink8PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeDrink8PictureBox.Location = New System.Drawing.Point(719, 250)
        Me.mcCafeDrink8PictureBox.Name = "mcCafeDrink8PictureBox"
        Me.mcCafeDrink8PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeDrink8PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeDrink8PictureBox.TabIndex = 93
        Me.mcCafeDrink8PictureBox.TabStop = False
        '
        'mcCafeDrink9PictureBox
        '
        Me.mcCafeDrink9PictureBox.Image = CType(resources.GetObject("mcCafeDrink9PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeDrink9PictureBox.Location = New System.Drawing.Point(1056, 250)
        Me.mcCafeDrink9PictureBox.Name = "mcCafeDrink9PictureBox"
        Me.mcCafeDrink9PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeDrink9PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeDrink9PictureBox.TabIndex = 100
        Me.mcCafeDrink9PictureBox.TabStop = False
        '
        'mcCafeDrink7Label
        '
        Me.mcCafeDrink7Label.AutoSize = True
        Me.mcCafeDrink7Label.Location = New System.Drawing.Point(369, 419)
        Me.mcCafeDrink7Label.Name = "mcCafeDrink7Label"
        Me.mcCafeDrink7Label.Size = New System.Drawing.Size(82, 17)
        Me.mcCafeDrink7Label.TabIndex = 94
        Me.mcCafeDrink7Label.Text = "Cappuccino"
        '
        'mcCafeDrink8Label
        '
        Me.mcCafeDrink8Label.AutoSize = True
        Me.mcCafeDrink8Label.Location = New System.Drawing.Point(716, 419)
        Me.mcCafeDrink8Label.Name = "mcCafeDrink8Label"
        Me.mcCafeDrink8Label.Size = New System.Drawing.Size(75, 17)
        Me.mcCafeDrink8Label.TabIndex = 96
        Me.mcCafeDrink8Label.Text = "Americano"
        '
        'McCafeDrink
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.mcCafeDrinkPanel)
        Me.Controls.Add(Me.mcCafeDrinkLabel)
        Me.Name = "McCafeDrink"
        Me.Size = New System.Drawing.Size(1676, 1038)
        Me.mcCafeDrinkPanel.ResumeLayout(False)
        Me.mcCafeDrinkPanel.PerformLayout()
        CType(Me.mcCafeDrink1PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeDrink2PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeDrink3PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeDrink10PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeDrink13PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeDrink12PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeDrink11PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeDrink4PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeDrink5PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeDrink6PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeDrink7PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeDrink8PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeDrink9PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents mcCafeDrinkLabel As Label
    Friend WithEvents mcCafeDrinkPanel As Panel
    Friend WithEvents mcCafeDrink1PictureBox As PictureBox
    Friend WithEvents mcCafeDrinkPrice11Label As Label
    Friend WithEvents mcCafeDrinkPrice10Label As Label
    Friend WithEvents mcCafeDrink11Label As Label
    Friend WithEvents mcCafeDrink2PictureBox As PictureBox
    Friend WithEvents mcCafeDrinkPrice13Label As Label
    Friend WithEvents mcCafeDrink10Label As Label
    Friend WithEvents mcCafeDrink13Label As Label
    Friend WithEvents mcCafeDrink3PictureBox As PictureBox
    Friend WithEvents mcCafeDrinkPrice12Label As Label
    Friend WithEvents mcCafeDrink10PictureBox As PictureBox
    Friend WithEvents mcCafeDrink12Label As Label
    Friend WithEvents mcCafeDrink2Label As Label
    Friend WithEvents mcCafeDrink13PictureBox As PictureBox
    Friend WithEvents mcCafeDrinkPrice2Label As Label
    Friend WithEvents mcCafeDrink12PictureBox As PictureBox
    Friend WithEvents mcCafeDrink3Label As Label
    Friend WithEvents mcCafeDrink11PictureBox As PictureBox
    Friend WithEvents mcCafeDrinkPrice3Label As Label
    Friend WithEvents mcCafeDrink1Label As Label
    Friend WithEvents mcCafeDrinkPrice1Label As Label
    Friend WithEvents mcCafeDrink4PictureBox As PictureBox
    Friend WithEvents mcCafeDrink5PictureBox As PictureBox
    Friend WithEvents mcCafeDrink4Label As Label
    Friend WithEvents mcCafeDrinkPrice4Label As Label
    Friend WithEvents mcCafeDrink5Label As Label
    Friend WithEvents mcCafeDrinkPrice9Label As Label
    Friend WithEvents mcCafeDrinkPrice8Label As Label
    Friend WithEvents mcCafeDrinkPrice7Label As Label
    Friend WithEvents mcCafeDrinkPrice6Label As Label
    Friend WithEvents mcCafeDrinkPrice5Label As Label
    Friend WithEvents mcCafeDrink6Label As Label
    Friend WithEvents mcCafeDrink6PictureBox As PictureBox
    Friend WithEvents mcCafeDrink9Label As Label
    Friend WithEvents mcCafeDrink7PictureBox As PictureBox
    Friend WithEvents mcCafeDrink8PictureBox As PictureBox
    Friend WithEvents mcCafeDrink9PictureBox As PictureBox
    Friend WithEvents mcCafeDrink7Label As Label
    Friend WithEvents mcCafeDrink8Label As Label
End Class
