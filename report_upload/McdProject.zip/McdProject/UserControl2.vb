﻿Public Class UserControl2
    Private Sub Label22_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Application.Exit()
    End Sub
End Class
