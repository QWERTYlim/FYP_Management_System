﻿Public Class UserControl1
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox13_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox12_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox2_Click_1(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox11_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox15_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox14_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label28_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label27_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label26_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label25_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label23_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label24_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label21_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label22_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label29_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label30_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label19_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label12_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label11_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label13_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label14_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label16_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label15_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub UserControl1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label18_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label17_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label20_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Application.Exit()
    End Sub

    Public Sub mcChickenSVMPictureBox_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox1_Click_1(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Form2.Show()
    End Sub
End Class
