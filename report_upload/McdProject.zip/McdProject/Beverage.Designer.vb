﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Beverage
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Beverage))
        Me.beverageLabel = New System.Windows.Forms.Label()
        Me.beveragePanel = New System.Windows.Forms.Panel()
        Me.beverage1PriceLabel = New System.Windows.Forms.Label()
        Me.beverage11PriceLabelLabel = New System.Windows.Forms.Label()
        Me.beverage6PriceLabel = New System.Windows.Forms.Label()
        Me.beverage11Label = New System.Windows.Forms.Label()
        Me.beverage1Label = New System.Windows.Forms.Label()
        Me.beverage11PictureBox = New System.Windows.Forms.PictureBox()
        Me.beverage5PictureBox = New System.Windows.Forms.PictureBox()
        Me.beverage10PriceLabel = New System.Windows.Forms.Label()
        Me.beverage2Label = New System.Windows.Forms.Label()
        Me.beverage10Label = New System.Windows.Forms.Label()
        Me.beverage2PriceLabel = New System.Windows.Forms.Label()
        Me.beverage3Label = New System.Windows.Forms.Label()
        Me.beverage3PriceLabel = New System.Windows.Forms.Label()
        Me.beverage9PriceLabel = New System.Windows.Forms.Label()
        Me.beverage10PictureBox = New System.Windows.Forms.PictureBox()
        Me.beverage9Label = New System.Windows.Forms.Label()
        Me.beverage6Label = New System.Windows.Forms.Label()
        Me.beverage4PictureBox = New System.Windows.Forms.PictureBox()
        Me.beverage8PriceLabel = New System.Windows.Forms.Label()
        Me.beverage4Label = New System.Windows.Forms.Label()
        Me.beverage8Label = New System.Windows.Forms.Label()
        Me.beverage3PictureBox = New System.Windows.Forms.PictureBox()
        Me.beverage7PriceLabel = New System.Windows.Forms.Label()
        Me.beverage9PictureBox = New System.Windows.Forms.PictureBox()
        Me.beverage7Label = New System.Windows.Forms.Label()
        Me.beverage4PriceLabel = New System.Windows.Forms.Label()
        Me.beverage2PictureBox = New System.Windows.Forms.PictureBox()
        Me.beverage6PictureBox = New System.Windows.Forms.PictureBox()
        Me.beverage5Label = New System.Windows.Forms.Label()
        Me.beverage1PictureBox = New System.Windows.Forms.PictureBox()
        Me.beverage5PriceLabel = New System.Windows.Forms.Label()
        Me.beverage8PictureBox = New System.Windows.Forms.PictureBox()
        Me.beverage7PictureBox = New System.Windows.Forms.PictureBox()
        Me.beveragePanel.SuspendLayout()
        CType(Me.beverage11PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.beverage5PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.beverage10PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.beverage4PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.beverage3PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.beverage9PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.beverage2PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.beverage6PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.beverage1PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.beverage8PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.beverage7PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'beverageLabel
        '
        Me.beverageLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.beverageLabel.Font = New System.Drawing.Font("Segoe UI", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.beverageLabel.Location = New System.Drawing.Point(3, 10)
        Me.beverageLabel.Name = "beverageLabel"
        Me.beverageLabel.Size = New System.Drawing.Size(1670, 99)
        Me.beverageLabel.TabIndex = 131
        Me.beverageLabel.Text = "Beverage"
        '
        'beveragePanel
        '
        Me.beveragePanel.AutoScroll = True
        Me.beveragePanel.Controls.Add(Me.beverage1PriceLabel)
        Me.beveragePanel.Controls.Add(Me.beverage11PriceLabelLabel)
        Me.beveragePanel.Controls.Add(Me.beverage6PriceLabel)
        Me.beveragePanel.Controls.Add(Me.beverage11Label)
        Me.beveragePanel.Controls.Add(Me.beverage1Label)
        Me.beveragePanel.Controls.Add(Me.beverage11PictureBox)
        Me.beveragePanel.Controls.Add(Me.beverage5PictureBox)
        Me.beveragePanel.Controls.Add(Me.beverage10PriceLabel)
        Me.beveragePanel.Controls.Add(Me.beverage2Label)
        Me.beveragePanel.Controls.Add(Me.beverage10Label)
        Me.beveragePanel.Controls.Add(Me.beverage2PriceLabel)
        Me.beveragePanel.Controls.Add(Me.beverage3Label)
        Me.beveragePanel.Controls.Add(Me.beverage3PriceLabel)
        Me.beveragePanel.Controls.Add(Me.beverage9PriceLabel)
        Me.beveragePanel.Controls.Add(Me.beverage10PictureBox)
        Me.beveragePanel.Controls.Add(Me.beverage9Label)
        Me.beveragePanel.Controls.Add(Me.beverage6Label)
        Me.beveragePanel.Controls.Add(Me.beverage4PictureBox)
        Me.beveragePanel.Controls.Add(Me.beverage8PriceLabel)
        Me.beveragePanel.Controls.Add(Me.beverage4Label)
        Me.beveragePanel.Controls.Add(Me.beverage8Label)
        Me.beveragePanel.Controls.Add(Me.beverage3PictureBox)
        Me.beveragePanel.Controls.Add(Me.beverage7PriceLabel)
        Me.beveragePanel.Controls.Add(Me.beverage9PictureBox)
        Me.beveragePanel.Controls.Add(Me.beverage7Label)
        Me.beveragePanel.Controls.Add(Me.beverage4PriceLabel)
        Me.beveragePanel.Controls.Add(Me.beverage2PictureBox)
        Me.beveragePanel.Controls.Add(Me.beverage6PictureBox)
        Me.beveragePanel.Controls.Add(Me.beverage5Label)
        Me.beveragePanel.Controls.Add(Me.beverage1PictureBox)
        Me.beveragePanel.Controls.Add(Me.beverage5PriceLabel)
        Me.beveragePanel.Controls.Add(Me.beverage8PictureBox)
        Me.beveragePanel.Controls.Add(Me.beverage7PictureBox)
        Me.beveragePanel.Location = New System.Drawing.Point(12, 112)
        Me.beveragePanel.Name = "beveragePanel"
        Me.beveragePanel.Size = New System.Drawing.Size(1650, 625)
        Me.beveragePanel.TabIndex = 185
        '
        'beverage1PriceLabel
        '
        Me.beverage1PriceLabel.AutoSize = True
        Me.beverage1PriceLabel.Location = New System.Drawing.Point(13, 196)
        Me.beverage1PriceLabel.Name = "beverage1PriceLabel"
        Me.beverage1PriceLabel.Size = New System.Drawing.Size(93, 17)
        Me.beverage1PriceLabel.TabIndex = 185
        Me.beverage1PriceLabel.Text = "From RM4.53"
        '
        'beverage11PriceLabelLabel
        '
        Me.beverage11PriceLabelLabel.AutoSize = True
        Me.beverage11PriceLabelLabel.Location = New System.Drawing.Point(13, 683)
        Me.beverage11PriceLabelLabel.Name = "beverage11PriceLabelLabel"
        Me.beverage11PriceLabelLabel.Size = New System.Drawing.Size(93, 17)
        Me.beverage11PriceLabelLabel.TabIndex = 181
        Me.beverage11PriceLabelLabel.Text = "From RM4.72"
        '
        'beverage6PriceLabel
        '
        Me.beverage6PriceLabel.AutoSize = True
        Me.beverage6PriceLabel.Location = New System.Drawing.Point(21, 436)
        Me.beverage6PriceLabel.Name = "beverage6PriceLabel"
        Me.beverage6PriceLabel.Size = New System.Drawing.Size(93, 17)
        Me.beverage6PriceLabel.TabIndex = 182
        Me.beverage6PriceLabel.Text = "From RM4.53"
        '
        'beverage11Label
        '
        Me.beverage11Label.AutoSize = True
        Me.beverage11Label.Location = New System.Drawing.Point(13, 666)
        Me.beverage11Label.Name = "beverage11Label"
        Me.beverage11Label.Size = New System.Drawing.Size(149, 17)
        Me.beverage11Label.TabIndex = 175
        Me.beverage11Label.Text = "Premium Roast Coffee"
        '
        'beverage1Label
        '
        Me.beverage1Label.AutoSize = True
        Me.beverage1Label.Location = New System.Drawing.Point(13, 179)
        Me.beverage1Label.Name = "beverage1Label"
        Me.beverage1Label.Size = New System.Drawing.Size(63, 17)
        Me.beverage1Label.TabIndex = 184
        Me.beverage1Label.Text = "100 Plus"
        '
        'beverage11PictureBox
        '
        Me.beverage11PictureBox.Image = CType(resources.GetObject("beverage11PictureBox.Image"), System.Drawing.Image)
        Me.beverage11PictureBox.Location = New System.Drawing.Point(16, 497)
        Me.beverage11PictureBox.Name = "beverage11PictureBox"
        Me.beverage11PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.beverage11PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.beverage11PictureBox.TabIndex = 174
        Me.beverage11PictureBox.TabStop = False
        '
        'beverage5PictureBox
        '
        Me.beverage5PictureBox.Image = CType(resources.GetObject("beverage5PictureBox.Image"), System.Drawing.Image)
        Me.beverage5PictureBox.Location = New System.Drawing.Point(1360, 10)
        Me.beverage5PictureBox.Name = "beverage5PictureBox"
        Me.beverage5PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.beverage5PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.beverage5PictureBox.TabIndex = 180
        Me.beverage5PictureBox.TabStop = False
        '
        'beverage10PriceLabel
        '
        Me.beverage10PriceLabel.AutoSize = True
        Me.beverage10PriceLabel.Location = New System.Drawing.Point(1357, 436)
        Me.beverage10PriceLabel.Name = "beverage10PriceLabel"
        Me.beverage10PriceLabel.Size = New System.Drawing.Size(93, 17)
        Me.beverage10PriceLabel.TabIndex = 173
        Me.beverage10PriceLabel.Text = "From RM4.72"
        '
        'beverage2Label
        '
        Me.beverage2Label.AutoSize = True
        Me.beverage2Label.Location = New System.Drawing.Point(369, 179)
        Me.beverage2Label.Name = "beverage2Label"
        Me.beverage2Label.Size = New System.Drawing.Size(83, 17)
        Me.beverage2Label.TabIndex = 151
        Me.beverage2Label.Text = "Coca-Cola®"
        '
        'beverage10Label
        '
        Me.beverage10Label.AutoSize = True
        Me.beverage10Label.Location = New System.Drawing.Point(1357, 419)
        Me.beverage10Label.Name = "beverage10Label"
        Me.beverage10Label.Size = New System.Drawing.Size(59, 17)
        Me.beverage10Label.TabIndex = 172
        Me.beverage10Label.Text = "Hot Tea"
        '
        'beverage2PriceLabel
        '
        Me.beverage2PriceLabel.AutoSize = True
        Me.beverage2PriceLabel.Location = New System.Drawing.Point(369, 196)
        Me.beverage2PriceLabel.Name = "beverage2PriceLabel"
        Me.beverage2PriceLabel.Size = New System.Drawing.Size(93, 17)
        Me.beverage2PriceLabel.TabIndex = 152
        Me.beverage2PriceLabel.Text = "From RM4.53"
        '
        'beverage3Label
        '
        Me.beverage3Label.AutoSize = True
        Me.beverage3Label.Location = New System.Drawing.Point(719, 179)
        Me.beverage3Label.Name = "beverage3Label"
        Me.beverage3Label.Size = New System.Drawing.Size(55, 17)
        Me.beverage3Label.TabIndex = 153
        Me.beverage3Label.Text = "Sprite®"
        '
        'beverage3PriceLabel
        '
        Me.beverage3PriceLabel.AutoSize = True
        Me.beverage3PriceLabel.Location = New System.Drawing.Point(719, 196)
        Me.beverage3PriceLabel.Name = "beverage3PriceLabel"
        Me.beverage3PriceLabel.Size = New System.Drawing.Size(93, 17)
        Me.beverage3PriceLabel.TabIndex = 154
        Me.beverage3PriceLabel.Text = "From RM4.53"
        '
        'beverage9PriceLabel
        '
        Me.beverage9PriceLabel.AutoSize = True
        Me.beverage9PriceLabel.Location = New System.Drawing.Point(1055, 436)
        Me.beverage9PriceLabel.Name = "beverage9PriceLabel"
        Me.beverage9PriceLabel.Size = New System.Drawing.Size(93, 17)
        Me.beverage9PriceLabel.TabIndex = 170
        Me.beverage9PriceLabel.Text = "From RM4.72"
        '
        'beverage10PictureBox
        '
        Me.beverage10PictureBox.Image = CType(resources.GetObject("beverage10PictureBox.Image"), System.Drawing.Image)
        Me.beverage10PictureBox.Location = New System.Drawing.Point(1360, 250)
        Me.beverage10PictureBox.Name = "beverage10PictureBox"
        Me.beverage10PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.beverage10PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.beverage10PictureBox.TabIndex = 171
        Me.beverage10PictureBox.TabStop = False
        '
        'beverage9Label
        '
        Me.beverage9Label.AutoSize = True
        Me.beverage9Label.Location = New System.Drawing.Point(1053, 419)
        Me.beverage9Label.Name = "beverage9Label"
        Me.beverage9Label.Size = New System.Drawing.Size(95, 17)
        Me.beverage9Label.TabIndex = 169
        Me.beverage9Label.Text = "Hot Teh Tarik"
        '
        'beverage6Label
        '
        Me.beverage6Label.AutoSize = True
        Me.beverage6Label.Location = New System.Drawing.Point(18, 419)
        Me.beverage6Label.Name = "beverage6Label"
        Me.beverage6Label.Size = New System.Drawing.Size(98, 17)
        Me.beverage6Label.TabIndex = 167
        Me.beverage6Label.Text = "Drinking water"
        '
        'beverage4PictureBox
        '
        Me.beverage4PictureBox.Image = CType(resources.GetObject("beverage4PictureBox.Image"), System.Drawing.Image)
        Me.beverage4PictureBox.Location = New System.Drawing.Point(1056, 10)
        Me.beverage4PictureBox.Name = "beverage4PictureBox"
        Me.beverage4PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.beverage4PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.beverage4PictureBox.TabIndex = 179
        Me.beverage4PictureBox.TabStop = False
        '
        'beverage8PriceLabel
        '
        Me.beverage8PriceLabel.AutoSize = True
        Me.beverage8PriceLabel.Location = New System.Drawing.Point(719, 436)
        Me.beverage8PriceLabel.Name = "beverage8PriceLabel"
        Me.beverage8PriceLabel.Size = New System.Drawing.Size(93, 17)
        Me.beverage8PriceLabel.TabIndex = 166
        Me.beverage8PriceLabel.Text = "From RM4.53"
        '
        'beverage4Label
        '
        Me.beverage4Label.AutoSize = True
        Me.beverage4Label.Location = New System.Drawing.Point(1053, 179)
        Me.beverage4Label.Name = "beverage4Label"
        Me.beverage4Label.Size = New System.Drawing.Size(110, 17)
        Me.beverage4Label.TabIndex = 156
        Me.beverage4Label.Text = "Iced Lemon Tea"
        '
        'beverage8Label
        '
        Me.beverage8Label.AutoSize = True
        Me.beverage8Label.Location = New System.Drawing.Point(719, 419)
        Me.beverage8Label.Name = "beverage8Label"
        Me.beverage8Label.Size = New System.Drawing.Size(77, 17)
        Me.beverage8Label.TabIndex = 165
        Me.beverage8Label.Text = "Hot MILO®"
        '
        'beverage3PictureBox
        '
        Me.beverage3PictureBox.Image = CType(resources.GetObject("beverage3PictureBox.Image"), System.Drawing.Image)
        Me.beverage3PictureBox.Location = New System.Drawing.Point(719, 10)
        Me.beverage3PictureBox.Name = "beverage3PictureBox"
        Me.beverage3PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.beverage3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.beverage3PictureBox.TabIndex = 178
        Me.beverage3PictureBox.TabStop = False
        '
        'beverage7PriceLabel
        '
        Me.beverage7PriceLabel.AutoSize = True
        Me.beverage7PriceLabel.Location = New System.Drawing.Point(372, 436)
        Me.beverage7PriceLabel.Name = "beverage7PriceLabel"
        Me.beverage7PriceLabel.Size = New System.Drawing.Size(93, 17)
        Me.beverage7PriceLabel.TabIndex = 164
        Me.beverage7PriceLabel.Text = "From RM7.08"
        '
        'beverage9PictureBox
        '
        Me.beverage9PictureBox.Image = CType(resources.GetObject("beverage9PictureBox.Image"), System.Drawing.Image)
        Me.beverage9PictureBox.Location = New System.Drawing.Point(1056, 250)
        Me.beverage9PictureBox.Name = "beverage9PictureBox"
        Me.beverage9PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.beverage9PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.beverage9PictureBox.TabIndex = 168
        Me.beverage9PictureBox.TabStop = False
        '
        'beverage7Label
        '
        Me.beverage7Label.AutoSize = True
        Me.beverage7Label.Location = New System.Drawing.Point(372, 419)
        Me.beverage7Label.Name = "beverage7Label"
        Me.beverage7Label.Size = New System.Drawing.Size(51, 17)
        Me.beverage7Label.TabIndex = 163
        Me.beverage7Label.Text = "MILO®"
        '
        'beverage4PriceLabel
        '
        Me.beverage4PriceLabel.AutoSize = True
        Me.beverage4PriceLabel.Location = New System.Drawing.Point(1053, 196)
        Me.beverage4PriceLabel.Name = "beverage4PriceLabel"
        Me.beverage4PriceLabel.Size = New System.Drawing.Size(93, 17)
        Me.beverage4PriceLabel.TabIndex = 157
        Me.beverage4PriceLabel.Text = "From RM5.94"
        '
        'beverage2PictureBox
        '
        Me.beverage2PictureBox.Image = CType(resources.GetObject("beverage2PictureBox.Image"), System.Drawing.Image)
        Me.beverage2PictureBox.Location = New System.Drawing.Point(369, 10)
        Me.beverage2PictureBox.Name = "beverage2PictureBox"
        Me.beverage2PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.beverage2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.beverage2PictureBox.TabIndex = 177
        Me.beverage2PictureBox.TabStop = False
        '
        'beverage6PictureBox
        '
        Me.beverage6PictureBox.Image = CType(resources.GetObject("beverage6PictureBox.Image"), System.Drawing.Image)
        Me.beverage6PictureBox.Location = New System.Drawing.Point(16, 250)
        Me.beverage6PictureBox.Name = "beverage6PictureBox"
        Me.beverage6PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.beverage6PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.beverage6PictureBox.TabIndex = 160
        Me.beverage6PictureBox.TabStop = False
        '
        'beverage5Label
        '
        Me.beverage5Label.AutoSize = True
        Me.beverage5Label.Location = New System.Drawing.Point(1357, 179)
        Me.beverage5Label.Name = "beverage5Label"
        Me.beverage5Label.Size = New System.Drawing.Size(147, 17)
        Me.beverage5Label.TabIndex = 158
        Me.beverage5Label.Text = "Banana Walnut Muffin"
        '
        'beverage1PictureBox
        '
        Me.beverage1PictureBox.Image = CType(resources.GetObject("beverage1PictureBox.Image"), System.Drawing.Image)
        Me.beverage1PictureBox.Location = New System.Drawing.Point(12, 10)
        Me.beverage1PictureBox.Name = "beverage1PictureBox"
        Me.beverage1PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.beverage1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.beverage1PictureBox.TabIndex = 176
        Me.beverage1PictureBox.TabStop = False
        '
        'beverage5PriceLabel
        '
        Me.beverage5PriceLabel.AutoSize = True
        Me.beverage5PriceLabel.Location = New System.Drawing.Point(1357, 196)
        Me.beverage5PriceLabel.Name = "beverage5PriceLabel"
        Me.beverage5PriceLabel.Size = New System.Drawing.Size(93, 17)
        Me.beverage5PriceLabel.TabIndex = 159
        Me.beverage5PriceLabel.Text = "From RM6.13"
        '
        'beverage8PictureBox
        '
        Me.beverage8PictureBox.Image = CType(resources.GetObject("beverage8PictureBox.Image"), System.Drawing.Image)
        Me.beverage8PictureBox.Location = New System.Drawing.Point(719, 250)
        Me.beverage8PictureBox.Name = "beverage8PictureBox"
        Me.beverage8PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.beverage8PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.beverage8PictureBox.TabIndex = 162
        Me.beverage8PictureBox.TabStop = False
        '
        'beverage7PictureBox
        '
        Me.beverage7PictureBox.Image = CType(resources.GetObject("beverage7PictureBox.Image"), System.Drawing.Image)
        Me.beverage7PictureBox.Location = New System.Drawing.Point(369, 250)
        Me.beverage7PictureBox.Name = "beverage7PictureBox"
        Me.beverage7PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.beverage7PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.beverage7PictureBox.TabIndex = 161
        Me.beverage7PictureBox.TabStop = False
        '
        'Beverage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.beveragePanel)
        Me.Controls.Add(Me.beverageLabel)
        Me.Name = "Beverage"
        Me.Size = New System.Drawing.Size(1676, 1038)
        Me.beveragePanel.ResumeLayout(False)
        Me.beveragePanel.PerformLayout()
        CType(Me.beverage11PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.beverage5PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.beverage10PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.beverage4PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.beverage3PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.beverage9PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.beverage2PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.beverage6PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.beverage1PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.beverage8PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.beverage7PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents beverageLabel As Label
    Friend WithEvents beveragePanel As Panel
    Friend WithEvents beverage1PriceLabel As Label
    Friend WithEvents beverage11PriceLabelLabel As Label
    Friend WithEvents beverage6PriceLabel As Label
    Friend WithEvents beverage11Label As Label
    Friend WithEvents beverage1Label As Label
    Friend WithEvents beverage11PictureBox As PictureBox
    Friend WithEvents beverage5PictureBox As PictureBox
    Friend WithEvents beverage10PriceLabel As Label
    Friend WithEvents beverage2Label As Label
    Friend WithEvents beverage10Label As Label
    Friend WithEvents beverage2PriceLabel As Label
    Friend WithEvents beverage3Label As Label
    Friend WithEvents beverage3PriceLabel As Label
    Friend WithEvents beverage9PriceLabel As Label
    Friend WithEvents beverage10PictureBox As PictureBox
    Friend WithEvents beverage9Label As Label
    Friend WithEvents beverage6Label As Label
    Friend WithEvents beverage4PictureBox As PictureBox
    Friend WithEvents beverage8PriceLabel As Label
    Friend WithEvents beverage4Label As Label
    Friend WithEvents beverage8Label As Label
    Friend WithEvents beverage3PictureBox As PictureBox
    Friend WithEvents beverage7PriceLabel As Label
    Friend WithEvents beverage9PictureBox As PictureBox
    Friend WithEvents beverage7Label As Label
    Friend WithEvents beverage4PriceLabel As Label
    Friend WithEvents beverage2PictureBox As PictureBox
    Friend WithEvents beverage6PictureBox As PictureBox
    Friend WithEvents beverage5Label As Label
    Friend WithEvents beverage1PictureBox As PictureBox
    Friend WithEvents beverage5PriceLabel As Label
    Friend WithEvents beverage8PictureBox As PictureBox
    Friend WithEvents beverage7PictureBox As PictureBox
End Class
