﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class HappyMeal
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(HappyMeal))
        Me.happyMealLabel = New System.Windows.Forms.Label()
        Me.happyMealPanel = New System.Windows.Forms.Panel()
        Me.happyMeal6PriceLabel = New System.Windows.Forms.Label()
        Me.happyMeal6PictureBox = New System.Windows.Forms.PictureBox()
        Me.happyMeal6Label = New System.Windows.Forms.Label()
        Me.happyMeal5PictureBox = New System.Windows.Forms.PictureBox()
        Me.happyMeal2Label = New System.Windows.Forms.Label()
        Me.happyMeal2PriceLabel = New System.Windows.Forms.Label()
        Me.happyMeal3Label = New System.Windows.Forms.Label()
        Me.happyMeal1PriceLabel = New System.Windows.Forms.Label()
        Me.happyMeal3PriceLabel = New System.Windows.Forms.Label()
        Me.happyMeal1Label = New System.Windows.Forms.Label()
        Me.happyMeal4PictureBox = New System.Windows.Forms.PictureBox()
        Me.happyMeal4Label = New System.Windows.Forms.Label()
        Me.happyMeal3PictureBox = New System.Windows.Forms.PictureBox()
        Me.happyMeal4PriceLabel = New System.Windows.Forms.Label()
        Me.happyMeal2PictureBox = New System.Windows.Forms.PictureBox()
        Me.happyMeal5Label = New System.Windows.Forms.Label()
        Me.happyMeal1PictureBox = New System.Windows.Forms.PictureBox()
        Me.happyMeal5PriceLabel = New System.Windows.Forms.Label()
        Me.happyMealPanel.SuspendLayout()
        CType(Me.happyMeal6PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.happyMeal5PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.happyMeal4PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.happyMeal3PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.happyMeal2PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.happyMeal1PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'happyMealLabel
        '
        Me.happyMealLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.happyMealLabel.Font = New System.Drawing.Font("Segoe UI", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.happyMealLabel.Location = New System.Drawing.Point(3, 10)
        Me.happyMealLabel.Name = "happyMealLabel"
        Me.happyMealLabel.Size = New System.Drawing.Size(1670, 99)
        Me.happyMealLabel.TabIndex = 133
        Me.happyMealLabel.Text = "Happy Meal"
        '
        'happyMealPanel
        '
        Me.happyMealPanel.Controls.Add(Me.happyMeal6PriceLabel)
        Me.happyMealPanel.Controls.Add(Me.happyMeal6PictureBox)
        Me.happyMealPanel.Controls.Add(Me.happyMeal6Label)
        Me.happyMealPanel.Controls.Add(Me.happyMeal5PictureBox)
        Me.happyMealPanel.Controls.Add(Me.happyMeal2Label)
        Me.happyMealPanel.Controls.Add(Me.happyMeal2PriceLabel)
        Me.happyMealPanel.Controls.Add(Me.happyMeal3Label)
        Me.happyMealPanel.Controls.Add(Me.happyMeal1PriceLabel)
        Me.happyMealPanel.Controls.Add(Me.happyMeal3PriceLabel)
        Me.happyMealPanel.Controls.Add(Me.happyMeal1Label)
        Me.happyMealPanel.Controls.Add(Me.happyMeal4PictureBox)
        Me.happyMealPanel.Controls.Add(Me.happyMeal4Label)
        Me.happyMealPanel.Controls.Add(Me.happyMeal3PictureBox)
        Me.happyMealPanel.Controls.Add(Me.happyMeal4PriceLabel)
        Me.happyMealPanel.Controls.Add(Me.happyMeal2PictureBox)
        Me.happyMealPanel.Controls.Add(Me.happyMeal5Label)
        Me.happyMealPanel.Controls.Add(Me.happyMeal1PictureBox)
        Me.happyMealPanel.Controls.Add(Me.happyMeal5PriceLabel)
        Me.happyMealPanel.Location = New System.Drawing.Point(12, 112)
        Me.happyMealPanel.Name = "happyMealPanel"
        Me.happyMealPanel.Size = New System.Drawing.Size(1650, 521)
        Me.happyMealPanel.TabIndex = 218
        '
        'happyMeal6PriceLabel
        '
        Me.happyMeal6PriceLabel.AutoSize = True
        Me.happyMeal6PriceLabel.Location = New System.Drawing.Point(15, 435)
        Me.happyMeal6PriceLabel.Name = "happyMeal6PriceLabel"
        Me.happyMeal6PriceLabel.Size = New System.Drawing.Size(101, 17)
        Me.happyMeal6PriceLabel.TabIndex = 219
        Me.happyMeal6PriceLabel.Text = "From RM10.37"
        '
        'happyMeal6PictureBox
        '
        Me.happyMeal6PictureBox.Image = CType(resources.GetObject("happyMeal6PictureBox.Image"), System.Drawing.Image)
        Me.happyMeal6PictureBox.Location = New System.Drawing.Point(16, 250)
        Me.happyMeal6PictureBox.Name = "happyMeal6PictureBox"
        Me.happyMeal6PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.happyMeal6PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.happyMeal6PictureBox.TabIndex = 218
        Me.happyMeal6PictureBox.TabStop = False
        '
        'happyMeal6Label
        '
        Me.happyMeal6Label.AutoSize = True
        Me.happyMeal6Label.Location = New System.Drawing.Point(14, 418)
        Me.happyMeal6Label.Name = "happyMeal6Label"
        Me.happyMeal6Label.Size = New System.Drawing.Size(127, 17)
        Me.happyMeal6Label.TabIndex = 217
        Me.happyMeal6Label.Text = "Bubur Ayam McD™"
        '
        'happyMeal5PictureBox
        '
        Me.happyMeal5PictureBox.Image = CType(resources.GetObject("happyMeal5PictureBox.Image"), System.Drawing.Image)
        Me.happyMeal5PictureBox.Location = New System.Drawing.Point(1360, 10)
        Me.happyMeal5PictureBox.Name = "happyMeal5PictureBox"
        Me.happyMeal5PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.happyMeal5PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.happyMeal5PictureBox.TabIndex = 212
        Me.happyMeal5PictureBox.TabStop = False
        '
        'happyMeal2Label
        '
        Me.happyMeal2Label.AutoSize = True
        Me.happyMeal2Label.Location = New System.Drawing.Point(372, 179)
        Me.happyMeal2Label.Name = "happyMeal2Label"
        Me.happyMeal2Label.Size = New System.Drawing.Size(177, 17)
        Me.happyMeal2Label.TabIndex = 199
        Me.happyMeal2Label.Text = "4pcs Chicken McNuggets®"
        '
        'happyMeal2PriceLabel
        '
        Me.happyMeal2PriceLabel.AutoSize = True
        Me.happyMeal2PriceLabel.Location = New System.Drawing.Point(372, 196)
        Me.happyMeal2PriceLabel.Name = "happyMeal2PriceLabel"
        Me.happyMeal2PriceLabel.Size = New System.Drawing.Size(101, 17)
        Me.happyMeal2PriceLabel.TabIndex = 200
        Me.happyMeal2PriceLabel.Text = "From RM10.37"
        '
        'happyMeal3Label
        '
        Me.happyMeal3Label.AutoSize = True
        Me.happyMeal3Label.Location = New System.Drawing.Point(718, 179)
        Me.happyMeal3Label.Name = "happyMeal3Label"
        Me.happyMeal3Label.Size = New System.Drawing.Size(137, 17)
        Me.happyMeal3Label.TabIndex = 201
        Me.happyMeal3Label.Text = "Ayam Goreng McD™"
        '
        'happyMeal1PriceLabel
        '
        Me.happyMeal1PriceLabel.AutoSize = True
        Me.happyMeal1PriceLabel.Location = New System.Drawing.Point(16, 196)
        Me.happyMeal1PriceLabel.Name = "happyMeal1PriceLabel"
        Me.happyMeal1PriceLabel.Size = New System.Drawing.Size(101, 17)
        Me.happyMeal1PriceLabel.TabIndex = 213
        Me.happyMeal1PriceLabel.Text = "From RM10.37"
        '
        'happyMeal3PriceLabel
        '
        Me.happyMeal3PriceLabel.AutoSize = True
        Me.happyMeal3PriceLabel.Location = New System.Drawing.Point(718, 196)
        Me.happyMeal3PriceLabel.Name = "happyMeal3PriceLabel"
        Me.happyMeal3PriceLabel.Size = New System.Drawing.Size(101, 17)
        Me.happyMeal3PriceLabel.TabIndex = 202
        Me.happyMeal3PriceLabel.Text = "From RM10.37"
        '
        'happyMeal1Label
        '
        Me.happyMeal1Label.AutoSize = True
        Me.happyMeal1Label.Location = New System.Drawing.Point(16, 179)
        Me.happyMeal1Label.Name = "happyMeal1Label"
        Me.happyMeal1Label.Size = New System.Drawing.Size(105, 17)
        Me.happyMeal1Label.TabIndex = 203
        Me.happyMeal1Label.Text = "Chicken Burger"
        '
        'happyMeal4PictureBox
        '
        Me.happyMeal4PictureBox.Image = CType(resources.GetObject("happyMeal4PictureBox.Image"), System.Drawing.Image)
        Me.happyMeal4PictureBox.Location = New System.Drawing.Point(1056, 10)
        Me.happyMeal4PictureBox.Name = "happyMeal4PictureBox"
        Me.happyMeal4PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.happyMeal4PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.happyMeal4PictureBox.TabIndex = 211
        Me.happyMeal4PictureBox.TabStop = False
        '
        'happyMeal4Label
        '
        Me.happyMeal4Label.AutoSize = True
        Me.happyMeal4Label.Location = New System.Drawing.Point(1054, 179)
        Me.happyMeal4Label.Name = "happyMeal4Label"
        Me.happyMeal4Label.Size = New System.Drawing.Size(98, 17)
        Me.happyMeal4Label.TabIndex = 204
        Me.happyMeal4Label.Text = "Cheeseburger"
        '
        'happyMeal3PictureBox
        '
        Me.happyMeal3PictureBox.Image = CType(resources.GetObject("happyMeal3PictureBox.Image"), System.Drawing.Image)
        Me.happyMeal3PictureBox.Location = New System.Drawing.Point(719, 10)
        Me.happyMeal3PictureBox.Name = "happyMeal3PictureBox"
        Me.happyMeal3PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.happyMeal3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.happyMeal3PictureBox.TabIndex = 210
        Me.happyMeal3PictureBox.TabStop = False
        '
        'happyMeal4PriceLabel
        '
        Me.happyMeal4PriceLabel.AutoSize = True
        Me.happyMeal4PriceLabel.Location = New System.Drawing.Point(1053, 196)
        Me.happyMeal4PriceLabel.Name = "happyMeal4PriceLabel"
        Me.happyMeal4PriceLabel.Size = New System.Drawing.Size(101, 17)
        Me.happyMeal4PriceLabel.TabIndex = 205
        Me.happyMeal4PriceLabel.Text = "From RM10.37"
        '
        'happyMeal2PictureBox
        '
        Me.happyMeal2PictureBox.Image = CType(resources.GetObject("happyMeal2PictureBox.Image"), System.Drawing.Image)
        Me.happyMeal2PictureBox.Location = New System.Drawing.Point(369, 10)
        Me.happyMeal2PictureBox.Name = "happyMeal2PictureBox"
        Me.happyMeal2PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.happyMeal2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.happyMeal2PictureBox.TabIndex = 209
        Me.happyMeal2PictureBox.TabStop = False
        '
        'happyMeal5Label
        '
        Me.happyMeal5Label.AutoSize = True
        Me.happyMeal5Label.Location = New System.Drawing.Point(1369, 192)
        Me.happyMeal5Label.Name = "happyMeal5Label"
        Me.happyMeal5Label.Size = New System.Drawing.Size(212, 17)
        Me.happyMeal5Label.TabIndex = 206
        Me.happyMeal5Label.Text = "Ayam Goreng McD™ Spicy (1pc)"
        '
        'happyMeal1PictureBox
        '
        Me.happyMeal1PictureBox.Image = CType(resources.GetObject("happyMeal1PictureBox.Image"), System.Drawing.Image)
        Me.happyMeal1PictureBox.Location = New System.Drawing.Point(16, 10)
        Me.happyMeal1PictureBox.Name = "happyMeal1PictureBox"
        Me.happyMeal1PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.happyMeal1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.happyMeal1PictureBox.TabIndex = 208
        Me.happyMeal1PictureBox.TabStop = False
        '
        'happyMeal5PriceLabel
        '
        Me.happyMeal5PriceLabel.AutoSize = True
        Me.happyMeal5PriceLabel.Location = New System.Drawing.Point(1372, 209)
        Me.happyMeal5PriceLabel.Name = "happyMeal5PriceLabel"
        Me.happyMeal5PriceLabel.Size = New System.Drawing.Size(101, 17)
        Me.happyMeal5PriceLabel.TabIndex = 207
        Me.happyMeal5PriceLabel.Text = "From RM10.37"
        '
        'HappyMeal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.happyMealPanel)
        Me.Controls.Add(Me.happyMealLabel)
        Me.Name = "HappyMeal"
        Me.Size = New System.Drawing.Size(1676, 1038)
        Me.happyMealPanel.ResumeLayout(False)
        Me.happyMealPanel.PerformLayout()
        CType(Me.happyMeal6PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.happyMeal5PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.happyMeal4PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.happyMeal3PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.happyMeal2PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.happyMeal1PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents happyMealLabel As Label
    Friend WithEvents happyMealPanel As Panel
    Friend WithEvents happyMeal6PriceLabel As Label
    Friend WithEvents happyMeal6PictureBox As PictureBox
    Friend WithEvents happyMeal6Label As Label
    Friend WithEvents happyMeal5PictureBox As PictureBox
    Friend WithEvents happyMeal2Label As Label
    Friend WithEvents happyMeal2PriceLabel As Label
    Friend WithEvents happyMeal3Label As Label
    Friend WithEvents happyMeal1PriceLabel As Label
    Friend WithEvents happyMeal3PriceLabel As Label
    Friend WithEvents happyMeal1Label As Label
    Friend WithEvents happyMeal4PictureBox As PictureBox
    Friend WithEvents happyMeal4Label As Label
    Friend WithEvents happyMeal3PictureBox As PictureBox
    Friend WithEvents happyMeal4PriceLabel As Label
    Friend WithEvents happyMeal2PictureBox As PictureBox
    Friend WithEvents happyMeal5Label As Label
    Friend WithEvents happyMeal1PictureBox As PictureBox
    Friend WithEvents happyMeal5PriceLabel As Label
End Class
