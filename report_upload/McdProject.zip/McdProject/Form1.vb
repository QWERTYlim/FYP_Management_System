﻿Public Class SelectForm
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)
        PictureBox1.BackColor = Color.SeaGreen
    End Sub

    Private Sub PictureBox1_Click_1(sender As Object, e As EventArgs) Handles PictureBox1.Click
        menus.Show()
        Me.Close()

    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        menus.Show()
        Me.Close()
    End Sub

    Private Sub SelectForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class