﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class McCafeCake
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(McCafeCake))
        Me.mcCafeCakeLabel = New System.Windows.Forms.Label()
        Me.mcCafeCakePanel = New System.Windows.Forms.Panel()
        Me.mcCafeCake5PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeCakePrice11Label = New System.Windows.Forms.Label()
        Me.mcCafeCake1PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeCake11Label = New System.Windows.Forms.Label()
        Me.mcCafeCake2PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeCake11PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeCake3PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeCakePrice6Label = New System.Windows.Forms.Label()
        Me.mcCafeCakePrice10Label = New System.Windows.Forms.Label()
        Me.mcCafeCake2Label = New System.Windows.Forms.Label()
        Me.mcCafeCake10Label = New System.Windows.Forms.Label()
        Me.mcCafeCakePrice2Label = New System.Windows.Forms.Label()
        Me.mcCafeCake10PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeCake3Label = New System.Windows.Forms.Label()
        Me.mcCafeCakePrice9Label = New System.Windows.Forms.Label()
        Me.mcCafeCakePrice3Label = New System.Windows.Forms.Label()
        Me.mcCafeCake9Label = New System.Windows.Forms.Label()
        Me.mcCafeCake1Label = New System.Windows.Forms.Label()
        Me.mcCafeCake9PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeCakePrice1Label = New System.Windows.Forms.Label()
        Me.mcCafeCake6Label = New System.Windows.Forms.Label()
        Me.mcCafeCake4PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeCakePrice8Label = New System.Windows.Forms.Label()
        Me.mcCafeCake4Label = New System.Windows.Forms.Label()
        Me.mcCafeCake8Label = New System.Windows.Forms.Label()
        Me.mcCafeCakePrice4Label = New System.Windows.Forms.Label()
        Me.mcCafeCakePrice7Label = New System.Windows.Forms.Label()
        Me.mcCafeCake5Label = New System.Windows.Forms.Label()
        Me.mcCafeCake7Label = New System.Windows.Forms.Label()
        Me.mcCafeCakePrice5Label = New System.Windows.Forms.Label()
        Me.mcCafeCake8PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeCake6PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeCake7PictureBox = New System.Windows.Forms.PictureBox()
        Me.mcCafeCakePanel.SuspendLayout()
        CType(Me.mcCafeCake5PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeCake1PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeCake2PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeCake11PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeCake3PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeCake10PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeCake9PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeCake4PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeCake8PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeCake6PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcCafeCake7PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mcCafeCakeLabel
        '
        Me.mcCafeCakeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.mcCafeCakeLabel.Font = New System.Drawing.Font("Segoe UI", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mcCafeCakeLabel.Location = New System.Drawing.Point(3, 10)
        Me.mcCafeCakeLabel.Name = "mcCafeCakeLabel"
        Me.mcCafeCakeLabel.Size = New System.Drawing.Size(1670, 99)
        Me.mcCafeCakeLabel.TabIndex = 130
        Me.mcCafeCakeLabel.Text = "McCafe Cake"
        '
        'mcCafeCakePanel
        '
        Me.mcCafeCakePanel.AutoScroll = True
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake5PictureBox)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCakePrice11Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake1PictureBox)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake11Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake2PictureBox)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake11PictureBox)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake3PictureBox)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCakePrice6Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCakePrice10Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake2Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake10Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCakePrice2Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake10PictureBox)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake3Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCakePrice9Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCakePrice3Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake9Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake1Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake9PictureBox)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCakePrice1Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake6Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake4PictureBox)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCakePrice8Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake4Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake8Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCakePrice4Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCakePrice7Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake5Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake7Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCakePrice5Label)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake8PictureBox)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake6PictureBox)
        Me.mcCafeCakePanel.Controls.Add(Me.mcCafeCake7PictureBox)
        Me.mcCafeCakePanel.Location = New System.Drawing.Point(12, 112)
        Me.mcCafeCakePanel.Name = "mcCafeCakePanel"
        Me.mcCafeCakePanel.Size = New System.Drawing.Size(1650, 625)
        Me.mcCafeCakePanel.TabIndex = 153
        '
        'mcCafeCake5PictureBox
        '
        Me.mcCafeCake5PictureBox.Image = CType(resources.GetObject("mcCafeCake5PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeCake5PictureBox.Location = New System.Drawing.Point(1360, 10)
        Me.mcCafeCake5PictureBox.Name = "mcCafeCake5PictureBox"
        Me.mcCafeCake5PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeCake5PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeCake5PictureBox.TabIndex = 131
        Me.mcCafeCake5PictureBox.TabStop = False
        '
        'mcCafeCakePrice11Label
        '
        Me.mcCafeCakePrice11Label.AutoSize = True
        Me.mcCafeCakePrice11Label.Location = New System.Drawing.Point(21, 683)
        Me.mcCafeCakePrice11Label.Name = "mcCafeCakePrice11Label"
        Me.mcCafeCakePrice11Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeCakePrice11Label.TabIndex = 151
        Me.mcCafeCakePrice11Label.Text = "From RM11.31"
        '
        'mcCafeCake1PictureBox
        '
        Me.mcCafeCake1PictureBox.Image = CType(resources.GetObject("mcCafeCake1PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeCake1PictureBox.Location = New System.Drawing.Point(24, 10)
        Me.mcCafeCake1PictureBox.Name = "mcCafeCake1PictureBox"
        Me.mcCafeCake1PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeCake1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeCake1PictureBox.TabIndex = 118
        Me.mcCafeCake1PictureBox.TabStop = False
        '
        'mcCafeCake11Label
        '
        Me.mcCafeCake11Label.AutoSize = True
        Me.mcCafeCake11Label.Location = New System.Drawing.Point(21, 666)
        Me.mcCafeCake11Label.Name = "mcCafeCake11Label"
        Me.mcCafeCake11Label.Size = New System.Drawing.Size(113, 17)
        Me.mcCafeCake11Label.TabIndex = 150
        Me.mcCafeCake11Label.Text = "Red Velvet Cake"
        '
        'mcCafeCake2PictureBox
        '
        Me.mcCafeCake2PictureBox.Image = CType(resources.GetObject("mcCafeCake2PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeCake2PictureBox.Location = New System.Drawing.Point(369, 10)
        Me.mcCafeCake2PictureBox.Name = "mcCafeCake2PictureBox"
        Me.mcCafeCake2PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeCake2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeCake2PictureBox.TabIndex = 119
        Me.mcCafeCake2PictureBox.TabStop = False
        '
        'mcCafeCake11PictureBox
        '
        Me.mcCafeCake11PictureBox.Image = CType(resources.GetObject("mcCafeCake11PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeCake11PictureBox.Location = New System.Drawing.Point(24, 497)
        Me.mcCafeCake11PictureBox.Name = "mcCafeCake11PictureBox"
        Me.mcCafeCake11PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeCake11PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeCake11PictureBox.TabIndex = 149
        Me.mcCafeCake11PictureBox.TabStop = False
        '
        'mcCafeCake3PictureBox
        '
        Me.mcCafeCake3PictureBox.Image = CType(resources.GetObject("mcCafeCake3PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeCake3PictureBox.Location = New System.Drawing.Point(719, 10)
        Me.mcCafeCake3PictureBox.Name = "mcCafeCake3PictureBox"
        Me.mcCafeCake3PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeCake3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeCake3PictureBox.TabIndex = 120
        Me.mcCafeCake3PictureBox.TabStop = False
        '
        'mcCafeCakePrice6Label
        '
        Me.mcCafeCakePrice6Label.AutoSize = True
        Me.mcCafeCakePrice6Label.Location = New System.Drawing.Point(21, 436)
        Me.mcCafeCakePrice6Label.Name = "mcCafeCakePrice6Label"
        Me.mcCafeCakePrice6Label.Size = New System.Drawing.Size(93, 17)
        Me.mcCafeCakePrice6Label.TabIndex = 142
        Me.mcCafeCakePrice6Label.Text = "From RM6.13"
        '
        'mcCafeCakePrice10Label
        '
        Me.mcCafeCakePrice10Label.AutoSize = True
        Me.mcCafeCakePrice10Label.Location = New System.Drawing.Point(1360, 449)
        Me.mcCafeCakePrice10Label.Name = "mcCafeCakePrice10Label"
        Me.mcCafeCakePrice10Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeCakePrice10Label.TabIndex = 148
        Me.mcCafeCakePrice10Label.Text = "From RM11.31"
        '
        'mcCafeCake2Label
        '
        Me.mcCafeCake2Label.AutoSize = True
        Me.mcCafeCake2Label.Location = New System.Drawing.Point(369, 179)
        Me.mcCafeCake2Label.Name = "mcCafeCake2Label"
        Me.mcCafeCake2Label.Size = New System.Drawing.Size(246, 17)
        Me.mcCafeCake2Label.TabIndex = 121
        Me.mcCafeCake2Label.Text = "Cookies & Cream Cheesecake + Coffee"
        '
        'mcCafeCake10Label
        '
        Me.mcCafeCake10Label.AutoSize = True
        Me.mcCafeCake10Label.Location = New System.Drawing.Point(1357, 419)
        Me.mcCafeCake10Label.Name = "mcCafeCake10Label"
        Me.mcCafeCake10Label.Size = New System.Drawing.Size(189, 17)
        Me.mcCafeCake10Label.TabIndex = 147
        Me.mcCafeCake10Label.Text = "Cookies & Cream Cheesecake"
        '
        'mcCafeCakePrice2Label
        '
        Me.mcCafeCakePrice2Label.AutoSize = True
        Me.mcCafeCakePrice2Label.Location = New System.Drawing.Point(369, 196)
        Me.mcCafeCakePrice2Label.Name = "mcCafeCakePrice2Label"
        Me.mcCafeCakePrice2Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeCakePrice2Label.TabIndex = 122
        Me.mcCafeCakePrice2Label.Text = "From RM12.25"
        '
        'mcCafeCake10PictureBox
        '
        Me.mcCafeCake10PictureBox.Image = CType(resources.GetObject("mcCafeCake10PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeCake10PictureBox.Location = New System.Drawing.Point(1360, 250)
        Me.mcCafeCake10PictureBox.Name = "mcCafeCake10PictureBox"
        Me.mcCafeCake10PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeCake10PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeCake10PictureBox.TabIndex = 146
        Me.mcCafeCake10PictureBox.TabStop = False
        '
        'mcCafeCake3Label
        '
        Me.mcCafeCake3Label.AutoSize = True
        Me.mcCafeCake3Label.Location = New System.Drawing.Point(719, 179)
        Me.mcCafeCake3Label.Name = "mcCafeCake3Label"
        Me.mcCafeCake3Label.Size = New System.Drawing.Size(170, 17)
        Me.mcCafeCake3Label.TabIndex = 123
        Me.mcCafeCake3Label.Text = "Red Velvet Cake + Coffee"
        '
        'mcCafeCakePrice9Label
        '
        Me.mcCafeCakePrice9Label.AutoSize = True
        Me.mcCafeCakePrice9Label.Location = New System.Drawing.Point(1052, 436)
        Me.mcCafeCakePrice9Label.Name = "mcCafeCakePrice9Label"
        Me.mcCafeCakePrice9Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeCakePrice9Label.TabIndex = 145
        Me.mcCafeCakePrice9Label.Text = "From RM11.31"
        '
        'mcCafeCakePrice3Label
        '
        Me.mcCafeCakePrice3Label.AutoSize = True
        Me.mcCafeCakePrice3Label.Location = New System.Drawing.Point(719, 196)
        Me.mcCafeCakePrice3Label.Name = "mcCafeCakePrice3Label"
        Me.mcCafeCakePrice3Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeCakePrice3Label.TabIndex = 124
        Me.mcCafeCakePrice3Label.Text = "From RM12.25"
        '
        'mcCafeCake9Label
        '
        Me.mcCafeCake9Label.AutoSize = True
        Me.mcCafeCake9Label.Location = New System.Drawing.Point(1052, 419)
        Me.mcCafeCake9Label.Name = "mcCafeCake9Label"
        Me.mcCafeCake9Label.Size = New System.Drawing.Size(134, 17)
        Me.mcCafeCake9Label.TabIndex = 144
        Me.mcCafeCake9Label.Text = "Classic Cheesecake"
        '
        'mcCafeCake1Label
        '
        Me.mcCafeCake1Label.AutoSize = True
        Me.mcCafeCake1Label.Location = New System.Drawing.Point(21, 179)
        Me.mcCafeCake1Label.Name = "mcCafeCake1Label"
        Me.mcCafeCake1Label.Size = New System.Drawing.Size(191, 17)
        Me.mcCafeCake1Label.TabIndex = 125
        Me.mcCafeCake1Label.Text = "Classic Cheesecake + Coffee"
        '
        'mcCafeCake9PictureBox
        '
        Me.mcCafeCake9PictureBox.Image = CType(resources.GetObject("mcCafeCake9PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeCake9PictureBox.Location = New System.Drawing.Point(1053, 250)
        Me.mcCafeCake9PictureBox.Name = "mcCafeCake9PictureBox"
        Me.mcCafeCake9PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeCake9PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeCake9PictureBox.TabIndex = 143
        Me.mcCafeCake9PictureBox.TabStop = False
        '
        'mcCafeCakePrice1Label
        '
        Me.mcCafeCakePrice1Label.AutoSize = True
        Me.mcCafeCakePrice1Label.Location = New System.Drawing.Point(21, 196)
        Me.mcCafeCakePrice1Label.Name = "mcCafeCakePrice1Label"
        Me.mcCafeCakePrice1Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeCakePrice1Label.TabIndex = 126
        Me.mcCafeCakePrice1Label.Text = "From RM12.25"
        '
        'mcCafeCake6Label
        '
        Me.mcCafeCake6Label.AutoSize = True
        Me.mcCafeCake6Label.Location = New System.Drawing.Point(21, 419)
        Me.mcCafeCake6Label.Name = "mcCafeCake6Label"
        Me.mcCafeCake6Label.Size = New System.Drawing.Size(162, 17)
        Me.mcCafeCake6Label.TabIndex = 141
        Me.mcCafeCake6Label.Text = "Double Chocolate Muffin"
        '
        'mcCafeCake4PictureBox
        '
        Me.mcCafeCake4PictureBox.Image = CType(resources.GetObject("mcCafeCake4PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeCake4PictureBox.Location = New System.Drawing.Point(1053, 10)
        Me.mcCafeCake4PictureBox.Name = "mcCafeCake4PictureBox"
        Me.mcCafeCake4PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeCake4PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeCake4PictureBox.TabIndex = 127
        Me.mcCafeCake4PictureBox.TabStop = False
        '
        'mcCafeCakePrice8Label
        '
        Me.mcCafeCakePrice8Label.AutoSize = True
        Me.mcCafeCakePrice8Label.Location = New System.Drawing.Point(719, 436)
        Me.mcCafeCakePrice8Label.Name = "mcCafeCakePrice8Label"
        Me.mcCafeCakePrice8Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeCakePrice8Label.TabIndex = 140
        Me.mcCafeCakePrice8Label.Text = "From RM11.31"
        '
        'mcCafeCake4Label
        '
        Me.mcCafeCake4Label.AutoSize = True
        Me.mcCafeCake4Label.Location = New System.Drawing.Point(1050, 179)
        Me.mcCafeCake4Label.Name = "mcCafeCake4Label"
        Me.mcCafeCake4Label.Size = New System.Drawing.Size(182, 17)
        Me.mcCafeCake4Label.TabIndex = 128
        Me.mcCafeCake4Label.Text = "Belgium Chocolate + Coffee"
        '
        'mcCafeCake8Label
        '
        Me.mcCafeCake8Label.AutoSize = True
        Me.mcCafeCake8Label.Location = New System.Drawing.Point(719, 419)
        Me.mcCafeCake8Label.Name = "mcCafeCake8Label"
        Me.mcCafeCake8Label.Size = New System.Drawing.Size(142, 17)
        Me.mcCafeCake8Label.TabIndex = 139
        Me.mcCafeCake8Label.Text = "Chocolate Lava Cake"
        '
        'mcCafeCakePrice4Label
        '
        Me.mcCafeCakePrice4Label.AutoSize = True
        Me.mcCafeCakePrice4Label.Location = New System.Drawing.Point(1052, 196)
        Me.mcCafeCakePrice4Label.Name = "mcCafeCakePrice4Label"
        Me.mcCafeCakePrice4Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeCakePrice4Label.TabIndex = 129
        Me.mcCafeCakePrice4Label.Text = "From RM12.25"
        '
        'mcCafeCakePrice7Label
        '
        Me.mcCafeCakePrice7Label.AutoSize = True
        Me.mcCafeCakePrice7Label.Location = New System.Drawing.Point(369, 436)
        Me.mcCafeCakePrice7Label.Name = "mcCafeCakePrice7Label"
        Me.mcCafeCakePrice7Label.Size = New System.Drawing.Size(101, 17)
        Me.mcCafeCakePrice7Label.TabIndex = 138
        Me.mcCafeCakePrice7Label.Text = "From RM11.31"
        '
        'mcCafeCake5Label
        '
        Me.mcCafeCake5Label.AutoSize = True
        Me.mcCafeCake5Label.Location = New System.Drawing.Point(1357, 179)
        Me.mcCafeCake5Label.Name = "mcCafeCake5Label"
        Me.mcCafeCake5Label.Size = New System.Drawing.Size(147, 17)
        Me.mcCafeCake5Label.TabIndex = 132
        Me.mcCafeCake5Label.Text = "Banana Walnut Muffin"
        '
        'mcCafeCake7Label
        '
        Me.mcCafeCake7Label.AutoSize = True
        Me.mcCafeCake7Label.Location = New System.Drawing.Point(369, 419)
        Me.mcCafeCake7Label.Name = "mcCafeCake7Label"
        Me.mcCafeCake7Label.Size = New System.Drawing.Size(161, 17)
        Me.mcCafeCake7Label.TabIndex = 137
        Me.mcCafeCake7Label.Text = "Belgium Chocolate Cake"
        '
        'mcCafeCakePrice5Label
        '
        Me.mcCafeCakePrice5Label.AutoSize = True
        Me.mcCafeCakePrice5Label.Location = New System.Drawing.Point(1359, 196)
        Me.mcCafeCakePrice5Label.Name = "mcCafeCakePrice5Label"
        Me.mcCafeCakePrice5Label.Size = New System.Drawing.Size(93, 17)
        Me.mcCafeCakePrice5Label.TabIndex = 133
        Me.mcCafeCakePrice5Label.Text = "From RM6.13"
        '
        'mcCafeCake8PictureBox
        '
        Me.mcCafeCake8PictureBox.Image = CType(resources.GetObject("mcCafeCake8PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeCake8PictureBox.Location = New System.Drawing.Point(719, 250)
        Me.mcCafeCake8PictureBox.Name = "mcCafeCake8PictureBox"
        Me.mcCafeCake8PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeCake8PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeCake8PictureBox.TabIndex = 136
        Me.mcCafeCake8PictureBox.TabStop = False
        '
        'mcCafeCake6PictureBox
        '
        Me.mcCafeCake6PictureBox.Image = CType(resources.GetObject("mcCafeCake6PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeCake6PictureBox.Location = New System.Drawing.Point(22, 250)
        Me.mcCafeCake6PictureBox.Name = "mcCafeCake6PictureBox"
        Me.mcCafeCake6PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeCake6PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeCake6PictureBox.TabIndex = 134
        Me.mcCafeCake6PictureBox.TabStop = False
        '
        'mcCafeCake7PictureBox
        '
        Me.mcCafeCake7PictureBox.Image = CType(resources.GetObject("mcCafeCake7PictureBox.Image"), System.Drawing.Image)
        Me.mcCafeCake7PictureBox.Location = New System.Drawing.Point(369, 250)
        Me.mcCafeCake7PictureBox.Name = "mcCafeCake7PictureBox"
        Me.mcCafeCake7PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.mcCafeCake7PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcCafeCake7PictureBox.TabIndex = 135
        Me.mcCafeCake7PictureBox.TabStop = False
        '
        'McCafeCake
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.mcCafeCakePanel)
        Me.Controls.Add(Me.mcCafeCakeLabel)
        Me.Name = "McCafeCake"
        Me.Size = New System.Drawing.Size(1676, 1038)
        Me.mcCafeCakePanel.ResumeLayout(False)
        Me.mcCafeCakePanel.PerformLayout()
        CType(Me.mcCafeCake5PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeCake1PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeCake2PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeCake11PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeCake3PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeCake10PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeCake9PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeCake4PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeCake8PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeCake6PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcCafeCake7PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents mcCafeCakeLabel As Label
    Friend WithEvents mcCafeCakePanel As Panel
    Friend WithEvents mcCafeCake5PictureBox As PictureBox
    Friend WithEvents mcCafeCakePrice11Label As Label
    Friend WithEvents mcCafeCake1PictureBox As PictureBox
    Friend WithEvents mcCafeCake11Label As Label
    Friend WithEvents mcCafeCake2PictureBox As PictureBox
    Friend WithEvents mcCafeCake11PictureBox As PictureBox
    Friend WithEvents mcCafeCake3PictureBox As PictureBox
    Friend WithEvents mcCafeCakePrice6Label As Label
    Friend WithEvents mcCafeCakePrice10Label As Label
    Friend WithEvents mcCafeCake2Label As Label
    Friend WithEvents mcCafeCake10Label As Label
    Friend WithEvents mcCafeCakePrice2Label As Label
    Friend WithEvents mcCafeCake10PictureBox As PictureBox
    Friend WithEvents mcCafeCake3Label As Label
    Friend WithEvents mcCafeCakePrice9Label As Label
    Friend WithEvents mcCafeCakePrice3Label As Label
    Friend WithEvents mcCafeCake9Label As Label
    Friend WithEvents mcCafeCake1Label As Label
    Friend WithEvents mcCafeCake9PictureBox As PictureBox
    Friend WithEvents mcCafeCakePrice1Label As Label
    Friend WithEvents mcCafeCake6Label As Label
    Friend WithEvents mcCafeCake4PictureBox As PictureBox
    Friend WithEvents mcCafeCakePrice8Label As Label
    Friend WithEvents mcCafeCake4Label As Label
    Friend WithEvents mcCafeCake8Label As Label
    Friend WithEvents mcCafeCakePrice4Label As Label
    Friend WithEvents mcCafeCakePrice7Label As Label
    Friend WithEvents mcCafeCake5Label As Label
    Friend WithEvents mcCafeCake7Label As Label
    Friend WithEvents mcCafeCakePrice5Label As Label
    Friend WithEvents mcCafeCake8PictureBox As PictureBox
    Friend WithEvents mcCafeCake6PictureBox As PictureBox
    Friend WithEvents mcCafeCake7PictureBox As PictureBox
End Class
