﻿Public Class FamilyMeal
    Private Sub Label31_Click(sender As Object, e As EventArgs) Handles familyMealLabel.Click

    End Sub

    Private Sub exitButton_Click(sender As Object, e As EventArgs) 
        Application.Exit()
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles familyMealPanel.Paint

    End Sub
    Public Sub quantitys(ByVal setnum As Integer)
        Dim picture() = {familyMeal1PictureBox, familyMeal2PictureBox, familyMeal3PictureBox}
        Dim price() = {37.73, 37.73, 37.73}
        Dim setname() = {familyMeal1Label.Text, familyMeal2Label.Text, familyMeal3Label.Text}
        Quantity.SetPictureBox.Image = picture(setnum).Image
        Quantity.Label2.Text = price(setnum)
        Quantity.Label1.Text = setname(setnum)
        Quantity.one_set_price = price(setnum)
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles familyMeal1PictureBox.Click
        quantitys(0)
        Quantity.Show()
        Quantity.set_choosen = 15
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles familyMeal2PictureBox.Click
        quantitys(1)
        Quantity.Show()
        Quantity.set_choosen = 16
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles familyMeal3PictureBox.Click
        quantitys(2)
        Quantity.Show()
        Quantity.set_choosen = 17
    End Sub
End Class
