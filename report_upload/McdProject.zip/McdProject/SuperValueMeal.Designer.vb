﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SuperValueMeal
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SuperValueMeal))
        Me.superValueMeal6ConLabel = New System.Windows.Forms.Label()
        Me.superValueMeal6Label = New System.Windows.Forms.Label()
        Me.superValueMeal15ConLabel = New System.Windows.Forms.Label()
        Me.superValueMeal10ConLabel = New System.Windows.Forms.Label()
        Me.superValueMeal15Label = New System.Windows.Forms.Label()
        Me.superValueMeal10Label = New System.Windows.Forms.Label()
        Me.superValueMeal15PictureBox = New System.Windows.Forms.PictureBox()
        Me.superValueMealPrice14Label = New System.Windows.Forms.Label()
        Me.superValueMeal9ConLabel = New System.Windows.Forms.Label()
        Me.superValueMeal14Label = New System.Windows.Forms.Label()
        Me.superValueMeal6PictureBox = New System.Windows.Forms.PictureBox()
        Me.superValueMeal13ConLabel = New System.Windows.Forms.Label()
        Me.superValueMeal9Label = New System.Windows.Forms.Label()
        Me.superValueMeal13Label = New System.Windows.Forms.Label()
        Me.superValueMealPrice8Label = New System.Windows.Forms.Label()
        Me.superValueMeal12ConLabel = New System.Windows.Forms.Label()
        Me.superValueMeal8Label = New System.Windows.Forms.Label()
        Me.superValueMeal12Label = New System.Windows.Forms.Label()
        Me.superValueMeal7ConLabel = New System.Windows.Forms.Label()
        Me.superValueMeal11ConLabel = New System.Windows.Forms.Label()
        Me.superValueMeal7Label = New System.Windows.Forms.Label()
        Me.superValueMeal11Label = New System.Windows.Forms.Label()
        Me.superValueMeal10PictureBox = New System.Windows.Forms.PictureBox()
        Me.superValueMeal9PictureBox = New System.Windows.Forms.PictureBox()
        Me.superValueMeal14PictureBox = New System.Windows.Forms.PictureBox()
        Me.superValueMeal13PictureBox = New System.Windows.Forms.PictureBox()
        Me.superValueMeal8PictureBox = New System.Windows.Forms.PictureBox()
        Me.superValueMeal12PictureBox = New System.Windows.Forms.PictureBox()
        Me.superValueMeal7PictureBox = New System.Windows.Forms.PictureBox()
        Me.superValueMeal11PictureBox = New System.Windows.Forms.PictureBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.superValueMeal5Label = New System.Windows.Forms.Label()
        Me.superValueMeal4ConLabel = New System.Windows.Forms.Label()
        Me.superValueMeal4Label = New System.Windows.Forms.Label()
        Me.superValueMealPrice3Label = New System.Windows.Forms.Label()
        Me.superValueMeal3Label = New System.Windows.Forms.Label()
        Me.superValueMealPrice2Label = New System.Windows.Forms.Label()
        Me.superValueMeal2Label = New System.Windows.Forms.Label()
        Me.superValueMealPrice1Label = New System.Windows.Forms.Label()
        Me.superValueMeal1Label = New System.Windows.Forms.Label()
        Me.superValueMeal1PictureBox = New System.Windows.Forms.PictureBox()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.superValueMeal5PictureBox = New System.Windows.Forms.PictureBox()
        Me.superValueMeal4PictureBox = New System.Windows.Forms.PictureBox()
        Me.superValueMeal3PictureBox = New System.Windows.Forms.PictureBox()
        Me.superValueMeal2PictureBox = New System.Windows.Forms.PictureBox()
        Me.superValueMealPanel = New System.Windows.Forms.Panel()
        Me.superValueMealPrice13Label = New System.Windows.Forms.Label()
        Me.superValueMealPrice15Label = New System.Windows.Forms.Label()
        Me.superValueMealPrice11Label = New System.Windows.Forms.Label()
        Me.superValueMealPrice12Label = New System.Windows.Forms.Label()
        Me.superValueMealPrice6Label = New System.Windows.Forms.Label()
        Me.superValueMealPrice7Label = New System.Windows.Forms.Label()
        Me.superValueMealPrice10Label = New System.Windows.Forms.Label()
        Me.superValueMealPrice5Label = New System.Windows.Forms.Label()
        Me.superValueMealPrice9Label = New System.Windows.Forms.Label()
        Me.superValueMealPrice4Label = New System.Windows.Forms.Label()
        Me.superValueMealLabel = New System.Windows.Forms.Label()
        CType(Me.superValueMeal15PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal6PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal10PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal9PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal14PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal13PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal8PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal12PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal7PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal11PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal1PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal5PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal4PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal3PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.superValueMeal2PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.superValueMealPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'superValueMeal6ConLabel
        '
        Me.superValueMeal6ConLabel.AutoSize = True
        Me.superValueMeal6ConLabel.Location = New System.Drawing.Point(20, 436)
        Me.superValueMeal6ConLabel.Name = "superValueMeal6ConLabel"
        Me.superValueMeal6ConLabel.Size = New System.Drawing.Size(114, 17)
        Me.superValueMeal6ConLabel.TabIndex = 78
        Me.superValueMeal6ConLabel.Text = "Value Meal         "
        '
        'superValueMeal6Label
        '
        Me.superValueMeal6Label.AutoSize = True
        Me.superValueMeal6Label.Location = New System.Drawing.Point(20, 419)
        Me.superValueMeal6Label.Name = "superValueMeal6Label"
        Me.superValueMeal6Label.Size = New System.Drawing.Size(223, 17)
        Me.superValueMeal6Label.TabIndex = 77
        Me.superValueMeal6Label.Text = "9pcs Chicken McNuggets® Super "
        '
        'superValueMeal15ConLabel
        '
        Me.superValueMeal15ConLabel.AutoSize = True
        Me.superValueMeal15ConLabel.Location = New System.Drawing.Point(1357, 683)
        Me.superValueMeal15ConLabel.Name = "superValueMeal15ConLabel"
        Me.superValueMeal15ConLabel.Size = New System.Drawing.Size(152, 17)
        Me.superValueMeal15ConLabel.TabIndex = 44
        Me.superValueMeal15ConLabel.Text = "Super Value Meal        "
        '
        'superValueMeal10ConLabel
        '
        Me.superValueMeal10ConLabel.AutoSize = True
        Me.superValueMeal10ConLabel.Location = New System.Drawing.Point(1357, 436)
        Me.superValueMeal10ConLabel.Name = "superValueMeal10ConLabel"
        Me.superValueMeal10ConLabel.Size = New System.Drawing.Size(152, 17)
        Me.superValueMeal10ConLabel.TabIndex = 76
        Me.superValueMeal10ConLabel.Text = "Super Value Meal        "
        '
        'superValueMeal15Label
        '
        Me.superValueMeal15Label.AutoSize = True
        Me.superValueMeal15Label.Location = New System.Drawing.Point(1357, 666)
        Me.superValueMeal15Label.Name = "superValueMeal15Label"
        Me.superValueMeal15Label.Size = New System.Drawing.Size(209, 17)
        Me.superValueMeal15Label.TabIndex = 43
        Me.superValueMeal15Label.Text = "Quarter Pounder™ with Cheese "
        '
        'superValueMeal10Label
        '
        Me.superValueMeal10Label.AutoSize = True
        Me.superValueMeal10Label.Location = New System.Drawing.Point(1357, 419)
        Me.superValueMeal10Label.Name = "superValueMeal10Label"
        Me.superValueMeal10Label.Size = New System.Drawing.Size(223, 17)
        Me.superValueMeal10Label.TabIndex = 75
        Me.superValueMeal10Label.Text = "Ayam Goreng McD™ Spicy (2pcs) "
        '
        'superValueMeal15PictureBox
        '
        Me.superValueMeal15PictureBox.Image = CType(resources.GetObject("superValueMeal15PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal15PictureBox.Location = New System.Drawing.Point(1360, 497)
        Me.superValueMeal15PictureBox.Name = "superValueMeal15PictureBox"
        Me.superValueMeal15PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal15PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal15PictureBox.TabIndex = 14
        Me.superValueMeal15PictureBox.TabStop = False
        '
        'superValueMealPrice14Label
        '
        Me.superValueMealPrice14Label.AutoSize = True
        Me.superValueMealPrice14Label.Location = New System.Drawing.Point(1054, 683)
        Me.superValueMealPrice14Label.Name = "superValueMealPrice14Label"
        Me.superValueMealPrice14Label.Size = New System.Drawing.Size(101, 17)
        Me.superValueMealPrice14Label.TabIndex = 42
        Me.superValueMealPrice14Label.Text = "From RM19.34"
        '
        'superValueMeal9ConLabel
        '
        Me.superValueMeal9ConLabel.AutoSize = True
        Me.superValueMeal9ConLabel.Location = New System.Drawing.Point(1053, 436)
        Me.superValueMeal9ConLabel.Name = "superValueMeal9ConLabel"
        Me.superValueMeal9ConLabel.Size = New System.Drawing.Size(140, 17)
        Me.superValueMeal9ConLabel.TabIndex = 74
        Me.superValueMeal9ConLabel.Text = "Super Value Meal     "
        '
        'superValueMeal14Label
        '
        Me.superValueMeal14Label.AutoSize = True
        Me.superValueMeal14Label.Location = New System.Drawing.Point(1054, 666)
        Me.superValueMeal14Label.Name = "superValueMeal14Label"
        Me.superValueMeal14Label.Size = New System.Drawing.Size(184, 17)
        Me.superValueMeal14Label.TabIndex = 41
        Me.superValueMeal14Label.Text = "Big Mac™ Super Value Meal"
        '
        'superValueMeal6PictureBox
        '
        Me.superValueMeal6PictureBox.Image = CType(resources.GetObject("superValueMeal6PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal6PictureBox.Location = New System.Drawing.Point(16, 250)
        Me.superValueMeal6PictureBox.Name = "superValueMeal6PictureBox"
        Me.superValueMeal6PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal6PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal6PictureBox.TabIndex = 64
        Me.superValueMeal6PictureBox.TabStop = False
        '
        'superValueMeal13ConLabel
        '
        Me.superValueMeal13ConLabel.AutoSize = True
        Me.superValueMeal13ConLabel.Location = New System.Drawing.Point(717, 683)
        Me.superValueMeal13ConLabel.Name = "superValueMeal13ConLabel"
        Me.superValueMeal13ConLabel.Size = New System.Drawing.Size(70, 17)
        Me.superValueMeal13ConLabel.TabIndex = 40
        Me.superValueMeal13ConLabel.Text = "Meal        "
        '
        'superValueMeal9Label
        '
        Me.superValueMeal9Label.AutoSize = True
        Me.superValueMeal9Label.Location = New System.Drawing.Point(1054, 419)
        Me.superValueMeal9Label.Name = "superValueMeal9Label"
        Me.superValueMeal9Label.Size = New System.Drawing.Size(239, 17)
        Me.superValueMeal9Label.TabIndex = 73
        Me.superValueMeal9Label.Text = "Ayam Goreng McD™ Regular (2pcs) "
        '
        'superValueMeal13Label
        '
        Me.superValueMeal13Label.AutoSize = True
        Me.superValueMeal13Label.Location = New System.Drawing.Point(716, 666)
        Me.superValueMeal13Label.Name = "superValueMeal13Label"
        Me.superValueMeal13Label.Size = New System.Drawing.Size(233, 17)
        Me.superValueMeal13Label.TabIndex = 39
        Me.superValueMeal13Label.Text = "Double Cheeseburger Super Value "
        '
        'superValueMealPrice8Label
        '
        Me.superValueMealPrice8Label.AutoSize = True
        Me.superValueMealPrice8Label.Location = New System.Drawing.Point(717, 436)
        Me.superValueMealPrice8Label.Name = "superValueMealPrice8Label"
        Me.superValueMealPrice8Label.Size = New System.Drawing.Size(101, 17)
        Me.superValueMealPrice8Label.TabIndex = 72
        Me.superValueMealPrice8Label.Text = "From RM20.28"
        '
        'superValueMeal12ConLabel
        '
        Me.superValueMeal12ConLabel.AutoSize = True
        Me.superValueMeal12ConLabel.Location = New System.Drawing.Point(370, 683)
        Me.superValueMeal12ConLabel.Name = "superValueMeal12ConLabel"
        Me.superValueMeal12ConLabel.Size = New System.Drawing.Size(152, 17)
        Me.superValueMeal12ConLabel.TabIndex = 38
        Me.superValueMeal12ConLabel.Text = "Super Value Meal        "
        '
        'superValueMeal8Label
        '
        Me.superValueMeal8Label.AutoSize = True
        Me.superValueMeal8Label.Location = New System.Drawing.Point(717, 419)
        Me.superValueMeal8Label.Name = "superValueMeal8Label"
        Me.superValueMeal8Label.Size = New System.Drawing.Size(153, 17)
        Me.superValueMeal8Label.TabIndex = 71
        Me.superValueMeal8Label.Text = "GCB Super Value Meal"
        '
        'superValueMeal12Label
        '
        Me.superValueMeal12Label.AutoSize = True
        Me.superValueMeal12Label.Location = New System.Drawing.Point(371, 666)
        Me.superValueMeal12Label.Name = "superValueMeal12Label"
        Me.superValueMeal12Label.Size = New System.Drawing.Size(239, 17)
        Me.superValueMeal12Label.TabIndex = 37
        Me.superValueMeal12Label.Text = "Ayam Goreng McD™ Regular (3pcs) "
        '
        'superValueMeal7ConLabel
        '
        Me.superValueMeal7ConLabel.AutoSize = True
        Me.superValueMeal7ConLabel.Location = New System.Drawing.Point(370, 436)
        Me.superValueMeal7ConLabel.Name = "superValueMeal7ConLabel"
        Me.superValueMeal7ConLabel.Size = New System.Drawing.Size(90, 17)
        Me.superValueMeal7ConLabel.TabIndex = 70
        Me.superValueMeal7ConLabel.Text = "Value Meal   "
        '
        'superValueMeal11ConLabel
        '
        Me.superValueMeal11ConLabel.AutoSize = True
        Me.superValueMeal11ConLabel.Location = New System.Drawing.Point(17, 683)
        Me.superValueMeal11ConLabel.Name = "superValueMeal11ConLabel"
        Me.superValueMeal11ConLabel.Size = New System.Drawing.Size(152, 17)
        Me.superValueMeal11ConLabel.TabIndex = 36
        Me.superValueMeal11ConLabel.Text = "Super Value Meal        "
        '
        'superValueMeal7Label
        '
        Me.superValueMeal7Label.AutoSize = True
        Me.superValueMeal7Label.Location = New System.Drawing.Point(371, 419)
        Me.superValueMeal7Label.Name = "superValueMeal7Label"
        Me.superValueMeal7Label.Size = New System.Drawing.Size(217, 17)
        Me.superValueMeal7Label.TabIndex = 69
        Me.superValueMeal7Label.Text = "Spicy Chicken McDeluxe™ Super "
        '
        'superValueMeal11Label
        '
        Me.superValueMeal11Label.AutoSize = True
        Me.superValueMeal11Label.Location = New System.Drawing.Point(17, 666)
        Me.superValueMeal11Label.Name = "superValueMeal11Label"
        Me.superValueMeal11Label.Size = New System.Drawing.Size(223, 17)
        Me.superValueMeal11Label.TabIndex = 35
        Me.superValueMeal11Label.Text = "Ayam Goreng McD™ Spicy (3pcs) "
        '
        'superValueMeal10PictureBox
        '
        Me.superValueMeal10PictureBox.Image = CType(resources.GetObject("superValueMeal10PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal10PictureBox.Location = New System.Drawing.Point(1360, 250)
        Me.superValueMeal10PictureBox.Name = "superValueMeal10PictureBox"
        Me.superValueMeal10PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal10PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal10PictureBox.TabIndex = 68
        Me.superValueMeal10PictureBox.TabStop = False
        '
        'superValueMeal9PictureBox
        '
        Me.superValueMeal9PictureBox.Image = CType(resources.GetObject("superValueMeal9PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal9PictureBox.Location = New System.Drawing.Point(1056, 250)
        Me.superValueMeal9PictureBox.Name = "superValueMeal9PictureBox"
        Me.superValueMeal9PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal9PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal9PictureBox.TabIndex = 67
        Me.superValueMeal9PictureBox.TabStop = False
        '
        'superValueMeal14PictureBox
        '
        Me.superValueMeal14PictureBox.Image = CType(resources.GetObject("superValueMeal14PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal14PictureBox.Location = New System.Drawing.Point(1056, 497)
        Me.superValueMeal14PictureBox.Name = "superValueMeal14PictureBox"
        Me.superValueMeal14PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal14PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal14PictureBox.TabIndex = 13
        Me.superValueMeal14PictureBox.TabStop = False
        '
        'superValueMeal13PictureBox
        '
        Me.superValueMeal13PictureBox.Image = CType(resources.GetObject("superValueMeal13PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal13PictureBox.Location = New System.Drawing.Point(720, 497)
        Me.superValueMeal13PictureBox.Name = "superValueMeal13PictureBox"
        Me.superValueMeal13PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal13PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal13PictureBox.TabIndex = 12
        Me.superValueMeal13PictureBox.TabStop = False
        '
        'superValueMeal8PictureBox
        '
        Me.superValueMeal8PictureBox.Image = CType(resources.GetObject("superValueMeal8PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal8PictureBox.Location = New System.Drawing.Point(719, 250)
        Me.superValueMeal8PictureBox.Name = "superValueMeal8PictureBox"
        Me.superValueMeal8PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal8PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal8PictureBox.TabIndex = 66
        Me.superValueMeal8PictureBox.TabStop = False
        '
        'superValueMeal12PictureBox
        '
        Me.superValueMeal12PictureBox.Image = CType(resources.GetObject("superValueMeal12PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal12PictureBox.Location = New System.Drawing.Point(369, 497)
        Me.superValueMeal12PictureBox.Name = "superValueMeal12PictureBox"
        Me.superValueMeal12PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal12PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal12PictureBox.TabIndex = 11
        Me.superValueMeal12PictureBox.TabStop = False
        '
        'superValueMeal7PictureBox
        '
        Me.superValueMeal7PictureBox.Image = CType(resources.GetObject("superValueMeal7PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal7PictureBox.Location = New System.Drawing.Point(369, 250)
        Me.superValueMeal7PictureBox.Name = "superValueMeal7PictureBox"
        Me.superValueMeal7PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal7PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal7PictureBox.TabIndex = 65
        Me.superValueMeal7PictureBox.TabStop = False
        '
        'superValueMeal11PictureBox
        '
        Me.superValueMeal11PictureBox.Image = CType(resources.GetObject("superValueMeal11PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal11PictureBox.Location = New System.Drawing.Point(16, 497)
        Me.superValueMeal11PictureBox.Name = "superValueMeal11PictureBox"
        Me.superValueMeal11PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal11PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal11PictureBox.TabIndex = 10
        Me.superValueMeal11PictureBox.TabStop = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(1357, 196)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(110, 17)
        Me.Label9.TabIndex = 63
        Me.Label9.Text = "Value Meal        "
        '
        'superValueMeal5Label
        '
        Me.superValueMeal5Label.AutoSize = True
        Me.superValueMeal5Label.Location = New System.Drawing.Point(1357, 179)
        Me.superValueMeal5Label.Name = "superValueMeal5Label"
        Me.superValueMeal5Label.Size = New System.Drawing.Size(223, 17)
        Me.superValueMeal5Label.TabIndex = 62
        Me.superValueMeal5Label.Text = "6pcs Chicken McNuggets® Super "
        '
        'superValueMeal4ConLabel
        '
        Me.superValueMeal4ConLabel.AutoSize = True
        Me.superValueMeal4ConLabel.Location = New System.Drawing.Point(1053, 196)
        Me.superValueMeal4ConLabel.Name = "superValueMeal4ConLabel"
        Me.superValueMeal4ConLabel.Size = New System.Drawing.Size(126, 17)
        Me.superValueMeal4ConLabel.TabIndex = 61
        Me.superValueMeal4ConLabel.Text = "Value Meal            "
        '
        'superValueMeal4Label
        '
        Me.superValueMeal4Label.AutoSize = True
        Me.superValueMeal4Label.Location = New System.Drawing.Point(1053, 179)
        Me.superValueMeal4Label.Name = "superValueMeal4Label"
        Me.superValueMeal4Label.Size = New System.Drawing.Size(202, 17)
        Me.superValueMeal4Label.TabIndex = 60
        Me.superValueMeal4Label.Text = "Sweet Chilli Fish Burger Super "
        '
        'superValueMealPrice3Label
        '
        Me.superValueMealPrice3Label.AutoSize = True
        Me.superValueMealPrice3Label.Location = New System.Drawing.Point(716, 196)
        Me.superValueMealPrice3Label.Name = "superValueMealPrice3Label"
        Me.superValueMealPrice3Label.Size = New System.Drawing.Size(101, 17)
        Me.superValueMealPrice3Label.TabIndex = 59
        Me.superValueMealPrice3Label.Text = "From RM16.51"
        '
        'superValueMeal3Label
        '
        Me.superValueMeal3Label.AutoSize = True
        Me.superValueMeal3Label.Location = New System.Drawing.Point(716, 179)
        Me.superValueMeal3Label.Name = "superValueMeal3Label"
        Me.superValueMeal3Label.Size = New System.Drawing.Size(207, 17)
        Me.superValueMeal3Label.TabIndex = 58
        Me.superValueMeal3Label.Text = "Filet-O-Fish™ Super Value Meal"
        '
        'superValueMealPrice2Label
        '
        Me.superValueMealPrice2Label.AutoSize = True
        Me.superValueMealPrice2Label.Location = New System.Drawing.Point(370, 196)
        Me.superValueMealPrice2Label.Name = "superValueMealPrice2Label"
        Me.superValueMealPrice2Label.Size = New System.Drawing.Size(101, 17)
        Me.superValueMealPrice2Label.TabIndex = 57
        Me.superValueMealPrice2Label.Text = "From RM17.92"
        '
        'superValueMeal2Label
        '
        Me.superValueMeal2Label.AutoSize = True
        Me.superValueMeal2Label.Location = New System.Drawing.Point(370, 179)
        Me.superValueMeal2Label.Name = "superValueMeal2Label"
        Me.superValueMeal2Label.Size = New System.Drawing.Size(249, 17)
        Me.superValueMeal2Label.TabIndex = 56
        Me.superValueMeal2Label.Text = "McChicken® Deluxe Super Value Meal"
        '
        'superValueMealPrice1Label
        '
        Me.superValueMealPrice1Label.AutoSize = True
        Me.superValueMealPrice1Label.Location = New System.Drawing.Point(20, 196)
        Me.superValueMealPrice1Label.Name = "superValueMealPrice1Label"
        Me.superValueMealPrice1Label.Size = New System.Drawing.Size(101, 17)
        Me.superValueMealPrice1Label.TabIndex = 55
        Me.superValueMealPrice1Label.Text = "From RM16.51"
        '
        'superValueMeal1Label
        '
        Me.superValueMeal1Label.AutoSize = True
        Me.superValueMeal1Label.Location = New System.Drawing.Point(17, 179)
        Me.superValueMeal1Label.Name = "superValueMeal1Label"
        Me.superValueMeal1Label.Size = New System.Drawing.Size(206, 17)
        Me.superValueMeal1Label.TabIndex = 54
        Me.superValueMeal1Label.Text = "McChicken® Super Value Meal "
        '
        'superValueMeal1PictureBox
        '
        Me.superValueMeal1PictureBox.Image = CType(resources.GetObject("superValueMeal1PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal1PictureBox.Location = New System.Drawing.Point(16, 10)
        Me.superValueMeal1PictureBox.Name = "superValueMeal1PictureBox"
        Me.superValueMeal1PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal1PictureBox.TabIndex = 48
        Me.superValueMeal1PictureBox.TabStop = False
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(505, 117)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(8, 8)
        Me.FlowLayoutPanel1.TabIndex = 53
        '
        'superValueMeal5PictureBox
        '
        Me.superValueMeal5PictureBox.Image = CType(resources.GetObject("superValueMeal5PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal5PictureBox.Location = New System.Drawing.Point(1360, 10)
        Me.superValueMeal5PictureBox.Name = "superValueMeal5PictureBox"
        Me.superValueMeal5PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal5PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal5PictureBox.TabIndex = 52
        Me.superValueMeal5PictureBox.TabStop = False
        '
        'superValueMeal4PictureBox
        '
        Me.superValueMeal4PictureBox.Image = CType(resources.GetObject("superValueMeal4PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal4PictureBox.Location = New System.Drawing.Point(1056, 10)
        Me.superValueMeal4PictureBox.Name = "superValueMeal4PictureBox"
        Me.superValueMeal4PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal4PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal4PictureBox.TabIndex = 51
        Me.superValueMeal4PictureBox.TabStop = False
        '
        'superValueMeal3PictureBox
        '
        Me.superValueMeal3PictureBox.Image = CType(resources.GetObject("superValueMeal3PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal3PictureBox.Location = New System.Drawing.Point(719, 10)
        Me.superValueMeal3PictureBox.Name = "superValueMeal3PictureBox"
        Me.superValueMeal3PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal3PictureBox.TabIndex = 50
        Me.superValueMeal3PictureBox.TabStop = False
        '
        'superValueMeal2PictureBox
        '
        Me.superValueMeal2PictureBox.Image = CType(resources.GetObject("superValueMeal2PictureBox.Image"), System.Drawing.Image)
        Me.superValueMeal2PictureBox.Location = New System.Drawing.Point(369, 10)
        Me.superValueMeal2PictureBox.Name = "superValueMeal2PictureBox"
        Me.superValueMeal2PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.superValueMeal2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.superValueMeal2PictureBox.TabIndex = 49
        Me.superValueMeal2PictureBox.TabStop = False
        '
        'superValueMealPanel
        '
        Me.superValueMealPanel.AutoScroll = True
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice13Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice15Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice11Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice12Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice6Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice7Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice10Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice5Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice9Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice4Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal6ConLabel)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal6Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal15ConLabel)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal10ConLabel)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal15Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal10Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal15PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice14Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal9ConLabel)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal14Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal6PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal13ConLabel)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal9Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal13Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice8Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal12ConLabel)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal8Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal12Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal7ConLabel)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal11ConLabel)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal7Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal11Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal10PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal9PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal14PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal13PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal8PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal12PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal7PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal11PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.Label9)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal5Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal4ConLabel)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal4Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice3Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal3Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice2Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal2Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMealPrice1Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal1Label)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal1PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.FlowLayoutPanel1)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal5PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal4PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal3PictureBox)
        Me.superValueMealPanel.Controls.Add(Me.superValueMeal2PictureBox)
        Me.superValueMealPanel.Location = New System.Drawing.Point(12, 112)
        Me.superValueMealPanel.Name = "superValueMealPanel"
        Me.superValueMealPanel.Size = New System.Drawing.Size(1650, 615)
        Me.superValueMealPanel.TabIndex = 48
        '
        'superValueMealPrice13Label
        '
        Me.superValueMealPrice13Label.AutoSize = True
        Me.superValueMealPrice13Label.Location = New System.Drawing.Point(851, 683)
        Me.superValueMealPrice13Label.Name = "superValueMealPrice13Label"
        Me.superValueMealPrice13Label.Size = New System.Drawing.Size(105, 17)
        Me.superValueMealPrice13Label.TabIndex = 88
        Me.superValueMealPrice13Label.Text = "From  RM18.40"
        '
        'superValueMealPrice15Label
        '
        Me.superValueMealPrice15Label.AutoSize = True
        Me.superValueMealPrice15Label.Location = New System.Drawing.Point(1492, 683)
        Me.superValueMealPrice15Label.Name = "superValueMealPrice15Label"
        Me.superValueMealPrice15Label.Size = New System.Drawing.Size(105, 17)
        Me.superValueMealPrice15Label.TabIndex = 87
        Me.superValueMealPrice15Label.Text = " From RM20.28"
        '
        'superValueMealPrice11Label
        '
        Me.superValueMealPrice11Label.AutoSize = True
        Me.superValueMealPrice11Label.Location = New System.Drawing.Point(148, 683)
        Me.superValueMealPrice11Label.Name = "superValueMealPrice11Label"
        Me.superValueMealPrice11Label.Size = New System.Drawing.Size(101, 17)
        Me.superValueMealPrice11Label.TabIndex = 86
        Me.superValueMealPrice11Label.Text = "From RM24.53"
        '
        'superValueMealPrice12Label
        '
        Me.superValueMealPrice12Label.AutoSize = True
        Me.superValueMealPrice12Label.Location = New System.Drawing.Point(501, 683)
        Me.superValueMealPrice12Label.Name = "superValueMealPrice12Label"
        Me.superValueMealPrice12Label.Size = New System.Drawing.Size(101, 17)
        Me.superValueMealPrice12Label.TabIndex = 85
        Me.superValueMealPrice12Label.Text = "From RM24.53"
        '
        'superValueMealPrice6Label
        '
        Me.superValueMealPrice6Label.AutoSize = True
        Me.superValueMealPrice6Label.Location = New System.Drawing.Point(148, 436)
        Me.superValueMealPrice6Label.Name = "superValueMealPrice6Label"
        Me.superValueMealPrice6Label.Size = New System.Drawing.Size(101, 17)
        Me.superValueMealPrice6Label.TabIndex = 84
        Me.superValueMealPrice6Label.Text = "From RM19.81"
        '
        'superValueMealPrice7Label
        '
        Me.superValueMealPrice7Label.AutoSize = True
        Me.superValueMealPrice7Label.Location = New System.Drawing.Point(501, 436)
        Me.superValueMealPrice7Label.Name = "superValueMealPrice7Label"
        Me.superValueMealPrice7Label.Size = New System.Drawing.Size(105, 17)
        Me.superValueMealPrice7Label.TabIndex = 83
        Me.superValueMealPrice7Label.Text = " From RM20.28"
        '
        'superValueMealPrice10Label
        '
        Me.superValueMealPrice10Label.AutoSize = True
        Me.superValueMealPrice10Label.Location = New System.Drawing.Point(1492, 436)
        Me.superValueMealPrice10Label.Name = "superValueMealPrice10Label"
        Me.superValueMealPrice10Label.Size = New System.Drawing.Size(105, 17)
        Me.superValueMealPrice10Label.TabIndex = 82
        Me.superValueMealPrice10Label.Text = " From RM20.28"
        '
        'superValueMealPrice5Label
        '
        Me.superValueMealPrice5Label.AutoSize = True
        Me.superValueMealPrice5Label.Location = New System.Drawing.Point(1492, 196)
        Me.superValueMealPrice5Label.Name = "superValueMealPrice5Label"
        Me.superValueMealPrice5Label.Size = New System.Drawing.Size(105, 17)
        Me.superValueMealPrice5Label.TabIndex = 81
        Me.superValueMealPrice5Label.Text = " From RM16.51"
        '
        'superValueMealPrice9Label
        '
        Me.superValueMealPrice9Label.AutoSize = True
        Me.superValueMealPrice9Label.Location = New System.Drawing.Point(1188, 436)
        Me.superValueMealPrice9Label.Name = "superValueMealPrice9Label"
        Me.superValueMealPrice9Label.Size = New System.Drawing.Size(105, 17)
        Me.superValueMealPrice9Label.TabIndex = 80
        Me.superValueMealPrice9Label.Text = " From RM20.28"
        '
        'superValueMealPrice4Label
        '
        Me.superValueMealPrice4Label.AutoSize = True
        Me.superValueMealPrice4Label.Location = New System.Drawing.Point(1192, 196)
        Me.superValueMealPrice4Label.Name = "superValueMealPrice4Label"
        Me.superValueMealPrice4Label.Size = New System.Drawing.Size(101, 17)
        Me.superValueMealPrice4Label.TabIndex = 79
        Me.superValueMealPrice4Label.Text = "From RM19.34"
        '
        'superValueMealLabel
        '
        Me.superValueMealLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.superValueMealLabel.Font = New System.Drawing.Font("Segoe UI", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.superValueMealLabel.Location = New System.Drawing.Point(3, 10)
        Me.superValueMealLabel.Name = "superValueMealLabel"
        Me.superValueMealLabel.Size = New System.Drawing.Size(1670, 99)
        Me.superValueMealLabel.TabIndex = 47
        Me.superValueMealLabel.Text = "Super Value Meal"
        '
        'SuperValueMeal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.superValueMealPanel)
        Me.Controls.Add(Me.superValueMealLabel)
        Me.Name = "SuperValueMeal"
        Me.Size = New System.Drawing.Size(1676, 1038)
        CType(Me.superValueMeal15PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal6PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal10PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal9PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal14PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal13PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal8PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal12PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal7PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal11PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal1PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal5PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal4PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal3PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.superValueMeal2PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.superValueMealPanel.ResumeLayout(False)
        Me.superValueMealPanel.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents superValueMeal6ConLabel As Label
    Friend WithEvents superValueMeal6Label As Label
    Friend WithEvents superValueMeal15ConLabel As Label
    Friend WithEvents superValueMeal10ConLabel As Label
    Friend WithEvents superValueMeal15Label As Label
    Friend WithEvents superValueMeal10Label As Label
    Friend WithEvents superValueMeal15PictureBox As PictureBox
    Friend WithEvents superValueMealPrice14Label As Label
    Friend WithEvents superValueMeal9ConLabel As Label
    Friend WithEvents superValueMeal14Label As Label
    Friend WithEvents superValueMeal6PictureBox As PictureBox
    Friend WithEvents superValueMeal13ConLabel As Label
    Friend WithEvents superValueMeal9Label As Label
    Friend WithEvents superValueMeal13Label As Label
    Friend WithEvents superValueMealPrice8Label As Label
    Friend WithEvents superValueMeal12ConLabel As Label
    Friend WithEvents superValueMeal8Label As Label
    Friend WithEvents superValueMeal12Label As Label
    Friend WithEvents superValueMeal7ConLabel As Label
    Friend WithEvents superValueMeal11ConLabel As Label
    Friend WithEvents superValueMeal7Label As Label
    Friend WithEvents superValueMeal11Label As Label
    Friend WithEvents superValueMeal10PictureBox As PictureBox
    Friend WithEvents superValueMeal9PictureBox As PictureBox
    Friend WithEvents superValueMeal14PictureBox As PictureBox
    Friend WithEvents superValueMeal13PictureBox As PictureBox
    Friend WithEvents superValueMeal8PictureBox As PictureBox
    Friend WithEvents superValueMeal12PictureBox As PictureBox
    Friend WithEvents superValueMeal7PictureBox As PictureBox
    Friend WithEvents superValueMeal11PictureBox As PictureBox
    Friend WithEvents Label9 As Label
    Friend WithEvents superValueMeal5Label As Label
    Friend WithEvents superValueMeal4ConLabel As Label
    Friend WithEvents superValueMeal4Label As Label
    Friend WithEvents superValueMealPrice3Label As Label
    Friend WithEvents superValueMeal3Label As Label
    Friend WithEvents superValueMealPrice2Label As Label
    Friend WithEvents superValueMeal2Label As Label
    Friend WithEvents superValueMealPrice1Label As Label
    Friend WithEvents superValueMeal1Label As Label
    Friend WithEvents superValueMeal1PictureBox As PictureBox
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents superValueMeal5PictureBox As PictureBox
    Friend WithEvents superValueMeal4PictureBox As PictureBox
    Friend WithEvents superValueMeal3PictureBox As PictureBox
    Friend WithEvents superValueMeal2PictureBox As PictureBox
    Friend WithEvents superValueMealPanel As Panel
    Friend WithEvents superValueMealLabel As Label
    Friend WithEvents superValueMealPrice4Label As Label
    Friend WithEvents superValueMealPrice5Label As Label
    Friend WithEvents superValueMealPrice9Label As Label
    Friend WithEvents superValueMealPrice13Label As Label
    Friend WithEvents superValueMealPrice11Label As Label
    Friend WithEvents superValueMealPrice12Label As Label
    Friend WithEvents superValueMealPrice6Label As Label
    Friend WithEvents superValueMealPrice7Label As Label
    Friend WithEvents superValueMealPrice10Label As Label
    Friend WithEvents superValueMealPrice15Label As Label
End Class
