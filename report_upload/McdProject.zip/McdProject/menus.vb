﻿Public Class menus
    Public takeaway As Boolean = False
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles superValueMealLabel.Click
        label_color_refresh()
        UserControl11.BringToFront()
        superValueMealLabel.ForeColor = Color.Red
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles mcCafeCakeLabel.Click
        label_color_refresh()
        McCafeCake1.BringToFront()
        mcCafeCakeLabel.ForeColor = Color.Red
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles familyMealLabel.Click
        label_color_refresh()
        FamilyMeal1.BringToFront()
        familyMealLabel.ForeColor = Color.Red
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles valueMealAndAlaCarteLabel.Click
        label_color_refresh()
        UserControl21.BringToFront()
        valueMealAndAlaCarteLabel.ForeColor = Color.Red
    End Sub

    Private Sub menus_Load(sender As Object, e As EventArgs) Handles Me.Load
        UserControl11.BringToFront()
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles partyPackageLabel.Click
        label_color_refresh()
        PartyPackage1.BringToFront()
        partyPackageLabel.ForeColor = Color.Red
    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles mcCafeDrinkLabel.Click
        label_color_refresh()
        McCafeDrink1.BringToFront()
        mcCafeDrinkLabel.ForeColor = Color.Red
    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles beverageLabel.Click
        label_color_refresh()
        Beverage1.BringToFront()
        beverageLabel.ForeColor = Color.Red
    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles dessertLabel.Click
        label_color_refresh()
        Dessert1.BringToFront()
        dessertLabel.ForeColor = Color.Red
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles happyMealLabel.Click
        label_color_refresh()
        HappyMeal1.BringToFront()
        happyMealLabel.ForeColor = Color.Red
    End Sub

    Private Sub Label11_Click(sender As Object, e As EventArgs) Handles sideLabel.Click
        label_color_refresh()
        Side1.BringToFront()
        sideLabel.ForeColor = Color.Red
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)
        'MyOrder1.BringToFront()
    End Sub

    Private Sub nextButton_Click(sender As Object, e As EventArgs) Handles nextButton.Click
        Dim totalwannapay As Double
        For i As Integer = 0 To 90
            If set_detail(i, 2) <> 0 Then
                totalwannapay = (set_detail(i, 1) * set_detail(i, 2))
            End If
        Next
        totalwannapay += (totalwannapay * 0.06)
        If takeaway = True Then
            totalwannapay += 1.2
        End If
        Pay.feeLabel.Text = totalwannapay.ToString("f2")
        orderCartLabel.Visible = True
        Label18.Visible = False
        taxLabel.Visible = False
        Label13.Visible = False
        Label17.Visible = False
        TotalPriceLabel.Visible = False
        Label12.Visible = False
        Label15.Visible = False
        TotalItemLabel.Visible = False
        viewOrderLabel.Visible = False
        nextButton.Enabled = False
        cancelsButton.BackColor = Color.FromArgb(247, 94, 100)
        nextButton.BackColor = Color.FromArgb(80, 97, 77)
        For i As Integer = 0 To 90
            set_detail(i, 2) = 0
        Next
        Pay.Show()
        Me.Close()
    End Sub

    Private Sub cancelButton_Click(sender As Object, e As EventArgs) Handles cancelsButton.Click
        CancelOrder.Show()

    End Sub

    Private Sub viewOrderLabel_Click(sender As Object, e As EventArgs) Handles viewOrderLabel.Click
        Dim setnameoutput As String
        Dim quantityoutput As String
        Dim priceoutput As String
        Dim alreadyexist As Boolean = True
        Dim temp As Double

        For i As Integer = 0 To 90

            If set_detail(i, 2) <> 0 Then
                temp = (set_detail(i, 1) * set_detail(i, 2))
                If alreadyexist = True Then
                    setnameoutput = set_detail(i, 0).ToString
                    quantityoutput = set_detail(i, 2).ToString
                    priceoutput = temp.ToString("f2")
                    alreadyexist = False
                Else
                    setnameoutput = setnameoutput + vbNewLine + vbNewLine + set_detail(i, 0).ToString
                    quantityoutput = quantityoutput + vbNewLine + vbNewLine + set_detail(i, 2).ToString
                    priceoutput = priceoutput + vbNewLine + vbNewLine + temp.ToString("f2")
                End If
            End If
        Next

        Dim total_price As Double
        Dim totalpricewithtax As Double
        For i As Integer = 0 To 90
            If set_detail(i, 2) <> 0 Then
                total_price += (set_detail(i, 1) * set_detail(i, 2))
            End If
        Next
        totalpricewithtax = total_price * 1.06
        setnameoutput = setnameoutput + vbNewLine + vbNewLine + "Tax 6%"
        priceoutput = priceoutput + vbNewLine + vbNewLine + (total_price * 0.06).ToString("f2")
        If takeaway = True Then
            setnameoutput = setnameoutput + vbNewLine + vbNewLine + "Takeaway Fee"
            priceoutput = priceoutput + vbNewLine + vbNewLine + "1.20"

            totalpricewithtax += 1.2
        End If
        ViewOrder.FoodNameLabel.Text = setnameoutput
        ViewOrder.FoodsPriceLabel.Text = priceoutput
        ViewOrder.FoodsQuantityLabel.Text = quantityoutput
        ViewOrder.totalPriceLabel.Text = totalpricewithtax.ToString("f2")


        ViewOrder.Show()
    End Sub

    Private Sub Label2_MouseHover(sender As Object, e As EventArgs) Handles superValueMealLabel.MouseHover
        superValueMealLabel.ForeColor = Color.Yellow

    End Sub

    Private Sub Label2_MouseLeave(sender As Object, e As EventArgs) Handles superValueMealLabel.MouseLeave
        If superValueMealLabel.ForeColor <> Color.Red Then
            superValueMealLabel.ForeColor = Color.Black
        End If
    End Sub

    Private Sub Label3_MouseHover(sender As Object, e As EventArgs) Handles familyMealLabel.MouseHover
        familyMealLabel.ForeColor = Color.Yellow
    End Sub

    Private Sub Label3_MouseLeave(sender As Object, e As EventArgs) Handles familyMealLabel.MouseLeave
        If familyMealLabel.ForeColor <> Color.Red Then
            familyMealLabel.ForeColor = Color.Black
        End If
    End Sub

    Private Sub Label4_MouseHover(sender As Object, e As EventArgs) Handles valueMealAndAlaCarteLabel.MouseHover
        valueMealAndAlaCarteLabel.ForeColor = Color.Yellow
    End Sub

    Private Sub Label4_MouseLeave(sender As Object, e As EventArgs) Handles valueMealAndAlaCarteLabel.MouseLeave
        If valueMealAndAlaCarteLabel.ForeColor <> Color.Red Then
            valueMealAndAlaCarteLabel.ForeColor = Color.Black
        End If
    End Sub

    Private Sub Label5_MouseHover(sender As Object, e As EventArgs) Handles partyPackageLabel.MouseHover
        partyPackageLabel.ForeColor = Color.Yellow
    End Sub

    Private Sub Label5_MouseLeave(sender As Object, e As EventArgs) Handles partyPackageLabel.MouseLeave
        If partyPackageLabel.ForeColor <> Color.Red Then
            partyPackageLabel.ForeColor = Color.Black
        End If
    End Sub

    Private Sub Label6_MouseHover(sender As Object, e As EventArgs) Handles mcCafeCakeLabel.MouseHover
        mcCafeCakeLabel.ForeColor = Color.Yellow
    End Sub

    Private Sub Label6_MouseLeave(sender As Object, e As EventArgs) Handles mcCafeCakeLabel.MouseLeave
        If mcCafeCakeLabel.ForeColor <> Color.Red Then
            mcCafeCakeLabel.ForeColor = Color.Black
        End If
    End Sub

    Private Sub Label7_MouseHover(sender As Object, e As EventArgs) Handles mcCafeDrinkLabel.MouseHover
        mcCafeDrinkLabel.ForeColor = Color.Yellow
    End Sub

    Private Sub Label7_MouseLeave(sender As Object, e As EventArgs) Handles mcCafeDrinkLabel.MouseLeave
        If mcCafeDrinkLabel.ForeColor <> Color.Red Then
            mcCafeDrinkLabel.ForeColor = Color.Black
        End If
    End Sub

    Private Sub Label8_MouseHover(sender As Object, e As EventArgs) Handles beverageLabel.MouseHover
        beverageLabel.ForeColor = Color.Yellow
    End Sub

    Private Sub Label8_MouseLeave(sender As Object, e As EventArgs) Handles beverageLabel.MouseLeave
        If beverageLabel.ForeColor <> Color.Red Then
            beverageLabel.ForeColor = Color.Black
        End If
    End Sub

    Private Sub Label9_MouseHover(sender As Object, e As EventArgs) Handles dessertLabel.MouseHover
        dessertLabel.ForeColor = Color.Yellow
    End Sub

    Private Sub Label9_MouseLeave(sender As Object, e As EventArgs) Handles dessertLabel.MouseLeave
        If dessertLabel.ForeColor <> Color.Red Then
            dessertLabel.ForeColor = Color.Black
        End If
    End Sub

    Private Sub Label10_MouseHover(sender As Object, e As EventArgs) Handles happyMealLabel.MouseHover
        happyMealLabel.ForeColor = Color.Yellow
    End Sub

    Private Sub Label10_MouseLeave(sender As Object, e As EventArgs) Handles happyMealLabel.MouseLeave
        If happyMealLabel.ForeColor <> Color.Red Then
            happyMealLabel.ForeColor = Color.Black
        End If
    End Sub

    Private Sub Label11_MouseHover(sender As Object, e As EventArgs) Handles sideLabel.MouseHover
        sideLabel.ForeColor = Color.Yellow
    End Sub

    Private Sub Label11_MouseLeave(sender As Object, e As EventArgs) Handles sideLabel.MouseLeave
        If sideLabel.ForeColor <> Color.Red Then
            sideLabel.ForeColor = Color.Black
        End If
    End Sub

    Private Sub label_color_refresh()
        superValueMealLabel.ForeColor = Color.Black
        familyMealLabel.ForeColor = Color.Black
        valueMealAndAlaCarteLabel.ForeColor = Color.Black
        partyPackageLabel.ForeColor = Color.Black
        mcCafeCakeLabel.ForeColor = Color.Black
        mcCafeDrinkLabel.ForeColor = Color.Black
        beverageLabel.ForeColor = Color.Black
        dessertLabel.ForeColor = Color.Black
        happyMealLabel.ForeColor = Color.Black
        sideLabel.ForeColor = Color.Black
    End Sub
    Public set_detail(,) = {
        {"McChicken® Super Value Meal ", 16.51, 0},
        {"McChicken® Deluxe Super Value Meal", 17.92, 0},
        {"Filet-O-Fish™ Super Value Meal", 16.51, 0},
        {"Sweet Chilli Fish Burger Super", 19.34, 0},
        {"Chicken McNuggets® Super ", 16.51, 0},
        {"9pcs Chicken McNuggets® Super ", 19.81, 0},
        {"Spicy Chicken McDeluxe™ Super ", 20.28, 0},
        {"GCB Super Value Meal", 20.28, 0},
        {"Ayam Goreng McD™ Regular (2pcs) ", 20.28, 0},
        {"Ayam Goreng McD™ Spicy (2pcs) ", 20.28, 0},
        {"Ayam Goreng McD™ Spicy (3pcs) ", 24.53, 0},
        {"Ayam Goreng McD™ Regular (3pcs) ", 24.53, 0},
        {"Double Cheeseburger Super Value meal", 18.4, 0},
        {"Big Mac™ Super Value Meal", 19.34, 0},
        {"Quarter Pounder™ with Cheese ", 20.28, 0},
        {"Family Meal - Spicy", 37.73, 0},
        {"Family Meal - Regular", 37.73, 0},
        {"Family Meal - Mixed", 37.73, 0},
        {"Nasi Lemak McD™ + Rendang Ayam", 17.92, 0},
        {"Nasi Lemak McD™ + SCM Cutlet", 16.03, 0},
        {"Nasi Lemak McD™ + GCB Cutlet", 16.03, 0},
        {"Spicy Korean Chicken Burger", 14.62, 0},
        {"Filet-O-Fish™ Super Value Meal", 16.51, 0},
        {"Spicy Korean Beef Burger", 14.62, 0},
        {"Double Spicy Korean Chicken Burger", 18.4, 0},
        {"Double Cheeseburger", 10.37, 0},
        {"Triple Cheeseburger", 16.03, 0},
        {"Big Mac™", 11.31, 0},
        {"Mega Mac™", 17.45, 0},
        {"Quarter Pounder™ with Cheese", 12.25, 0},
        {"Double Quarter Pounder™ with Cheese", 18.4, 0},
        {"Smoky Grilled Beef", 15.57, 0},
        {"McChicken®", 8.49, 0},
        {"Home Party Package A", 94.34, 0},
        {"Home Party Package B", 141.51, 0},
        {"Party Pack A", 9.0, 0},
        {"Party Pack B", 9.0, 0},
        {"Party Pack C", 9.0, 0},
        {"Iced Mocha", 10.37, 0},
        {"Iced Chocolate", 10.37, 0},
        {"Iced Latte", 8.96, 0},
        {"Iced Americano", 8.96, 0},
        {"Flat White", 7.54, 0},
        {"Latte", 7.54, 0},
        {"Cappuccino", 7.54, 0},
        {"Americano", 7.54, 0},
        {"Premium Roast Coffee", 4.72, 0},
        {"Belgium Chocolate + Coffee", 12.25, 0},
        {"Classic Cheesecake + Coffee", 12.25, 0},
        {"Cookies & Cream Cheesecake + Coffee", 12.25, 0},
        {"Red Velvet Cake + Coffee", 12.25, 0},
        {"Classic Cheesecake + Coffee", 12.25, 0},
        {"Cookies & Cream Cheesecake + Coffee", 12.25, 0},
        {"Red Velvet Cake + Coffee", 12.25, 0},
        {"Belgium Chocolate + Coffee", 12.25, 0},
        {"Banana Walnut Muffin", 6.13, 0},
        {"Double Chocolate Muffin", 6.13, 0},
        {"Belgium Chocolate Cake", 11.31, 0},
        {"Chocolate Lava Cake", 11.31, 0},
        {"Classic Cheesecake", 11.31, 0},
        {"Cookies & Cream Cheesecake", 11.31, 0},
        {"Red Velvet Cake", 11.31, 0},
        {"100 Plus", 4.53, 0},
        {"Coca-Cola®", 4.53, 0},
        {"Sprite®", 4.53, 0},
        {"Iced Lemon Tea", 5.94, 0},
        {"Banana Walnut Muffin", 6.13, 0},
        {"Drinking water", 4.53, 0},
        {"MILO®", 7.08, 0},
        {"Hot MILO®", 4.53, 0},
        {"Hot Teh Tarik", 4.72, 0},
        {"Hot Tea", 4.72, 0},
        {"Premium Roast Coffee", 4.72, 0},
        {"Cendol and Chocolate Sundae", 5.19, 0},
        {"Cendol McFlurry™", 7.08, 0},
        {"Corn Pie", 4.25, 0},
        {"Black Forest Pie", 4.25, 0},
        {"OREO® McFlurry™", 6.6, 0},
        {"Chocolate Sundae", 4.53, 0},
        {"Strawberry Sundae", 4.53, 0},
        {"Apple Pie", 3.77, 0},
        {"Chicken Burger", 10.37, 0},
        {"4pcs Chicken McNuggets®", 10.37, 0},
        {"Ayam Goreng McD™", 10.37, 0},
        {"Cheeseburger", 10.37, 0},
        {"Goreng McD™ Spicy (1pc)", 10.37, 0},
        {"Bubur Ayam McD™", 10.37, 0},
        {"Criss Cut Fries", 6.13, 0},
        {"French Fries", 5.19, 0},
        {"Corn", 4.25, 0},
        {"Bubur Ayam McD™", 6.6, 0}
        }

End Class