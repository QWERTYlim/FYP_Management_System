﻿Public Class HappyMeal
    Private Sub exitButton_Click(sender As Object, e As EventArgs) 
        Application.Exit()
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles happyMealPanel.Paint

    End Sub
    Public Sub quantitys(ByVal setnum As Integer)
        Dim picture() = {happyMeal1PictureBox, happyMeal2PictureBox, happyMeal3PictureBox, happyMeal4PictureBox, happyMeal5PictureBox, happyMeal6PictureBox}
        Dim price() = {10.37, 10.37, 10.37, 10.37, 10.37, 10.37}
        Dim setname() = {happyMeal1Label.Text, happyMeal2Label.Text, happyMeal3Label.Text, happyMeal4Label.Text, happyMeal5Label.Text, happyMeal6Label.Text}
        Quantity.SetPictureBox.Image = picture(setnum).Image
        Quantity.Label2.Text = price(setnum)
        Quantity.Label1.Text = setname(setnum)
        Quantity.one_set_price = price(setnum)
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles happyMeal1PictureBox.Click
        quantitys(0)
        Quantity.Show()
        Quantity.set_choosen = 81
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles happyMeal2PictureBox.Click
        quantitys(1)
        Quantity.Show()
        Quantity.set_choosen = 82
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles happyMeal3PictureBox.Click
        quantitys(2)
        Quantity.Show()
        Quantity.set_choosen = 83
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles happyMeal4PictureBox.Click
        quantitys(3)
        Quantity.Show()
        Quantity.set_choosen = 84
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles happyMeal5PictureBox.Click
        quantitys(4)
        Quantity.Show()
        Quantity.set_choosen = 85
    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles happyMeal6PictureBox.Click
        quantitys(5)
        Quantity.Show()
        Quantity.set_choosen = 86
    End Sub
End Class
