﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CancelOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CancelOrder))
        Me.questionLabel = New System.Windows.Forms.Label()
        Me.mcdLogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.noButton = New System.Windows.Forms.Button()
        Me.yesButton = New System.Windows.Forms.Button()
        Me.delay = New System.Windows.Forms.Timer(Me.components)
        CType(Me.mcdLogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'questionLabel
        '
        Me.questionLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.questionLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.questionLabel.Location = New System.Drawing.Point(234, 260)
        Me.questionLabel.Name = "questionLabel"
        Me.questionLabel.Size = New System.Drawing.Size(1457, 46)
        Me.questionLabel.TabIndex = 16
        Me.questionLabel.Text = "Would you like to cancel the order?"
        Me.questionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'mcdLogoPictureBox
        '
        Me.mcdLogoPictureBox.Image = CType(resources.GetObject("mcdLogoPictureBox.Image"), System.Drawing.Image)
        Me.mcdLogoPictureBox.Location = New System.Drawing.Point(759, 48)
        Me.mcdLogoPictureBox.Name = "mcdLogoPictureBox"
        Me.mcdLogoPictureBox.Size = New System.Drawing.Size(389, 195)
        Me.mcdLogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcdLogoPictureBox.TabIndex = 15
        Me.mcdLogoPictureBox.TabStop = False
        '
        'noButton
        '
        Me.noButton.AutoSize = True
        Me.noButton.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.noButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(4, Byte), Integer), CType(CType(4, Byte), Integer))
        Me.noButton.Location = New System.Drawing.Point(778, 368)
        Me.noButton.Name = "noButton"
        Me.noButton.Size = New System.Drawing.Size(156, 55)
        Me.noButton.TabIndex = 17
        Me.noButton.Text = "No"
        Me.noButton.UseVisualStyleBackColor = True
        '
        'yesButton
        '
        Me.yesButton.AutoSize = True
        Me.yesButton.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.yesButton.ForeColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.yesButton.Location = New System.Drawing.Point(1011, 368)
        Me.yesButton.Name = "yesButton"
        Me.yesButton.Size = New System.Drawing.Size(156, 55)
        Me.yesButton.TabIndex = 18
        Me.yesButton.Text = "Yes"
        Me.yesButton.UseVisualStyleBackColor = True
        '
        'delay
        '
        Me.delay.Interval = 3000
        '
        'CancelOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1924, 1053)
        Me.Controls.Add(Me.yesButton)
        Me.Controls.Add(Me.noButton)
        Me.Controls.Add(Me.questionLabel)
        Me.Controls.Add(Me.mcdLogoPictureBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "CancelOrder"
        Me.Text = "Form2"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.mcdLogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents questionLabel As Label
    Friend WithEvents mcdLogoPictureBox As PictureBox
    Friend WithEvents noButton As Button
    Friend WithEvents yesButton As Button
    Friend WithEvents delay As Timer
End Class
