﻿Public Class SuperValueMeal
    Private Sub exitButton_Click(sender As Object, e As EventArgs) 
        Application.Exit()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles superValueMeal1PictureBox.Click
        quantitys(0)
        Quantity.Show()
        Quantity.set_choosen = 0
    End Sub

    Public Sub quantitys(ByVal setnum As Integer)
        Dim picture() = {superValueMeal1PictureBox, superValueMeal2PictureBox, superValueMeal3PictureBox, superValueMeal4PictureBox, superValueMeal5PictureBox, superValueMeal6PictureBox, superValueMeal7PictureBox, superValueMeal8PictureBox, superValueMeal9PictureBox, superValueMeal10PictureBox, superValueMeal11PictureBox, superValueMeal12PictureBox, superValueMeal13PictureBox, superValueMeal14PictureBox, superValueMeal15PictureBox}
        Dim price() = {16.51, 17.92, 16.51, 19.34, 16.51, 19.81, 20.28, 20.28, 20.28, 20.28, 24.53, 24.53, 18.4, 19.34, 20.28}
        Dim setname() = {superValueMeal1Label.Text, superValueMeal2Label.Text, superValueMeal3Label.Text, superValueMeal4Label.Text + superValueMeal4ConLabel.Text, superValueMeal5Label.Text + Label9.Text, superValueMeal6Label.Text + superValueMeal6ConLabel.Text, superValueMeal7Label.Text + superValueMeal7ConLabel.Text, superValueMeal8Label.Text, superValueMeal9Label.Text + superValueMeal9ConLabel.Text, superValueMeal10Label.Text + superValueMeal10ConLabel.Text, superValueMeal11Label.Text + superValueMeal11ConLabel.Text, superValueMeal12Label.Text + superValueMeal12ConLabel.Text, superValueMeal13Label.Text, superValueMeal14Label.Text + superValueMealPrice14Label.Text, superValueMeal15Label.Text + superValueMeal15ConLabel.Text}
        Quantity.SetPictureBox.Image = picture(setnum).Image
        Quantity.Label2.Text = price(setnum)
        Quantity.Label1.Text = setname(setnum)
        Quantity.one_set_price = price(setnum)
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles superValueMeal2PictureBox.Click
        quantitys(1)
        Quantity.Show()
        Quantity.set_choosen = 1
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles superValueMeal3PictureBox.Click
        quantitys(2)
        Quantity.Show()
        Quantity.set_choosen = 2
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles superValueMeal4PictureBox.Click
        quantitys(3)
        Quantity.Show()
        Quantity.set_choosen = 3
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles superValueMeal5PictureBox.Click
        quantitys(4)
        Quantity.Show()
        Quantity.set_choosen = 4
    End Sub

    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles superValueMeal7PictureBox.Click
        quantitys(6)
        Quantity.Show()
        Quantity.set_choosen = 6
    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles superValueMeal6PictureBox.Click
        quantitys(5)
        Quantity.Show()
        Quantity.set_choosen = 5
    End Sub

    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles superValueMeal8PictureBox.Click
        quantitys(7)
        Quantity.set_choosen = 7
        Quantity.Show()
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles superValueMeal9PictureBox.Click
        quantitys(8)
        Quantity.Show()
        Quantity.set_choosen = 8
    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles superValueMeal10PictureBox.Click
        quantitys(9)
        Quantity.Show()
        Quantity.set_choosen = 9
    End Sub

    Private Sub PictureBox11_Click(sender As Object, e As EventArgs) Handles superValueMeal11PictureBox.Click
        quantitys(10)
        Quantity.Show()
        Quantity.set_choosen = 10
    End Sub

    Private Sub PictureBox12_Click(sender As Object, e As EventArgs) Handles superValueMeal12PictureBox.Click
        quantitys(11)
        Quantity.Show()
        Quantity.set_choosen = 11
    End Sub

    Private Sub PictureBox13_Click(sender As Object, e As EventArgs) Handles superValueMeal13PictureBox.Click
        quantitys(12)
        Quantity.Show()
        Quantity.set_choosen = 12
    End Sub

    Private Sub PictureBox14_Click(sender As Object, e As EventArgs) Handles superValueMeal14PictureBox.Click
        quantitys(13)
        Quantity.Show()
        Quantity.set_choosen = 13
    End Sub

    Private Sub PictureBox15_Click(sender As Object, e As EventArgs) Handles superValueMeal15PictureBox.Click
        quantitys(14)
        Quantity.Show()
        Quantity.set_choosen = 14
    End Sub
End Class

