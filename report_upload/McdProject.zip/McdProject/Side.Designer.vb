﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Side
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Side))
        Me.sideLabel = New System.Windows.Forms.Label()
        Me.sidePanel = New System.Windows.Forms.Panel()
        Me.side4PictureBox = New System.Windows.Forms.PictureBox()
        Me.sidePrice1Label = New System.Windows.Forms.Label()
        Me.side2Label = New System.Windows.Forms.Label()
        Me.sidePrice2Label = New System.Windows.Forms.Label()
        Me.side3PictureBox = New System.Windows.Forms.PictureBox()
        Me.side3Label = New System.Windows.Forms.Label()
        Me.side2PictureBox = New System.Windows.Forms.PictureBox()
        Me.sidePrice3Label = New System.Windows.Forms.Label()
        Me.side1PictureBox = New System.Windows.Forms.PictureBox()
        Me.side1Label = New System.Windows.Forms.Label()
        Me.sidePrice4Label = New System.Windows.Forms.Label()
        Me.side4Label = New System.Windows.Forms.Label()
        Me.sidePanel.SuspendLayout()
        CType(Me.side4PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.side3PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.side2PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.side1PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'sideLabel
        '
        Me.sideLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.sideLabel.Font = New System.Drawing.Font("Segoe UI", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sideLabel.Location = New System.Drawing.Point(3, 10)
        Me.sideLabel.Name = "sideLabel"
        Me.sideLabel.Size = New System.Drawing.Size(1670, 99)
        Me.sideLabel.TabIndex = 134
        Me.sideLabel.Text = "Side"
        '
        'sidePanel
        '
        Me.sidePanel.Controls.Add(Me.side4PictureBox)
        Me.sidePanel.Controls.Add(Me.sidePrice1Label)
        Me.sidePanel.Controls.Add(Me.side2Label)
        Me.sidePanel.Controls.Add(Me.sidePrice2Label)
        Me.sidePanel.Controls.Add(Me.side3PictureBox)
        Me.sidePanel.Controls.Add(Me.side3Label)
        Me.sidePanel.Controls.Add(Me.side2PictureBox)
        Me.sidePanel.Controls.Add(Me.sidePrice3Label)
        Me.sidePanel.Controls.Add(Me.side1PictureBox)
        Me.sidePanel.Controls.Add(Me.side1Label)
        Me.sidePanel.Controls.Add(Me.sidePrice4Label)
        Me.sidePanel.Controls.Add(Me.side4Label)
        Me.sidePanel.Location = New System.Drawing.Point(12, 112)
        Me.sidePanel.Name = "sidePanel"
        Me.sidePanel.Size = New System.Drawing.Size(1650, 521)
        Me.sidePanel.TabIndex = 227
        '
        'side4PictureBox
        '
        Me.side4PictureBox.Image = CType(resources.GetObject("side4PictureBox.Image"), System.Drawing.Image)
        Me.side4PictureBox.Location = New System.Drawing.Point(1056, 10)
        Me.side4PictureBox.Name = "side4PictureBox"
        Me.side4PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.side4PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.side4PictureBox.TabIndex = 224
        Me.side4PictureBox.TabStop = False
        '
        'sidePrice1Label
        '
        Me.sidePrice1Label.AutoSize = True
        Me.sidePrice1Label.Location = New System.Drawing.Point(17, 196)
        Me.sidePrice1Label.Name = "sidePrice1Label"
        Me.sidePrice1Label.Size = New System.Drawing.Size(93, 17)
        Me.sidePrice1Label.TabIndex = 225
        Me.sidePrice1Label.Text = "From RM6.13"
        '
        'side2Label
        '
        Me.side2Label.AutoSize = True
        Me.side2Label.Location = New System.Drawing.Point(369, 179)
        Me.side2Label.Name = "side2Label"
        Me.side2Label.Size = New System.Drawing.Size(87, 17)
        Me.side2Label.TabIndex = 214
        Me.side2Label.Text = "French Fries"
        '
        'sidePrice2Label
        '
        Me.sidePrice2Label.AutoSize = True
        Me.sidePrice2Label.Location = New System.Drawing.Point(369, 196)
        Me.sidePrice2Label.Name = "sidePrice2Label"
        Me.sidePrice2Label.Size = New System.Drawing.Size(93, 17)
        Me.sidePrice2Label.TabIndex = 215
        Me.sidePrice2Label.Text = "From RM5.19"
        '
        'side3PictureBox
        '
        Me.side3PictureBox.Image = CType(resources.GetObject("side3PictureBox.Image"), System.Drawing.Image)
        Me.side3PictureBox.Location = New System.Drawing.Point(719, 10)
        Me.side3PictureBox.Name = "side3PictureBox"
        Me.side3PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.side3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.side3PictureBox.TabIndex = 223
        Me.side3PictureBox.TabStop = False
        '
        'side3Label
        '
        Me.side3Label.AutoSize = True
        Me.side3Label.Location = New System.Drawing.Point(716, 179)
        Me.side3Label.Name = "side3Label"
        Me.side3Label.Size = New System.Drawing.Size(38, 17)
        Me.side3Label.TabIndex = 216
        Me.side3Label.Text = "Corn"
        '
        'side2PictureBox
        '
        Me.side2PictureBox.Image = CType(resources.GetObject("side2PictureBox.Image"), System.Drawing.Image)
        Me.side2PictureBox.Location = New System.Drawing.Point(369, 10)
        Me.side2PictureBox.Name = "side2PictureBox"
        Me.side2PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.side2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.side2PictureBox.TabIndex = 222
        Me.side2PictureBox.TabStop = False
        '
        'sidePrice3Label
        '
        Me.sidePrice3Label.AutoSize = True
        Me.sidePrice3Label.Location = New System.Drawing.Point(716, 196)
        Me.sidePrice3Label.Name = "sidePrice3Label"
        Me.sidePrice3Label.Size = New System.Drawing.Size(93, 17)
        Me.sidePrice3Label.TabIndex = 217
        Me.sidePrice3Label.Text = "From RM4.25"
        '
        'side1PictureBox
        '
        Me.side1PictureBox.Image = CType(resources.GetObject("side1PictureBox.Image"), System.Drawing.Image)
        Me.side1PictureBox.Location = New System.Drawing.Point(16, 10)
        Me.side1PictureBox.Name = "side1PictureBox"
        Me.side1PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.side1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.side1PictureBox.TabIndex = 221
        Me.side1PictureBox.TabStop = False
        '
        'side1Label
        '
        Me.side1Label.AutoSize = True
        Me.side1Label.Location = New System.Drawing.Point(17, 179)
        Me.side1Label.Name = "side1Label"
        Me.side1Label.Size = New System.Drawing.Size(99, 17)
        Me.side1Label.TabIndex = 218
        Me.side1Label.Text = "Criss Cut Fries"
        '
        'sidePrice4Label
        '
        Me.sidePrice4Label.AutoSize = True
        Me.sidePrice4Label.Location = New System.Drawing.Point(1053, 196)
        Me.sidePrice4Label.Name = "sidePrice4Label"
        Me.sidePrice4Label.Size = New System.Drawing.Size(93, 17)
        Me.sidePrice4Label.TabIndex = 220
        Me.sidePrice4Label.Text = "From RM6.60"
        '
        'side4Label
        '
        Me.side4Label.AutoSize = True
        Me.side4Label.Location = New System.Drawing.Point(1053, 179)
        Me.side4Label.Name = "side4Label"
        Me.side4Label.Size = New System.Drawing.Size(127, 17)
        Me.side4Label.TabIndex = 219
        Me.side4Label.Text = "Bubur Ayam McD™"
        '
        'Side
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.sidePanel)
        Me.Controls.Add(Me.sideLabel)
        Me.Name = "Side"
        Me.Size = New System.Drawing.Size(1676, 1038)
        Me.sidePanel.ResumeLayout(False)
        Me.sidePanel.PerformLayout()
        CType(Me.side4PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.side3PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.side2PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.side1PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents sideLabel As Label
    Friend WithEvents sidePanel As Panel
    Friend WithEvents side4PictureBox As PictureBox
    Friend WithEvents sidePrice1Label As Label
    Friend WithEvents side2Label As Label
    Friend WithEvents sidePrice2Label As Label
    Friend WithEvents side3PictureBox As PictureBox
    Friend WithEvents side3Label As Label
    Friend WithEvents side2PictureBox As PictureBox
    Friend WithEvents sidePrice3Label As Label
    Friend WithEvents side1PictureBox As PictureBox
    Friend WithEvents side1Label As Label
    Friend WithEvents sidePrice4Label As Label
    Friend WithEvents side4Label As Label
End Class
