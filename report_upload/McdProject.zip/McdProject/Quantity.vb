﻿Public Class Quantity
    Dim quantity As Integer = 1
    Public set_choosen As Integer = -1
    Public one_set_price As Double
    Public total_price As Double
    Private Sub yesButton_Click(sender As Object, e As EventArgs) Handles yesButton.Click
        Dim this_set_total_price As Double = one_set_price * quantity
        Dim total_set As Integer
        menus.TotalPriceLabel.Visible = True
        menus.taxLabel.Visible = True
        menus.TotalItemLabel.Visible = True
        menus.Label12.Visible = True
        menus.Label15.Visible = True
        menus.Label13.Visible = True
        menus.Label17.Visible = True
        menus.Label18.Visible = True
        menus.viewOrderLabel.Visible = True
        menus.set_detail(set_choosen, 2) = menus.set_detail(set_choosen, 2) + quantity
        For i As Integer = 0 To 90
            If menus.set_detail(i, 2) <> 0 Then
                total_price += (menus.set_detail(i, 1) * menus.set_detail(i, 2))
                total_set += menus.set_detail(i, 2)
            End If
        Next
        menus.TotalItemLabel.Text = total_set.ToString
        menus.TotalPriceLabel.Text = total_price.ToString
        Dim tax As Double = total_price * 0.06
        menus.taxLabel.Text = tax.ToString("f2")
        menus.orderCartLabel.Visible = False
        menus.Show()
        set_choosen = -1
        Me.Close()
        If total_set = 0 Then
        Else
            menus.nextButton.Enabled = True
            menus.nextButton.BackColor = Color.FromArgb(4, 161, 43)
            menus.nextButton.ForeColor = Color.White
            menus.cancelsButton.BackColor = Color.FromArgb(255, 42, 27)
            menus.cancelsButton.ForeColor = Color.White
        End If
    End Sub

    Private Sub noButton_Click(sender As Object, e As EventArgs) Handles noButton.Click
        menus.Show()
        Me.Close()
    End Sub

    Private Sub plusButton_Click(sender As Object, e As EventArgs) Handles plusButton.Click
        quantity += 1
        numLabel.Text = quantity
        Label2.Text = quantity * one_set_price
    End Sub

    Private Sub minusButton_Click(sender As Object, e As EventArgs) Handles minusButton.Click
        If quantity <> 1 Then
            quantity -= 1
        End If
        numLabel.Text = quantity
        Label2.Text = quantity * one_set_price
    End Sub

    Private Sub yesButton_MouseHover(sender As Object, e As EventArgs) Handles yesButton.MouseHover
        yesButton.BackColor = Color.Red
    End Sub

    Private Sub yesButton_MouseLeave(sender As Object, e As EventArgs) Handles yesButton.MouseLeave
        yesButton.BackColor = Color.FromArgb(247, 94, 100)
    End Sub

    Private Sub plusButton_MouseHover(sender As Object, e As EventArgs) Handles plusButton.MouseHover
        plusButton.BackColor = Color.Red
    End Sub

    Private Sub plusButton_MouseLeave(sender As Object, e As EventArgs) Handles plusButton.MouseLeave
        plusButton.BackColor = Color.FromArgb(247, 94, 100)
    End Sub

    Private Sub minusButton_MouseHover(sender As Object, e As EventArgs) Handles minusButton.MouseHover
        minusButton.BackColor = Color.Green
    End Sub

    Private Sub minusButton_MouseLeave(sender As Object, e As EventArgs) Handles minusButton.MouseLeave
        minusButton.BackColor = Color.FromArgb(80, 97, 77)
    End Sub

    Private Sub noButton_MouseHover(sender As Object, e As EventArgs) Handles noButton.MouseHover
        noButton.BackColor = Color.Green
    End Sub

    Private Sub noButton_MouseLeave(sender As Object, e As EventArgs) Handles noButton.MouseLeave
        noButton.BackColor = Color.FromArgb(80, 97, 77)
    End Sub
End Class