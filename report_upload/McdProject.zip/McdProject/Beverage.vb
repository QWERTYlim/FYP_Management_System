﻿Public Class Beverage
    Private Sub Beverage_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub exitButton_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) 
        Application.Exit()
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles beveragePanel.Paint

    End Sub
    Public Sub quantitys(ByVal setnum As Integer)
        Dim picture() = {beverage1PictureBox, beverage2PictureBox, beverage3PictureBox, beverage4PictureBox, beverage5PictureBox, beverage6PictureBox, beverage7PictureBox, beverage8PictureBox, beverage9PictureBox, beverage10PictureBox, beverage11PictureBox}
        Dim price() = {4.53, 4.53, 4.53, 5.94, 6.13, 4.53, 7.08, 4.53, 4.72, 4.72, 4.72}
        Dim setname() = {beverage1Label.Text, beverage2Label.Text, beverage3Label.Text, beverage4Label.Text, beverage5Label.Text, beverage6Label.Text, beverage7Label.Text, beverage8Label.Text, beverage9Label.Text, beverage10Label.Text, beverage11Label.Text}
        Quantity.SetPictureBox.Image = picture(setnum).Image
        Quantity.Label2.Text = price(setnum)
        Quantity.Label1.Text = setname(setnum)
        Quantity.one_set_price = price(setnum)
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles beverage1PictureBox.Click
        quantitys(0)
        Quantity.Show()
        Quantity.set_choosen = 62
    End Sub

    Private Sub PictureBox2_Click_1(sender As Object, e As EventArgs) Handles beverage2PictureBox.Click
        quantitys(1)
        Quantity.Show()
        Quantity.set_choosen = 63
    End Sub

    Private Sub PictureBox3_Click_1(sender As Object, e As EventArgs) Handles beverage3PictureBox.Click
        quantitys(2)
        Quantity.Show()
        Quantity.set_choosen = 64
    End Sub

    Private Sub PictureBox4_Click_1(sender As Object, e As EventArgs) Handles beverage4PictureBox.Click
        quantitys(3)
        Quantity.Show()
        Quantity.set_choosen = 65
    End Sub

    Private Sub PictureBox5_Click_1(sender As Object, e As EventArgs) Handles beverage5PictureBox.Click
        quantitys(4)
        Quantity.Show()
        Quantity.set_choosen = 66
    End Sub

    Private Sub PictureBox6_Click_1(sender As Object, e As EventArgs) Handles beverage6PictureBox.Click
        quantitys(5)
        Quantity.Show()
        Quantity.set_choosen = 67
    End Sub

    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles beverage7PictureBox.Click
        quantitys(6)
        Quantity.Show()
        Quantity.set_choosen = 68
    End Sub

    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles beverage8PictureBox.Click
        quantitys(7)
        Quantity.Show()
        Quantity.set_choosen = 69
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles beverage9PictureBox.Click
        quantitys(8)
        Quantity.Show()
        Quantity.set_choosen = 70
    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles beverage10PictureBox.Click
        quantitys(9)
        Quantity.Show()
        Quantity.set_choosen = 71
    End Sub

    Private Sub PictureBox11_Click(sender As Object, e As EventArgs) Handles beverage11PictureBox.Click
        quantitys(10)
        Quantity.Show()
        Quantity.set_choosen = 72
    End Sub
End Class
