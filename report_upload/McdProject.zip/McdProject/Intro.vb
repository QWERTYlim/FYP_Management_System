﻿Public Class Intro

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles clickLabel.Click
        Eatin_takeaway.Show()
        Me.Close()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles promotion3PictureBox.Click
        Eatin_takeaway.Show()
        menus.Close()
        Me.Close()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles promotion2PictureBox.Click
        Eatin_takeaway.Show()
        menus.Close()
        Me.Close()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles promotion1PictureBox.Click
        Eatin_takeaway.Show()
        menus.Close()
        Me.Close()
    End Sub

End Class
