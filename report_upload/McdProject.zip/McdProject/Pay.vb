﻿Public Class Pay
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        back.Start()
    End Sub

    Private Sub back_Tick(sender As Object, e As EventArgs) Handles back.Tick
        Intro.Show()
        back.Stop()
        Me.Close()
    End Sub
End Class