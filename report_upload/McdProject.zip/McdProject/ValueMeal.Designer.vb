﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ValueMeal
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ValueMeal))
        Me.valueMealAndAlacarteLabel = New System.Windows.Forms.Label()
        Me.valueMealAndAlacartePanel = New System.Windows.Forms.Panel()
        Me.valueMealAndAlacartePrice10Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacartePrice15Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacartePrice11Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte15Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte10Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte15PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacartePrice9Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte9Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte10PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacarte9PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacarte14PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacartePrice14Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacartePrice8Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte11PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacarte8Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte12PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacartePrice7Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte14Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte7Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte13PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacartePrice6Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte11Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte6Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte12Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte8PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacartePrice13Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte7PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacartePrice12Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte6PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacarte13Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacartePrice5Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte5Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacartePrice4Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte4Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte5PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacarte4PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacartePrice1Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte1Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacartePrice3Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte3Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacartePrice2Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte2Label = New System.Windows.Forms.Label()
        Me.valueMealAndAlacarte3PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacarte2PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacarte1PictureBox = New System.Windows.Forms.PictureBox()
        Me.valueMealAndAlacartePanel.SuspendLayout()
        CType(Me.valueMealAndAlacarte15PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte10PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte9PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte14PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte11PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte12PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte13PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte8PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte7PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte6PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte5PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte4PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte3PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte2PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.valueMealAndAlacarte1PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'valueMealAndAlacarteLabel
        '
        Me.valueMealAndAlacarteLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.valueMealAndAlacarteLabel.Font = New System.Drawing.Font("Segoe UI", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.valueMealAndAlacarteLabel.Location = New System.Drawing.Point(3, 10)
        Me.valueMealAndAlacarteLabel.Name = "valueMealAndAlacarteLabel"
        Me.valueMealAndAlacarteLabel.Size = New System.Drawing.Size(1670, 99)
        Me.valueMealAndAlacarteLabel.TabIndex = 49
        Me.valueMealAndAlacarteLabel.Text = " Value Meal && Ala-Carte"
        '
        'valueMealAndAlacartePanel
        '
        Me.valueMealAndAlacartePanel.AutoScroll = True
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice10Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice15Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice11Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte15Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte10Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte15PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice9Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte9Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte10PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte9PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte14PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice14Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice8Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte11PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte8Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte12PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice7Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte14Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte7Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte13PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice6Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte11Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte6Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte12Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte8PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice13Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte7PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice12Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte6PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte13Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice5Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte5Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice4Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte4Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte5PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte4PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice1Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte1Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice3Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte3Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacartePrice2Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte2Label)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte3PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte2PictureBox)
        Me.valueMealAndAlacartePanel.Controls.Add(Me.valueMealAndAlacarte1PictureBox)
        Me.valueMealAndAlacartePanel.Location = New System.Drawing.Point(12, 112)
        Me.valueMealAndAlacartePanel.Name = "valueMealAndAlacartePanel"
        Me.valueMealAndAlacartePanel.Size = New System.Drawing.Size(1650, 625)
        Me.valueMealAndAlacartePanel.TabIndex = 96
        '
        'valueMealAndAlacartePrice10Label
        '
        Me.valueMealAndAlacartePrice10Label.AutoSize = True
        Me.valueMealAndAlacartePrice10Label.Location = New System.Drawing.Point(1361, 436)
        Me.valueMealAndAlacartePrice10Label.Name = "valueMealAndAlacartePrice10Label"
        Me.valueMealAndAlacartePrice10Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice10Label.TabIndex = 105
        Me.valueMealAndAlacartePrice10Label.Text = "From RM11.31"
        '
        'valueMealAndAlacartePrice15Label
        '
        Me.valueMealAndAlacartePrice15Label.AutoSize = True
        Me.valueMealAndAlacartePrice15Label.Location = New System.Drawing.Point(1361, 683)
        Me.valueMealAndAlacartePrice15Label.Name = "valueMealAndAlacartePrice15Label"
        Me.valueMealAndAlacartePrice15Label.Size = New System.Drawing.Size(93, 17)
        Me.valueMealAndAlacartePrice15Label.TabIndex = 93
        Me.valueMealAndAlacartePrice15Label.Text = "From RM8.49"
        '
        'valueMealAndAlacartePrice11Label
        '
        Me.valueMealAndAlacartePrice11Label.AutoSize = True
        Me.valueMealAndAlacartePrice11Label.Location = New System.Drawing.Point(20, 683)
        Me.valueMealAndAlacartePrice11Label.Name = "valueMealAndAlacartePrice11Label"
        Me.valueMealAndAlacartePrice11Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice11Label.TabIndex = 94
        Me.valueMealAndAlacartePrice11Label.Text = "From RM17.45"
        '
        'valueMealAndAlacarte15Label
        '
        Me.valueMealAndAlacarte15Label.AutoSize = True
        Me.valueMealAndAlacarte15Label.Location = New System.Drawing.Point(1361, 666)
        Me.valueMealAndAlacarte15Label.Name = "valueMealAndAlacarte15Label"
        Me.valueMealAndAlacarte15Label.Size = New System.Drawing.Size(86, 17)
        Me.valueMealAndAlacarte15Label.TabIndex = 92
        Me.valueMealAndAlacarte15Label.Text = "McChicken®"
        '
        'valueMealAndAlacarte10Label
        '
        Me.valueMealAndAlacarte10Label.AutoSize = True
        Me.valueMealAndAlacarte10Label.Location = New System.Drawing.Point(1361, 419)
        Me.valueMealAndAlacarte10Label.Name = "valueMealAndAlacarte10Label"
        Me.valueMealAndAlacarte10Label.Size = New System.Drawing.Size(68, 17)
        Me.valueMealAndAlacarte10Label.TabIndex = 104
        Me.valueMealAndAlacarte10Label.Text = "Big Mac™"
        '
        'valueMealAndAlacarte15PictureBox
        '
        Me.valueMealAndAlacarte15PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte15PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte15PictureBox.Location = New System.Drawing.Point(1360, 497)
        Me.valueMealAndAlacarte15PictureBox.Name = "valueMealAndAlacarte15PictureBox"
        Me.valueMealAndAlacarte15PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte15PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte15PictureBox.TabIndex = 91
        Me.valueMealAndAlacarte15PictureBox.TabStop = False
        '
        'valueMealAndAlacartePrice9Label
        '
        Me.valueMealAndAlacartePrice9Label.AutoSize = True
        Me.valueMealAndAlacartePrice9Label.Location = New System.Drawing.Point(1048, 436)
        Me.valueMealAndAlacartePrice9Label.Name = "valueMealAndAlacartePrice9Label"
        Me.valueMealAndAlacartePrice9Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice9Label.TabIndex = 103
        Me.valueMealAndAlacartePrice9Label.Text = "From RM16.03"
        '
        'valueMealAndAlacarte9Label
        '
        Me.valueMealAndAlacarte9Label.AutoSize = True
        Me.valueMealAndAlacarte9Label.Location = New System.Drawing.Point(1048, 419)
        Me.valueMealAndAlacarte9Label.Name = "valueMealAndAlacarte9Label"
        Me.valueMealAndAlacarte9Label.Size = New System.Drawing.Size(138, 17)
        Me.valueMealAndAlacarte9Label.TabIndex = 102
        Me.valueMealAndAlacarte9Label.Text = "Triple Cheeseburger"
        '
        'valueMealAndAlacarte10PictureBox
        '
        Me.valueMealAndAlacarte10PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte10PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte10PictureBox.Location = New System.Drawing.Point(1360, 250)
        Me.valueMealAndAlacarte10PictureBox.Name = "valueMealAndAlacarte10PictureBox"
        Me.valueMealAndAlacarte10PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte10PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte10PictureBox.TabIndex = 101
        Me.valueMealAndAlacarte10PictureBox.TabStop = False
        '
        'valueMealAndAlacarte9PictureBox
        '
        Me.valueMealAndAlacarte9PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte9PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte9PictureBox.Location = New System.Drawing.Point(1056, 250)
        Me.valueMealAndAlacarte9PictureBox.Name = "valueMealAndAlacarte9PictureBox"
        Me.valueMealAndAlacarte9PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte9PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte9PictureBox.TabIndex = 100
        Me.valueMealAndAlacarte9PictureBox.TabStop = False
        '
        'valueMealAndAlacarte14PictureBox
        '
        Me.valueMealAndAlacarte14PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte14PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte14PictureBox.Location = New System.Drawing.Point(1056, 497)
        Me.valueMealAndAlacarte14PictureBox.Name = "valueMealAndAlacarte14PictureBox"
        Me.valueMealAndAlacarte14PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte14PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte14PictureBox.TabIndex = 88
        Me.valueMealAndAlacarte14PictureBox.TabStop = False
        '
        'valueMealAndAlacartePrice14Label
        '
        Me.valueMealAndAlacartePrice14Label.AutoSize = True
        Me.valueMealAndAlacartePrice14Label.Location = New System.Drawing.Point(1053, 683)
        Me.valueMealAndAlacartePrice14Label.Name = "valueMealAndAlacartePrice14Label"
        Me.valueMealAndAlacartePrice14Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice14Label.TabIndex = 90
        Me.valueMealAndAlacartePrice14Label.Text = "From RM15.57"
        '
        'valueMealAndAlacartePrice8Label
        '
        Me.valueMealAndAlacartePrice8Label.AutoSize = True
        Me.valueMealAndAlacartePrice8Label.Location = New System.Drawing.Point(713, 436)
        Me.valueMealAndAlacartePrice8Label.Name = "valueMealAndAlacartePrice8Label"
        Me.valueMealAndAlacartePrice8Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice8Label.TabIndex = 99
        Me.valueMealAndAlacartePrice8Label.Text = "From RM10.37"
        '
        'valueMealAndAlacarte11PictureBox
        '
        Me.valueMealAndAlacarte11PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte11PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte11PictureBox.Location = New System.Drawing.Point(16, 497)
        Me.valueMealAndAlacarte11PictureBox.Name = "valueMealAndAlacarte11PictureBox"
        Me.valueMealAndAlacarte11PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte11PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte11PictureBox.TabIndex = 80
        Me.valueMealAndAlacarte11PictureBox.TabStop = False
        '
        'valueMealAndAlacarte8Label
        '
        Me.valueMealAndAlacarte8Label.AutoSize = True
        Me.valueMealAndAlacarte8Label.Location = New System.Drawing.Point(713, 419)
        Me.valueMealAndAlacarte8Label.Name = "valueMealAndAlacarte8Label"
        Me.valueMealAndAlacarte8Label.Size = New System.Drawing.Size(147, 17)
        Me.valueMealAndAlacarte8Label.TabIndex = 98
        Me.valueMealAndAlacarte8Label.Text = "Double Cheeseburger"
        '
        'valueMealAndAlacarte12PictureBox
        '
        Me.valueMealAndAlacarte12PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte12PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte12PictureBox.Location = New System.Drawing.Point(369, 497)
        Me.valueMealAndAlacarte12PictureBox.Name = "valueMealAndAlacarte12PictureBox"
        Me.valueMealAndAlacarte12PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte12PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte12PictureBox.TabIndex = 81
        Me.valueMealAndAlacarte12PictureBox.TabStop = False
        '
        'valueMealAndAlacartePrice7Label
        '
        Me.valueMealAndAlacartePrice7Label.AutoSize = True
        Me.valueMealAndAlacartePrice7Label.Location = New System.Drawing.Point(367, 436)
        Me.valueMealAndAlacartePrice7Label.Name = "valueMealAndAlacartePrice7Label"
        Me.valueMealAndAlacartePrice7Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice7Label.TabIndex = 97
        Me.valueMealAndAlacartePrice7Label.Text = "From RM18.40"
        '
        'valueMealAndAlacarte14Label
        '
        Me.valueMealAndAlacarte14Label.AutoSize = True
        Me.valueMealAndAlacarte14Label.Location = New System.Drawing.Point(1053, 666)
        Me.valueMealAndAlacarte14Label.Name = "valueMealAndAlacarte14Label"
        Me.valueMealAndAlacarte14Label.Size = New System.Drawing.Size(128, 17)
        Me.valueMealAndAlacarte14Label.TabIndex = 89
        Me.valueMealAndAlacarte14Label.Text = "Smoky Grilled Beef"
        '
        'valueMealAndAlacarte7Label
        '
        Me.valueMealAndAlacarte7Label.AutoSize = True
        Me.valueMealAndAlacarte7Label.Location = New System.Drawing.Point(367, 419)
        Me.valueMealAndAlacarte7Label.Name = "valueMealAndAlacarte7Label"
        Me.valueMealAndAlacarte7Label.Size = New System.Drawing.Size(242, 17)
        Me.valueMealAndAlacarte7Label.TabIndex = 96
        Me.valueMealAndAlacarte7Label.Text = "Double Spicy Korean Chicken Burger"
        '
        'valueMealAndAlacarte13PictureBox
        '
        Me.valueMealAndAlacarte13PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte13PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte13PictureBox.Location = New System.Drawing.Point(719, 497)
        Me.valueMealAndAlacarte13PictureBox.Name = "valueMealAndAlacarte13PictureBox"
        Me.valueMealAndAlacarte13PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte13PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte13PictureBox.TabIndex = 82
        Me.valueMealAndAlacarte13PictureBox.TabStop = False
        '
        'valueMealAndAlacartePrice6Label
        '
        Me.valueMealAndAlacartePrice6Label.AutoSize = True
        Me.valueMealAndAlacartePrice6Label.Location = New System.Drawing.Point(21, 436)
        Me.valueMealAndAlacartePrice6Label.Name = "valueMealAndAlacartePrice6Label"
        Me.valueMealAndAlacartePrice6Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice6Label.TabIndex = 95
        Me.valueMealAndAlacartePrice6Label.Text = "From RM14.62"
        '
        'valueMealAndAlacarte11Label
        '
        Me.valueMealAndAlacarte11Label.AutoSize = True
        Me.valueMealAndAlacarte11Label.Location = New System.Drawing.Point(20, 666)
        Me.valueMealAndAlacarte11Label.Name = "valueMealAndAlacarte11Label"
        Me.valueMealAndAlacarte11Label.Size = New System.Drawing.Size(83, 17)
        Me.valueMealAndAlacarte11Label.TabIndex = 83
        Me.valueMealAndAlacarte11Label.Text = "Mega Mac™"
        '
        'valueMealAndAlacarte6Label
        '
        Me.valueMealAndAlacarte6Label.AutoSize = True
        Me.valueMealAndAlacarte6Label.Location = New System.Drawing.Point(21, 419)
        Me.valueMealAndAlacarte6Label.Name = "valueMealAndAlacarte6Label"
        Me.valueMealAndAlacarte6Label.Size = New System.Drawing.Size(172, 17)
        Me.valueMealAndAlacarte6Label.TabIndex = 94
        Me.valueMealAndAlacarte6Label.Text = "Spicy Korean Beef Burger"
        '
        'valueMealAndAlacarte12Label
        '
        Me.valueMealAndAlacarte12Label.AutoSize = True
        Me.valueMealAndAlacarte12Label.Location = New System.Drawing.Point(366, 666)
        Me.valueMealAndAlacarte12Label.Name = "valueMealAndAlacarte12Label"
        Me.valueMealAndAlacarte12Label.Size = New System.Drawing.Size(205, 17)
        Me.valueMealAndAlacarte12Label.TabIndex = 84
        Me.valueMealAndAlacarte12Label.Text = "Quarter Pounder™ with Cheese"
        '
        'valueMealAndAlacarte8PictureBox
        '
        Me.valueMealAndAlacarte8PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte8PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte8PictureBox.Location = New System.Drawing.Point(719, 250)
        Me.valueMealAndAlacarte8PictureBox.Name = "valueMealAndAlacarte8PictureBox"
        Me.valueMealAndAlacarte8PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte8PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte8PictureBox.TabIndex = 93
        Me.valueMealAndAlacarte8PictureBox.TabStop = False
        '
        'valueMealAndAlacartePrice13Label
        '
        Me.valueMealAndAlacartePrice13Label.AutoSize = True
        Me.valueMealAndAlacartePrice13Label.Location = New System.Drawing.Point(716, 683)
        Me.valueMealAndAlacartePrice13Label.Name = "valueMealAndAlacartePrice13Label"
        Me.valueMealAndAlacartePrice13Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice13Label.TabIndex = 87
        Me.valueMealAndAlacartePrice13Label.Text = "From RM18.40"
        '
        'valueMealAndAlacarte7PictureBox
        '
        Me.valueMealAndAlacarte7PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte7PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte7PictureBox.Location = New System.Drawing.Point(369, 250)
        Me.valueMealAndAlacarte7PictureBox.Name = "valueMealAndAlacarte7PictureBox"
        Me.valueMealAndAlacarte7PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte7PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte7PictureBox.TabIndex = 92
        Me.valueMealAndAlacarte7PictureBox.TabStop = False
        '
        'valueMealAndAlacartePrice12Label
        '
        Me.valueMealAndAlacartePrice12Label.AutoSize = True
        Me.valueMealAndAlacartePrice12Label.Location = New System.Drawing.Point(366, 683)
        Me.valueMealAndAlacartePrice12Label.Name = "valueMealAndAlacartePrice12Label"
        Me.valueMealAndAlacartePrice12Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice12Label.TabIndex = 85
        Me.valueMealAndAlacartePrice12Label.Text = "From RM12.25"
        '
        'valueMealAndAlacarte6PictureBox
        '
        Me.valueMealAndAlacarte6PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte6PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte6PictureBox.Location = New System.Drawing.Point(16, 250)
        Me.valueMealAndAlacarte6PictureBox.Name = "valueMealAndAlacarte6PictureBox"
        Me.valueMealAndAlacarte6PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte6PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte6PictureBox.TabIndex = 91
        Me.valueMealAndAlacarte6PictureBox.TabStop = False
        '
        'valueMealAndAlacarte13Label
        '
        Me.valueMealAndAlacarte13Label.AutoSize = True
        Me.valueMealAndAlacarte13Label.Location = New System.Drawing.Point(716, 666)
        Me.valueMealAndAlacarte13Label.Name = "valueMealAndAlacarte13Label"
        Me.valueMealAndAlacarte13Label.Size = New System.Drawing.Size(254, 17)
        Me.valueMealAndAlacarte13Label.TabIndex = 86
        Me.valueMealAndAlacarte13Label.Text = "Double Quarter Pounder™ with Cheese"
        '
        'valueMealAndAlacartePrice5Label
        '
        Me.valueMealAndAlacartePrice5Label.AutoSize = True
        Me.valueMealAndAlacartePrice5Label.Location = New System.Drawing.Point(1361, 196)
        Me.valueMealAndAlacartePrice5Label.Name = "valueMealAndAlacartePrice5Label"
        Me.valueMealAndAlacartePrice5Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice5Label.TabIndex = 90
        Me.valueMealAndAlacartePrice5Label.Text = "From RM16.51"
        '
        'valueMealAndAlacarte5Label
        '
        Me.valueMealAndAlacarte5Label.AutoSize = True
        Me.valueMealAndAlacarte5Label.Location = New System.Drawing.Point(1361, 179)
        Me.valueMealAndAlacarte5Label.Name = "valueMealAndAlacarte5Label"
        Me.valueMealAndAlacarte5Label.Size = New System.Drawing.Size(207, 17)
        Me.valueMealAndAlacarte5Label.TabIndex = 89
        Me.valueMealAndAlacarte5Label.Text = "Filet-O-Fish™ Super Value Meal"
        '
        'valueMealAndAlacartePrice4Label
        '
        Me.valueMealAndAlacartePrice4Label.AutoSize = True
        Me.valueMealAndAlacartePrice4Label.Location = New System.Drawing.Point(1048, 196)
        Me.valueMealAndAlacartePrice4Label.Name = "valueMealAndAlacartePrice4Label"
        Me.valueMealAndAlacartePrice4Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice4Label.TabIndex = 88
        Me.valueMealAndAlacartePrice4Label.Text = "From RM14.62"
        '
        'valueMealAndAlacarte4Label
        '
        Me.valueMealAndAlacarte4Label.AutoSize = True
        Me.valueMealAndAlacarte4Label.Location = New System.Drawing.Point(1048, 179)
        Me.valueMealAndAlacarte4Label.Name = "valueMealAndAlacarte4Label"
        Me.valueMealAndAlacarte4Label.Size = New System.Drawing.Size(193, 17)
        Me.valueMealAndAlacarte4Label.TabIndex = 87
        Me.valueMealAndAlacarte4Label.Text = "Spicy Korean Chicken Burger"
        '
        'valueMealAndAlacarte5PictureBox
        '
        Me.valueMealAndAlacarte5PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte5PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte5PictureBox.Location = New System.Drawing.Point(1360, 10)
        Me.valueMealAndAlacarte5PictureBox.Name = "valueMealAndAlacarte5PictureBox"
        Me.valueMealAndAlacarte5PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte5PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte5PictureBox.TabIndex = 86
        Me.valueMealAndAlacarte5PictureBox.TabStop = False
        '
        'valueMealAndAlacarte4PictureBox
        '
        Me.valueMealAndAlacarte4PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte4PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte4PictureBox.Location = New System.Drawing.Point(1056, 10)
        Me.valueMealAndAlacarte4PictureBox.Name = "valueMealAndAlacarte4PictureBox"
        Me.valueMealAndAlacarte4PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte4PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte4PictureBox.TabIndex = 85
        Me.valueMealAndAlacarte4PictureBox.TabStop = False
        '
        'valueMealAndAlacartePrice1Label
        '
        Me.valueMealAndAlacartePrice1Label.AutoSize = True
        Me.valueMealAndAlacartePrice1Label.Location = New System.Drawing.Point(20, 196)
        Me.valueMealAndAlacartePrice1Label.Name = "valueMealAndAlacartePrice1Label"
        Me.valueMealAndAlacartePrice1Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice1Label.TabIndex = 84
        Me.valueMealAndAlacartePrice1Label.Text = "From RM17.92"
        '
        'valueMealAndAlacarte1Label
        '
        Me.valueMealAndAlacarte1Label.AutoSize = True
        Me.valueMealAndAlacarte1Label.Location = New System.Drawing.Point(17, 179)
        Me.valueMealAndAlacarte1Label.Name = "valueMealAndAlacarte1Label"
        Me.valueMealAndAlacarte1Label.Size = New System.Drawing.Size(237, 17)
        Me.valueMealAndAlacarte1Label.TabIndex = 83
        Me.valueMealAndAlacarte1Label.Text = "Nasi Lemak McD™ + Rendang Ayam"
        '
        'valueMealAndAlacartePrice3Label
        '
        Me.valueMealAndAlacartePrice3Label.AutoSize = True
        Me.valueMealAndAlacartePrice3Label.Location = New System.Drawing.Point(713, 196)
        Me.valueMealAndAlacartePrice3Label.Name = "valueMealAndAlacartePrice3Label"
        Me.valueMealAndAlacartePrice3Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice3Label.TabIndex = 82
        Me.valueMealAndAlacartePrice3Label.Text = "From RM16.03"
        '
        'valueMealAndAlacarte3Label
        '
        Me.valueMealAndAlacarte3Label.AutoSize = True
        Me.valueMealAndAlacarte3Label.Location = New System.Drawing.Point(713, 179)
        Me.valueMealAndAlacarte3Label.Name = "valueMealAndAlacarte3Label"
        Me.valueMealAndAlacarte3Label.Size = New System.Drawing.Size(209, 17)
        Me.valueMealAndAlacarte3Label.TabIndex = 81
        Me.valueMealAndAlacarte3Label.Text = "Nasi Lemak McD™ + GCB Cutlet"
        '
        'valueMealAndAlacartePrice2Label
        '
        Me.valueMealAndAlacartePrice2Label.AutoSize = True
        Me.valueMealAndAlacartePrice2Label.Location = New System.Drawing.Point(367, 196)
        Me.valueMealAndAlacartePrice2Label.Name = "valueMealAndAlacartePrice2Label"
        Me.valueMealAndAlacartePrice2Label.Size = New System.Drawing.Size(101, 17)
        Me.valueMealAndAlacartePrice2Label.TabIndex = 80
        Me.valueMealAndAlacartePrice2Label.Text = "From RM16.03"
        '
        'valueMealAndAlacarte2Label
        '
        Me.valueMealAndAlacarte2Label.AutoSize = True
        Me.valueMealAndAlacarte2Label.Location = New System.Drawing.Point(367, 179)
        Me.valueMealAndAlacarte2Label.Name = "valueMealAndAlacarte2Label"
        Me.valueMealAndAlacarte2Label.Size = New System.Drawing.Size(209, 17)
        Me.valueMealAndAlacarte2Label.TabIndex = 79
        Me.valueMealAndAlacarte2Label.Text = "Nasi Lemak McD™ + SCM Cutlet"
        '
        'valueMealAndAlacarte3PictureBox
        '
        Me.valueMealAndAlacarte3PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte3PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte3PictureBox.Location = New System.Drawing.Point(719, 10)
        Me.valueMealAndAlacarte3PictureBox.Name = "valueMealAndAlacarte3PictureBox"
        Me.valueMealAndAlacarte3PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte3PictureBox.TabIndex = 78
        Me.valueMealAndAlacarte3PictureBox.TabStop = False
        '
        'valueMealAndAlacarte2PictureBox
        '
        Me.valueMealAndAlacarte2PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte2PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte2PictureBox.Location = New System.Drawing.Point(369, 10)
        Me.valueMealAndAlacarte2PictureBox.Name = "valueMealAndAlacarte2PictureBox"
        Me.valueMealAndAlacarte2PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte2PictureBox.TabIndex = 77
        Me.valueMealAndAlacarte2PictureBox.TabStop = False
        '
        'valueMealAndAlacarte1PictureBox
        '
        Me.valueMealAndAlacarte1PictureBox.Image = CType(resources.GetObject("valueMealAndAlacarte1PictureBox.Image"), System.Drawing.Image)
        Me.valueMealAndAlacarte1PictureBox.Location = New System.Drawing.Point(16, 10)
        Me.valueMealAndAlacarte1PictureBox.Name = "valueMealAndAlacarte1PictureBox"
        Me.valueMealAndAlacarte1PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.valueMealAndAlacarte1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.valueMealAndAlacarte1PictureBox.TabIndex = 76
        Me.valueMealAndAlacarte1PictureBox.TabStop = False
        '
        'ValueMeal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.valueMealAndAlacartePanel)
        Me.Controls.Add(Me.valueMealAndAlacarteLabel)
        Me.Name = "ValueMeal"
        Me.Size = New System.Drawing.Size(1676, 1038)
        Me.valueMealAndAlacartePanel.ResumeLayout(False)
        Me.valueMealAndAlacartePanel.PerformLayout()
        CType(Me.valueMealAndAlacarte15PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte10PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte9PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte14PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte11PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte12PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte13PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte8PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte7PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte6PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte5PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte4PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte3PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte2PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.valueMealAndAlacarte1PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents valueMealAndAlacarteLabel As Label
    Friend WithEvents valueMealAndAlacartePanel As Panel
    Friend WithEvents valueMealAndAlacartePrice10Label As Label
    Friend WithEvents valueMealAndAlacartePrice15Label As Label
    Friend WithEvents valueMealAndAlacartePrice11Label As Label
    Friend WithEvents valueMealAndAlacarte15Label As Label
    Friend WithEvents valueMealAndAlacarte10Label As Label
    Friend WithEvents valueMealAndAlacarte15PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacartePrice9Label As Label
    Friend WithEvents valueMealAndAlacarte9Label As Label
    Friend WithEvents valueMealAndAlacarte10PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacarte9PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacarte14PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacartePrice14Label As Label
    Friend WithEvents valueMealAndAlacartePrice8Label As Label
    Friend WithEvents valueMealAndAlacarte11PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacarte8Label As Label
    Friend WithEvents valueMealAndAlacarte12PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacartePrice7Label As Label
    Friend WithEvents valueMealAndAlacarte14Label As Label
    Friend WithEvents valueMealAndAlacarte7Label As Label
    Friend WithEvents valueMealAndAlacarte13PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacartePrice6Label As Label
    Friend WithEvents valueMealAndAlacarte11Label As Label
    Friend WithEvents valueMealAndAlacarte6Label As Label
    Friend WithEvents valueMealAndAlacarte12Label As Label
    Friend WithEvents valueMealAndAlacarte8PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacartePrice13Label As Label
    Friend WithEvents valueMealAndAlacarte7PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacartePrice12Label As Label
    Friend WithEvents valueMealAndAlacarte6PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacarte13Label As Label
    Friend WithEvents valueMealAndAlacartePrice5Label As Label
    Friend WithEvents valueMealAndAlacarte5Label As Label
    Friend WithEvents valueMealAndAlacartePrice4Label As Label
    Friend WithEvents valueMealAndAlacarte4Label As Label
    Friend WithEvents valueMealAndAlacarte5PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacarte4PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacartePrice1Label As Label
    Friend WithEvents valueMealAndAlacarte1Label As Label
    Friend WithEvents valueMealAndAlacartePrice3Label As Label
    Friend WithEvents valueMealAndAlacarte3Label As Label
    Friend WithEvents valueMealAndAlacartePrice2Label As Label
    Friend WithEvents valueMealAndAlacarte2Label As Label
    Friend WithEvents valueMealAndAlacarte3PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacarte2PictureBox As PictureBox
    Friend WithEvents valueMealAndAlacarte1PictureBox As PictureBox
End Class
