﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Intro
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Intro))
        Me.promotion1PictureBox = New System.Windows.Forms.PictureBox()
        Me.promotion2PictureBox = New System.Windows.Forms.PictureBox()
        Me.promotion3PictureBox = New System.Windows.Forms.PictureBox()
        Me.clickPanel = New System.Windows.Forms.Panel()
        Me.clickLabel = New System.Windows.Forms.Label()
        CType(Me.promotion1PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.promotion2PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.promotion3PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.clickPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'promotion1PictureBox
        '
        Me.promotion1PictureBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.promotion1PictureBox.Image = CType(resources.GetObject("promotion1PictureBox.Image"), System.Drawing.Image)
        Me.promotion1PictureBox.Location = New System.Drawing.Point(0, 0)
        Me.promotion1PictureBox.Name = "promotion1PictureBox"
        Me.promotion1PictureBox.Size = New System.Drawing.Size(1924, 465)
        Me.promotion1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.promotion1PictureBox.TabIndex = 5
        Me.promotion1PictureBox.TabStop = False
        '
        'promotion2PictureBox
        '
        Me.promotion2PictureBox.Dock = System.Windows.Forms.DockStyle.Left
        Me.promotion2PictureBox.Image = CType(resources.GetObject("promotion2PictureBox.Image"), System.Drawing.Image)
        Me.promotion2PictureBox.Location = New System.Drawing.Point(0, 465)
        Me.promotion2PictureBox.Name = "promotion2PictureBox"
        Me.promotion2PictureBox.Size = New System.Drawing.Size(950, 590)
        Me.promotion2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.promotion2PictureBox.TabIndex = 6
        Me.promotion2PictureBox.TabStop = False
        '
        'promotion3PictureBox
        '
        Me.promotion3PictureBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.promotion3PictureBox.Image = CType(resources.GetObject("promotion3PictureBox.Image"), System.Drawing.Image)
        Me.promotion3PictureBox.Location = New System.Drawing.Point(950, 465)
        Me.promotion3PictureBox.Name = "promotion3PictureBox"
        Me.promotion3PictureBox.Size = New System.Drawing.Size(974, 590)
        Me.promotion3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.promotion3PictureBox.TabIndex = 7
        Me.promotion3PictureBox.TabStop = False
        '
        'clickPanel
        '
        Me.clickPanel.BackColor = System.Drawing.Color.SeaGreen
        Me.clickPanel.Controls.Add(Me.clickLabel)
        Me.clickPanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.clickPanel.Location = New System.Drawing.Point(950, 883)
        Me.clickPanel.Name = "clickPanel"
        Me.clickPanel.Size = New System.Drawing.Size(974, 172)
        Me.clickPanel.TabIndex = 8
        '
        'clickLabel
        '
        Me.clickLabel.AutoSize = True
        Me.clickLabel.Font = New System.Drawing.Font("Segoe UI Black", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.clickLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.clickLabel.Location = New System.Drawing.Point(323, 65)
        Me.clickLabel.Name = "clickLabel"
        Me.clickLabel.Size = New System.Drawing.Size(301, 54)
        Me.clickLabel.TabIndex = 0
        Me.clickLabel.Text = "Click To Order"
        '
        'Intro
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1924, 1055)
        Me.Controls.Add(Me.clickPanel)
        Me.Controls.Add(Me.promotion3PictureBox)
        Me.Controls.Add(Me.promotion2PictureBox)
        Me.Controls.Add(Me.promotion1PictureBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Intro"
        Me.Text = "Intro"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.promotion1PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.promotion2PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.promotion3PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.clickPanel.ResumeLayout(False)
        Me.clickPanel.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents promotion1PictureBox As PictureBox
    Friend WithEvents promotion2PictureBox As PictureBox
    Friend WithEvents promotion3PictureBox As PictureBox
    Friend WithEvents clickPanel As Panel
    Friend WithEvents clickLabel As Label
End Class
