﻿Public Class Side
    Private Sub Side_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub exitButton_Click(sender As Object, e As EventArgs) 
        Application.Exit()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles side1PictureBox.Click
        quantitys(0)
        Quantity.Show()
        Quantity.set_choosen = 87
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles sidePanel.Paint

    End Sub
    Public Sub quantitys(ByVal setnum As Integer)
        Dim picture() = {side1PictureBox, side2PictureBox, side3PictureBox, side4PictureBox}
        Dim price() = {6.13, 5.19, 4.25, 6.6}
        Dim setname() = {side1Label.Text, side2Label.Text, side3Label.Text, side4Label.Text}
        Quantity.SetPictureBox.Image = picture(setnum).Image
        Quantity.Label2.Text = price(setnum)
        Quantity.Label1.Text = setname(setnum)
        Quantity.one_set_price = price(setnum)
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles side2PictureBox.Click
        quantitys(1)
        Quantity.Show()
        Quantity.set_choosen = 88
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles side3PictureBox.Click
        quantitys(2)
        Quantity.Show()
        Quantity.set_choosen = 89
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles side4PictureBox.Click
        quantitys(3)
        Quantity.Show()
        Quantity.set_choosen = 90
    End Sub

End Class
