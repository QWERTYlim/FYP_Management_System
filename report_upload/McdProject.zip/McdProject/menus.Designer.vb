﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class menus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.mainMenuPanel = New System.Windows.Forms.Panel()
        Me.mainMenuLabel = New System.Windows.Forms.Label()
        Me.menuPanel = New System.Windows.Forms.Panel()
        Me.sideLabel = New System.Windows.Forms.Label()
        Me.happyMealLabel = New System.Windows.Forms.Label()
        Me.dessertLabel = New System.Windows.Forms.Label()
        Me.beverageLabel = New System.Windows.Forms.Label()
        Me.mcCafeDrinkLabel = New System.Windows.Forms.Label()
        Me.mcCafeCakeLabel = New System.Windows.Forms.Label()
        Me.partyPackageLabel = New System.Windows.Forms.Label()
        Me.valueMealAndAlaCarteLabel = New System.Windows.Forms.Label()
        Me.familyMealLabel = New System.Windows.Forms.Label()
        Me.superValueMealLabel = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Side1 = New McdProject.Side()
        Me.HappyMeal1 = New McdProject.HappyMeal()
        Me.Dessert1 = New McdProject.Dessert()
        Me.Beverage1 = New McdProject.Beverage()
        Me.McCafeCake1 = New McdProject.McCafeCake()
        Me.McCafeDrink1 = New McdProject.McCafeDrink()
        Me.PartyPackage1 = New McdProject.PartyPackage()
        Me.UserControl21 = New McdProject.ValueMeal()
        Me.UserControl11 = New McdProject.SuperValueMeal()
        Me.FamilyMeal1 = New McdProject.FamilyMeal()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.orderLittleDetailPanel = New System.Windows.Forms.Panel()
        Me.viewOrderLabel = New System.Windows.Forms.Label()
        Me.taxTotalItemsPanel = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TotalItemLabel = New System.Windows.Forms.Label()
        Me.TotalPriceLabel = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.taxLabel = New System.Windows.Forms.Label()
        Me.orderCartLabel = New System.Windows.Forms.Label()
        Me.myOrderPanel = New System.Windows.Forms.Panel()
        Me.wordLabel = New System.Windows.Forms.Label()
        Me.ButttonPanel = New System.Windows.Forms.Panel()
        Me.nextButton = New System.Windows.Forms.Button()
        Me.cancelsButton = New System.Windows.Forms.Button()
        Me.mainMenuPanel.SuspendLayout()
        Me.menuPanel.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.FlowLayoutPanel2.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.orderLittleDetailPanel.SuspendLayout()
        Me.taxTotalItemsPanel.SuspendLayout()
        Me.myOrderPanel.SuspendLayout()
        Me.ButttonPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'mainMenuPanel
        '
        Me.mainMenuPanel.BackColor = System.Drawing.Color.Red
        Me.mainMenuPanel.Controls.Add(Me.mainMenuLabel)
        Me.mainMenuPanel.Location = New System.Drawing.Point(3, 2)
        Me.mainMenuPanel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.mainMenuPanel.Name = "mainMenuPanel"
        Me.mainMenuPanel.Size = New System.Drawing.Size(227, 100)
        Me.mainMenuPanel.TabIndex = 0
        '
        'mainMenuLabel
        '
        Me.mainMenuLabel.AutoSize = True
        Me.mainMenuLabel.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mainMenuLabel.Location = New System.Drawing.Point(13, 28)
        Me.mainMenuLabel.Name = "mainMenuLabel"
        Me.mainMenuLabel.Size = New System.Drawing.Size(198, 45)
        Me.mainMenuLabel.TabIndex = 0
        Me.mainMenuLabel.Text = "Main Menu"
        '
        'menuPanel
        '
        Me.menuPanel.BackColor = System.Drawing.Color.Orange
        Me.menuPanel.Controls.Add(Me.sideLabel)
        Me.menuPanel.Controls.Add(Me.happyMealLabel)
        Me.menuPanel.Controls.Add(Me.dessertLabel)
        Me.menuPanel.Controls.Add(Me.beverageLabel)
        Me.menuPanel.Controls.Add(Me.mcCafeDrinkLabel)
        Me.menuPanel.Controls.Add(Me.mcCafeCakeLabel)
        Me.menuPanel.Controls.Add(Me.partyPackageLabel)
        Me.menuPanel.Controls.Add(Me.valueMealAndAlaCarteLabel)
        Me.menuPanel.Controls.Add(Me.familyMealLabel)
        Me.menuPanel.Controls.Add(Me.superValueMealLabel)
        Me.menuPanel.Location = New System.Drawing.Point(3, 106)
        Me.menuPanel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.menuPanel.Name = "menuPanel"
        Me.menuPanel.Size = New System.Drawing.Size(227, 635)
        Me.menuPanel.TabIndex = 1
        '
        'sideLabel
        '
        Me.sideLabel.AutoSize = True
        Me.sideLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.sideLabel.Location = New System.Drawing.Point(19, 524)
        Me.sideLabel.Name = "sideLabel"
        Me.sideLabel.Size = New System.Drawing.Size(45, 23)
        Me.sideLabel.TabIndex = 10
        Me.sideLabel.Text = "Side"
        '
        'happyMealLabel
        '
        Me.happyMealLabel.AutoSize = True
        Me.happyMealLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.happyMealLabel.Location = New System.Drawing.Point(19, 469)
        Me.happyMealLabel.Name = "happyMealLabel"
        Me.happyMealLabel.Size = New System.Drawing.Size(107, 23)
        Me.happyMealLabel.TabIndex = 9
        Me.happyMealLabel.Text = "Happy Meal"
        '
        'dessertLabel
        '
        Me.dessertLabel.AutoSize = True
        Me.dessertLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dessertLabel.Location = New System.Drawing.Point(19, 416)
        Me.dessertLabel.Name = "dessertLabel"
        Me.dessertLabel.Size = New System.Drawing.Size(69, 23)
        Me.dessertLabel.TabIndex = 8
        Me.dessertLabel.Text = "Dessert"
        '
        'beverageLabel
        '
        Me.beverageLabel.AutoSize = True
        Me.beverageLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.beverageLabel.Location = New System.Drawing.Point(19, 359)
        Me.beverageLabel.Name = "beverageLabel"
        Me.beverageLabel.Size = New System.Drawing.Size(84, 23)
        Me.beverageLabel.TabIndex = 7
        Me.beverageLabel.Text = "Beverage"
        '
        'mcCafeDrinkLabel
        '
        Me.mcCafeDrinkLabel.AutoSize = True
        Me.mcCafeDrinkLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mcCafeDrinkLabel.Location = New System.Drawing.Point(19, 247)
        Me.mcCafeDrinkLabel.Name = "mcCafeDrinkLabel"
        Me.mcCafeDrinkLabel.Size = New System.Drawing.Size(115, 23)
        Me.mcCafeDrinkLabel.TabIndex = 6
        Me.mcCafeDrinkLabel.Text = "McCafeDrink"
        '
        'mcCafeCakeLabel
        '
        Me.mcCafeCakeLabel.AutoSize = True
        Me.mcCafeCakeLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mcCafeCakeLabel.Location = New System.Drawing.Point(19, 302)
        Me.mcCafeCakeLabel.Name = "mcCafeCakeLabel"
        Me.mcCafeCakeLabel.Size = New System.Drawing.Size(109, 23)
        Me.mcCafeCakeLabel.TabIndex = 5
        Me.mcCafeCakeLabel.Text = "McCafeCake"
        '
        'partyPackageLabel
        '
        Me.partyPackageLabel.AutoSize = True
        Me.partyPackageLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.partyPackageLabel.Location = New System.Drawing.Point(19, 192)
        Me.partyPackageLabel.Name = "partyPackageLabel"
        Me.partyPackageLabel.Size = New System.Drawing.Size(123, 23)
        Me.partyPackageLabel.TabIndex = 4
        Me.partyPackageLabel.Text = "Party Package"
        '
        'valueMealAndAlaCarteLabel
        '
        Me.valueMealAndAlaCarteLabel.AutoSize = True
        Me.valueMealAndAlaCarteLabel.Font = New System.Drawing.Font("Segoe UI", 9.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.valueMealAndAlaCarteLabel.Location = New System.Drawing.Point(9, 139)
        Me.valueMealAndAlaCarteLabel.Name = "valueMealAndAlaCarteLabel"
        Me.valueMealAndAlaCarteLabel.Size = New System.Drawing.Size(196, 21)
        Me.valueMealAndAlaCarteLabel.TabIndex = 3
        Me.valueMealAndAlaCarteLabel.Text = "  Value Meal && Ala-Carte"
        '
        'familyMealLabel
        '
        Me.familyMealLabel.AutoSize = True
        Me.familyMealLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.familyMealLabel.Location = New System.Drawing.Point(19, 86)
        Me.familyMealLabel.Name = "familyMealLabel"
        Me.familyMealLabel.Size = New System.Drawing.Size(106, 23)
        Me.familyMealLabel.TabIndex = 2
        Me.familyMealLabel.Text = "Family Meal"
        '
        'superValueMealLabel
        '
        Me.superValueMealLabel.AutoSize = True
        Me.superValueMealLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.superValueMealLabel.Location = New System.Drawing.Point(19, 30)
        Me.superValueMealLabel.Name = "superValueMealLabel"
        Me.superValueMealLabel.Size = New System.Drawing.Size(149, 23)
        Me.superValueMealLabel.TabIndex = 1
        Me.superValueMealLabel.Text = "Super Value Meal"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Side1)
        Me.Panel4.Controls.Add(Me.HappyMeal1)
        Me.Panel4.Controls.Add(Me.Dessert1)
        Me.Panel4.Controls.Add(Me.Beverage1)
        Me.Panel4.Controls.Add(Me.McCafeCake1)
        Me.Panel4.Controls.Add(Me.McCafeDrink1)
        Me.Panel4.Controls.Add(Me.PartyPackage1)
        Me.Panel4.Controls.Add(Me.UserControl21)
        Me.Panel4.Controls.Add(Me.UserControl11)
        Me.Panel4.Controls.Add(Me.FamilyMeal1)
        Me.Panel4.Location = New System.Drawing.Point(239, 0)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1676, 743)
        Me.Panel4.TabIndex = 2
        '
        'Side1
        '
        Me.Side1.Location = New System.Drawing.Point(0, 0)
        Me.Side1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Side1.Name = "Side1"
        Me.Side1.Size = New System.Drawing.Size(1676, 1006)
        Me.Side1.TabIndex = 11
        '
        'HappyMeal1
        '
        Me.HappyMeal1.Location = New System.Drawing.Point(0, 0)
        Me.HappyMeal1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.HappyMeal1.Name = "HappyMeal1"
        Me.HappyMeal1.Size = New System.Drawing.Size(1676, 743)
        Me.HappyMeal1.TabIndex = 10
        '
        'Dessert1
        '
        Me.Dessert1.Location = New System.Drawing.Point(0, 0)
        Me.Dessert1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Dessert1.Name = "Dessert1"
        Me.Dessert1.Size = New System.Drawing.Size(1676, 743)
        Me.Dessert1.TabIndex = 9
        '
        'Beverage1
        '
        Me.Beverage1.Location = New System.Drawing.Point(0, 0)
        Me.Beverage1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Beverage1.Name = "Beverage1"
        Me.Beverage1.Size = New System.Drawing.Size(1676, 743)
        Me.Beverage1.TabIndex = 8
        '
        'McCafeCake1
        '
        Me.McCafeCake1.Location = New System.Drawing.Point(0, 0)
        Me.McCafeCake1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.McCafeCake1.Name = "McCafeCake1"
        Me.McCafeCake1.Size = New System.Drawing.Size(1676, 743)
        Me.McCafeCake1.TabIndex = 7
        '
        'McCafeDrink1
        '
        Me.McCafeDrink1.Location = New System.Drawing.Point(0, 0)
        Me.McCafeDrink1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.McCafeDrink1.Name = "McCafeDrink1"
        Me.McCafeDrink1.Size = New System.Drawing.Size(1676, 743)
        Me.McCafeDrink1.TabIndex = 6
        '
        'PartyPackage1
        '
        Me.PartyPackage1.Location = New System.Drawing.Point(0, 0)
        Me.PartyPackage1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PartyPackage1.Name = "PartyPackage1"
        Me.PartyPackage1.Size = New System.Drawing.Size(1676, 743)
        Me.PartyPackage1.TabIndex = 5
        '
        'UserControl21
        '
        Me.UserControl21.Location = New System.Drawing.Point(0, 0)
        Me.UserControl21.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.UserControl21.Name = "UserControl21"
        Me.UserControl21.Size = New System.Drawing.Size(1676, 743)
        Me.UserControl21.TabIndex = 4
        '
        'UserControl11
        '
        Me.UserControl11.Location = New System.Drawing.Point(0, 0)
        Me.UserControl11.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.UserControl11.Name = "UserControl11"
        Me.UserControl11.Size = New System.Drawing.Size(1676, 743)
        Me.UserControl11.TabIndex = 0
        '
        'FamilyMeal1
        '
        Me.FamilyMeal1.Location = New System.Drawing.Point(0, 0)
        Me.FamilyMeal1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.FamilyMeal1.Name = "FamilyMeal1"
        Me.FamilyMeal1.Size = New System.Drawing.Size(1676, 743)
        Me.FamilyMeal1.TabIndex = 3
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.mainMenuPanel)
        Me.FlowLayoutPanel1.Controls.Add(Me.menuPanel)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(1, 0)
        Me.FlowLayoutPanel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(232, 743)
        Me.FlowLayoutPanel1.TabIndex = 3
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.Controls.Add(Me.Panel7)
        Me.FlowLayoutPanel2.Controls.Add(Me.ButttonPanel)
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(4, 750)
        Me.FlowLayoutPanel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(1925, 300)
        Me.FlowLayoutPanel2.TabIndex = 4
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.orderLittleDetailPanel)
        Me.Panel7.Controls.Add(Me.myOrderPanel)
        Me.Panel7.Location = New System.Drawing.Point(3, 2)
        Me.Panel7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(1923, 219)
        Me.Panel7.TabIndex = 12
        '
        'orderLittleDetailPanel
        '
        Me.orderLittleDetailPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.orderLittleDetailPanel.Controls.Add(Me.viewOrderLabel)
        Me.orderLittleDetailPanel.Controls.Add(Me.taxTotalItemsPanel)
        Me.orderLittleDetailPanel.Controls.Add(Me.orderCartLabel)
        Me.orderLittleDetailPanel.Location = New System.Drawing.Point(13, 82)
        Me.orderLittleDetailPanel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.orderLittleDetailPanel.Name = "orderLittleDetailPanel"
        Me.orderLittleDetailPanel.Size = New System.Drawing.Size(1901, 135)
        Me.orderLittleDetailPanel.TabIndex = 1
        '
        'viewOrderLabel
        '
        Me.viewOrderLabel.AutoSize = True
        Me.viewOrderLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.viewOrderLabel.Location = New System.Drawing.Point(1714, 54)
        Me.viewOrderLabel.Name = "viewOrderLabel"
        Me.viewOrderLabel.Size = New System.Drawing.Size(157, 23)
        Me.viewOrderLabel.TabIndex = 22
        Me.viewOrderLabel.Text = "View my order >>"
        Me.viewOrderLabel.Visible = False
        '
        'taxTotalItemsPanel
        '
        Me.taxTotalItemsPanel.Controls.Add(Me.Label12)
        Me.taxTotalItemsPanel.Controls.Add(Me.Label18)
        Me.taxTotalItemsPanel.Controls.Add(Me.Label13)
        Me.taxTotalItemsPanel.Controls.Add(Me.Label17)
        Me.taxTotalItemsPanel.Controls.Add(Me.TotalItemLabel)
        Me.taxTotalItemsPanel.Controls.Add(Me.TotalPriceLabel)
        Me.taxTotalItemsPanel.Controls.Add(Me.Label15)
        Me.taxTotalItemsPanel.Controls.Add(Me.taxLabel)
        Me.taxTotalItemsPanel.Location = New System.Drawing.Point(27, 38)
        Me.taxTotalItemsPanel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.taxTotalItemsPanel.Name = "taxTotalItemsPanel"
        Me.taxTotalItemsPanel.Size = New System.Drawing.Size(561, 57)
        Me.taxTotalItemsPanel.TabIndex = 29
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.Label12.Location = New System.Drawing.Point(352, 17)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(16, 23)
        Me.Label12.TabIndex = 37
        Me.Label12.Text = "|"
        Me.Label12.Visible = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.Label18.Location = New System.Drawing.Point(3, 17)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(47, 23)
        Me.Label18.TabIndex = 31
        Me.Label18.Text = "Tax: "
        Me.Label18.Visible = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.Label13.Location = New System.Drawing.Point(156, 17)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(16, 23)
        Me.Label13.TabIndex = 30
        Me.Label13.Text = "|"
        Me.Label13.Visible = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.Label17.Location = New System.Drawing.Point(189, 17)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(59, 23)
        Me.Label17.TabIndex = 32
        Me.Label17.Text = "Total: "
        Me.Label17.Visible = False
        '
        'TotalItemLabel
        '
        Me.TotalItemLabel.AutoSize = True
        Me.TotalItemLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.TotalItemLabel.Location = New System.Drawing.Point(475, 17)
        Me.TotalItemLabel.Name = "TotalItemLabel"
        Me.TotalItemLabel.Size = New System.Drawing.Size(20, 23)
        Me.TotalItemLabel.TabIndex = 36
        Me.TotalItemLabel.Text = "0"
        Me.TotalItemLabel.Visible = False
        '
        'TotalPriceLabel
        '
        Me.TotalPriceLabel.AutoSize = True
        Me.TotalPriceLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.TotalPriceLabel.Location = New System.Drawing.Point(263, 17)
        Me.TotalPriceLabel.Name = "TotalPriceLabel"
        Me.TotalPriceLabel.Size = New System.Drawing.Size(20, 23)
        Me.TotalPriceLabel.TabIndex = 33
        Me.TotalPriceLabel.Text = "0"
        Me.TotalPriceLabel.Visible = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.Label15.Location = New System.Drawing.Point(395, 17)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(64, 23)
        Me.Label15.TabIndex = 35
        Me.Label15.Text = "Items: "
        Me.Label15.Visible = False
        '
        'taxLabel
        '
        Me.taxLabel.AutoSize = True
        Me.taxLabel.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold)
        Me.taxLabel.Location = New System.Drawing.Point(65, 17)
        Me.taxLabel.Name = "taxLabel"
        Me.taxLabel.Size = New System.Drawing.Size(20, 23)
        Me.taxLabel.TabIndex = 34
        Me.taxLabel.Text = "0"
        Me.taxLabel.Visible = False
        '
        'orderCartLabel
        '
        Me.orderCartLabel.AutoSize = True
        Me.orderCartLabel.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.orderCartLabel.ForeColor = System.Drawing.SystemColors.ActiveBorder
        Me.orderCartLabel.Location = New System.Drawing.Point(765, 37)
        Me.orderCartLabel.Name = "orderCartLabel"
        Me.orderCartLabel.Size = New System.Drawing.Size(329, 45)
        Me.orderCartLabel.TabIndex = 19
        Me.orderCartLabel.Text = "Your Order is empty"
        '
        'myOrderPanel
        '
        Me.myOrderPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.myOrderPanel.Controls.Add(Me.wordLabel)
        Me.myOrderPanel.Location = New System.Drawing.Point(13, 12)
        Me.myOrderPanel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.myOrderPanel.Name = "myOrderPanel"
        Me.myOrderPanel.Size = New System.Drawing.Size(1900, 55)
        Me.myOrderPanel.TabIndex = 0
        '
        'wordLabel
        '
        Me.wordLabel.AutoSize = True
        Me.wordLabel.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.wordLabel.ForeColor = System.Drawing.Color.White
        Me.wordLabel.Location = New System.Drawing.Point(27, 11)
        Me.wordLabel.Name = "wordLabel"
        Me.wordLabel.Size = New System.Drawing.Size(163, 45)
        Me.wordLabel.TabIndex = 0
        Me.wordLabel.Text = "My order"
        '
        'ButttonPanel
        '
        Me.ButttonPanel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ButttonPanel.Controls.Add(Me.nextButton)
        Me.ButttonPanel.Controls.Add(Me.cancelsButton)
        Me.ButttonPanel.Location = New System.Drawing.Point(3, 225)
        Me.ButttonPanel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ButttonPanel.Name = "ButttonPanel"
        Me.ButttonPanel.Size = New System.Drawing.Size(1923, 70)
        Me.ButttonPanel.TabIndex = 2
        '
        'nextButton
        '
        Me.nextButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.nextButton.Enabled = False
        Me.nextButton.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.nextButton.ForeColor = System.Drawing.Color.Silver
        Me.nextButton.Location = New System.Drawing.Point(971, 7)
        Me.nextButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.nextButton.Name = "nextButton"
        Me.nextButton.Size = New System.Drawing.Size(861, 55)
        Me.nextButton.TabIndex = 1
        Me.nextButton.Text = "Next"
        Me.nextButton.UseVisualStyleBackColor = False
        '
        'cancelsButton
        '
        Me.cancelsButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.cancelsButton.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.cancelsButton.ForeColor = System.Drawing.Color.Silver
        Me.cancelsButton.Location = New System.Drawing.Point(91, 7)
        Me.cancelsButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cancelsButton.Name = "cancelsButton"
        Me.cancelsButton.Size = New System.Drawing.Size(861, 55)
        Me.cancelsButton.TabIndex = 0
        Me.cancelsButton.Text = "Cancel Order"
        Me.cancelsButton.UseVisualStyleBackColor = False
        '
        'menus
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1924, 1055)
        Me.Controls.Add(Me.FlowLayoutPanel2)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.Panel4)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "menus"
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.mainMenuPanel.ResumeLayout(False)
        Me.mainMenuPanel.PerformLayout()
        Me.menuPanel.ResumeLayout(False)
        Me.menuPanel.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.orderLittleDetailPanel.ResumeLayout(False)
        Me.orderLittleDetailPanel.PerformLayout()
        Me.taxTotalItemsPanel.ResumeLayout(False)
        Me.taxTotalItemsPanel.PerformLayout()
        Me.myOrderPanel.ResumeLayout(False)
        Me.myOrderPanel.PerformLayout()
        Me.ButttonPanel.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents mainMenuPanel As Panel
    Friend WithEvents mainMenuLabel As Label
    Friend WithEvents superValueMealLabel As Label
    Friend WithEvents menuPanel As Panel
    Friend WithEvents beverageLabel As Label
    Friend WithEvents mcCafeDrinkLabel As Label
    Friend WithEvents mcCafeCakeLabel As Label
    Friend WithEvents partyPackageLabel As Label
    Friend WithEvents valueMealAndAlaCarteLabel As Label
    Friend WithEvents familyMealLabel As Label
    Friend WithEvents sideLabel As Label
    Friend WithEvents happyMealLabel As Label
    Friend WithEvents dessertLabel As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents UserControl11 As SuperValueMeal
    Friend WithEvents FamilyMeal1 As FamilyMeal
    Friend WithEvents UserControl21 As ValueMeal
    Friend WithEvents PartyPackage1 As PartyPackage
    Friend WithEvents McCafeDrink1 As McCafeDrink
    Friend WithEvents McCafeCake1 As McCafeCake
    Friend WithEvents Beverage1 As Beverage
    Friend WithEvents Dessert1 As Dessert
    Friend WithEvents HappyMeal1 As HappyMeal
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents FlowLayoutPanel2 As FlowLayoutPanel
    Friend WithEvents myOrderPanel As Panel
    Friend WithEvents wordLabel As Label
    Friend WithEvents ButttonPanel As Panel
    Friend WithEvents nextButton As Button
    Friend WithEvents cancelsButton As Button
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Side1 As Side
    Friend WithEvents orderLittleDetailPanel As Panel
    Friend WithEvents viewOrderLabel As Label
    Friend WithEvents taxTotalItemsPanel As Panel
    Friend WithEvents Label12 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents TotalItemLabel As Label
    Friend WithEvents TotalPriceLabel As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents taxLabel As Label
    Friend WithEvents orderCartLabel As Label
End Class
