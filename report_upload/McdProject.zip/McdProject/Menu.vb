﻿Public Class Menu
    Public menu As New Form
    Sub UserControl4_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
