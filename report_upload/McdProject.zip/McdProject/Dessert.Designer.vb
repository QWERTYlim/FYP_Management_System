﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Dessert
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dessert))
        Me.dessertLabel = New System.Windows.Forms.Label()
        Me.dessertPanel = New System.Windows.Forms.Panel()
        Me.dessert5PictureBox = New System.Windows.Forms.PictureBox()
        Me.dessert6priceLabel = New System.Windows.Forms.Label()
        Me.dessert2Label = New System.Windows.Forms.Label()
        Me.dessert8PictureBox = New System.Windows.Forms.PictureBox()
        Me.dessert2priceLabel = New System.Windows.Forms.Label()
        Me.dessert7PictureBox = New System.Windows.Forms.PictureBox()
        Me.dessert3Label = New System.Windows.Forms.Label()
        Me.dessert6PictureBox = New System.Windows.Forms.PictureBox()
        Me.dessert6Label = New System.Windows.Forms.Label()
        Me.dessert3priceLabel = New System.Windows.Forms.Label()
        Me.dessert8priceLabel = New System.Windows.Forms.Label()
        Me.desert1Label = New System.Windows.Forms.Label()
        Me.dessert8Label = New System.Windows.Forms.Label()
        Me.dessert4Label = New System.Windows.Forms.Label()
        Me.dessert7priceLabel = New System.Windows.Forms.Label()
        Me.dessert4priceLabel = New System.Windows.Forms.Label()
        Me.dessert7Label = New System.Windows.Forms.Label()
        Me.dessert5Label = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dessert1priceLabel = New System.Windows.Forms.Label()
        Me.dessert1PictureBox = New System.Windows.Forms.PictureBox()
        Me.dessert2PictureBox = New System.Windows.Forms.PictureBox()
        Me.dessert4PictureBox = New System.Windows.Forms.PictureBox()
        Me.dessert3PictureBox = New System.Windows.Forms.PictureBox()
        Me.dessertPanel.SuspendLayout()
        CType(Me.dessert5PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dessert8PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dessert7PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dessert6PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dessert1PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dessert2PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dessert4PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dessert3PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dessertLabel
        '
        Me.dessertLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.dessertLabel.Font = New System.Drawing.Font("Segoe UI", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dessertLabel.Location = New System.Drawing.Point(3, 10)
        Me.dessertLabel.Name = "dessertLabel"
        Me.dessertLabel.Size = New System.Drawing.Size(1670, 99)
        Me.dessertLabel.TabIndex = 132
        Me.dessertLabel.Text = "Dessert"
        '
        'dessertPanel
        '
        Me.dessertPanel.Controls.Add(Me.dessert5PictureBox)
        Me.dessertPanel.Controls.Add(Me.dessert6priceLabel)
        Me.dessertPanel.Controls.Add(Me.dessert2Label)
        Me.dessertPanel.Controls.Add(Me.dessert8PictureBox)
        Me.dessertPanel.Controls.Add(Me.dessert2priceLabel)
        Me.dessertPanel.Controls.Add(Me.dessert7PictureBox)
        Me.dessertPanel.Controls.Add(Me.dessert3Label)
        Me.dessertPanel.Controls.Add(Me.dessert6PictureBox)
        Me.dessertPanel.Controls.Add(Me.dessert6Label)
        Me.dessertPanel.Controls.Add(Me.dessert3priceLabel)
        Me.dessertPanel.Controls.Add(Me.dessert8priceLabel)
        Me.dessertPanel.Controls.Add(Me.desert1Label)
        Me.dessertPanel.Controls.Add(Me.dessert8Label)
        Me.dessertPanel.Controls.Add(Me.dessert4Label)
        Me.dessertPanel.Controls.Add(Me.dessert7priceLabel)
        Me.dessertPanel.Controls.Add(Me.dessert4priceLabel)
        Me.dessertPanel.Controls.Add(Me.dessert7Label)
        Me.dessertPanel.Controls.Add(Me.dessert5Label)
        Me.dessertPanel.Controls.Add(Me.Label1)
        Me.dessertPanel.Controls.Add(Me.dessert1priceLabel)
        Me.dessertPanel.Controls.Add(Me.dessert1PictureBox)
        Me.dessertPanel.Controls.Add(Me.dessert2PictureBox)
        Me.dessertPanel.Controls.Add(Me.dessert4PictureBox)
        Me.dessertPanel.Controls.Add(Me.dessert3PictureBox)
        Me.dessertPanel.Location = New System.Drawing.Point(12, 112)
        Me.dessertPanel.Name = "dessertPanel"
        Me.dessertPanel.Size = New System.Drawing.Size(1650, 521)
        Me.dessertPanel.TabIndex = 209
        '
        'dessert5PictureBox
        '
        Me.dessert5PictureBox.Image = CType(resources.GetObject("dessert5PictureBox.Image"), System.Drawing.Image)
        Me.dessert5PictureBox.Location = New System.Drawing.Point(1360, 10)
        Me.dessert5PictureBox.Name = "dessert5PictureBox"
        Me.dessert5PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.dessert5PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.dessert5PictureBox.TabIndex = 197
        Me.dessert5PictureBox.TabStop = False
        '
        'dessert6priceLabel
        '
        Me.dessert6priceLabel.AutoSize = True
        Me.dessert6priceLabel.Location = New System.Drawing.Point(16, 436)
        Me.dessert6priceLabel.Name = "dessert6priceLabel"
        Me.dessert6priceLabel.Size = New System.Drawing.Size(93, 17)
        Me.dessert6priceLabel.TabIndex = 207
        Me.dessert6priceLabel.Text = "From RM4.53"
        '
        'dessert2Label
        '
        Me.dessert2Label.AutoSize = True
        Me.dessert2Label.Location = New System.Drawing.Point(369, 179)
        Me.dessert2Label.Name = "dessert2Label"
        Me.dessert2Label.Size = New System.Drawing.Size(120, 17)
        Me.dessert2Label.TabIndex = 184
        Me.dessert2Label.Text = "Cendol McFlurry™"
        '
        'dessert8PictureBox
        '
        Me.dessert8PictureBox.Image = CType(resources.GetObject("dessert8PictureBox.Image"), System.Drawing.Image)
        Me.dessert8PictureBox.Location = New System.Drawing.Point(719, 250)
        Me.dessert8PictureBox.Name = "dessert8PictureBox"
        Me.dessert8PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.dessert8PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.dessert8PictureBox.TabIndex = 206
        Me.dessert8PictureBox.TabStop = False
        '
        'dessert2priceLabel
        '
        Me.dessert2priceLabel.AutoSize = True
        Me.dessert2priceLabel.Location = New System.Drawing.Point(369, 196)
        Me.dessert2priceLabel.Name = "dessert2priceLabel"
        Me.dessert2priceLabel.Size = New System.Drawing.Size(93, 17)
        Me.dessert2priceLabel.TabIndex = 185
        Me.dessert2priceLabel.Text = "From RM7.08"
        '
        'dessert7PictureBox
        '
        Me.dessert7PictureBox.Image = CType(resources.GetObject("dessert7PictureBox.Image"), System.Drawing.Image)
        Me.dessert7PictureBox.Location = New System.Drawing.Point(369, 250)
        Me.dessert7PictureBox.Name = "dessert7PictureBox"
        Me.dessert7PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.dessert7PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.dessert7PictureBox.TabIndex = 205
        Me.dessert7PictureBox.TabStop = False
        '
        'dessert3Label
        '
        Me.dessert3Label.AutoSize = True
        Me.dessert3Label.Location = New System.Drawing.Point(719, 179)
        Me.dessert3Label.Name = "dessert3Label"
        Me.dessert3Label.Size = New System.Drawing.Size(62, 17)
        Me.dessert3Label.TabIndex = 186
        Me.dessert3Label.Text = "Corn Pie"
        '
        'dessert6PictureBox
        '
        Me.dessert6PictureBox.Image = CType(resources.GetObject("dessert6PictureBox.Image"), System.Drawing.Image)
        Me.dessert6PictureBox.Location = New System.Drawing.Point(16, 250)
        Me.dessert6PictureBox.Name = "dessert6PictureBox"
        Me.dessert6PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.dessert6PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.dessert6PictureBox.TabIndex = 204
        Me.dessert6PictureBox.TabStop = False
        '
        'dessert6Label
        '
        Me.dessert6Label.AutoSize = True
        Me.dessert6Label.Location = New System.Drawing.Point(16, 419)
        Me.dessert6Label.Name = "dessert6Label"
        Me.dessert6Label.Size = New System.Drawing.Size(124, 17)
        Me.dessert6Label.TabIndex = 203
        Me.dessert6Label.Text = "Chocolate Sundae"
        '
        'dessert3priceLabel
        '
        Me.dessert3priceLabel.AutoSize = True
        Me.dessert3priceLabel.Location = New System.Drawing.Point(719, 196)
        Me.dessert3priceLabel.Name = "dessert3priceLabel"
        Me.dessert3priceLabel.Size = New System.Drawing.Size(93, 17)
        Me.dessert3priceLabel.TabIndex = 187
        Me.dessert3priceLabel.Text = "From RM4.25"
        '
        'dessert8priceLabel
        '
        Me.dessert8priceLabel.AutoSize = True
        Me.dessert8priceLabel.Location = New System.Drawing.Point(719, 436)
        Me.dessert8priceLabel.Name = "dessert8priceLabel"
        Me.dessert8priceLabel.Size = New System.Drawing.Size(93, 17)
        Me.dessert8priceLabel.TabIndex = 202
        Me.dessert8priceLabel.Text = "From RM3.77"
        '
        'desert1Label
        '
        Me.desert1Label.AutoSize = True
        Me.desert1Label.Location = New System.Drawing.Point(16, 179)
        Me.desert1Label.Name = "desert1Label"
        Me.desert1Label.Size = New System.Drawing.Size(200, 17)
        Me.desert1Label.TabIndex = 188
        Me.desert1Label.Text = "Cendol and Chocolate Sundae"
        '
        'dessert8Label
        '
        Me.dessert8Label.AutoSize = True
        Me.dessert8Label.Location = New System.Drawing.Point(719, 419)
        Me.dessert8Label.Name = "dessert8Label"
        Me.dessert8Label.Size = New System.Drawing.Size(68, 17)
        Me.dessert8Label.TabIndex = 201
        Me.dessert8Label.Text = "Apple Pie"
        '
        'dessert4Label
        '
        Me.dessert4Label.AutoSize = True
        Me.dessert4Label.Location = New System.Drawing.Point(1053, 179)
        Me.dessert4Label.Name = "dessert4Label"
        Me.dessert4Label.Size = New System.Drawing.Size(110, 17)
        Me.dessert4Label.TabIndex = 189
        Me.dessert4Label.Text = "Black Forest Pie"
        '
        'dessert7priceLabel
        '
        Me.dessert7priceLabel.AutoSize = True
        Me.dessert7priceLabel.Location = New System.Drawing.Point(369, 436)
        Me.dessert7priceLabel.Name = "dessert7priceLabel"
        Me.dessert7priceLabel.Size = New System.Drawing.Size(93, 17)
        Me.dessert7priceLabel.TabIndex = 200
        Me.dessert7priceLabel.Text = "From RM4.53"
        '
        'dessert4priceLabel
        '
        Me.dessert4priceLabel.AutoSize = True
        Me.dessert4priceLabel.Location = New System.Drawing.Point(1053, 196)
        Me.dessert4priceLabel.Name = "dessert4priceLabel"
        Me.dessert4priceLabel.Size = New System.Drawing.Size(93, 17)
        Me.dessert4priceLabel.TabIndex = 190
        Me.dessert4priceLabel.Text = "From RM4.25"
        '
        'dessert7Label
        '
        Me.dessert7Label.AutoSize = True
        Me.dessert7Label.Location = New System.Drawing.Point(369, 419)
        Me.dessert7Label.Name = "dessert7Label"
        Me.dessert7Label.Size = New System.Drawing.Size(129, 17)
        Me.dessert7Label.TabIndex = 199
        Me.dessert7Label.Text = "Strawberry Sundae"
        '
        'dessert5Label
        '
        Me.dessert5Label.AutoSize = True
        Me.dessert5Label.Location = New System.Drawing.Point(1360, 179)
        Me.dessert5Label.Name = "dessert5Label"
        Me.dessert5Label.Size = New System.Drawing.Size(127, 17)
        Me.dessert5Label.TabIndex = 191
        Me.dessert5Label.Text = "OREO® McFlurry™"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(1360, 196)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 17)
        Me.Label1.TabIndex = 192
        Me.Label1.Text = "From RM6.60"
        '
        'dessert1priceLabel
        '
        Me.dessert1priceLabel.AutoSize = True
        Me.dessert1priceLabel.Location = New System.Drawing.Point(16, 196)
        Me.dessert1priceLabel.Name = "dessert1priceLabel"
        Me.dessert1priceLabel.Size = New System.Drawing.Size(93, 17)
        Me.dessert1priceLabel.TabIndex = 198
        Me.dessert1priceLabel.Text = "From RM5.19"
        '
        'dessert1PictureBox
        '
        Me.dessert1PictureBox.Image = CType(resources.GetObject("dessert1PictureBox.Image"), System.Drawing.Image)
        Me.dessert1PictureBox.Location = New System.Drawing.Point(16, 10)
        Me.dessert1PictureBox.Name = "dessert1PictureBox"
        Me.dessert1PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.dessert1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.dessert1PictureBox.TabIndex = 193
        Me.dessert1PictureBox.TabStop = False
        '
        'dessert2PictureBox
        '
        Me.dessert2PictureBox.Image = CType(resources.GetObject("dessert2PictureBox.Image"), System.Drawing.Image)
        Me.dessert2PictureBox.Location = New System.Drawing.Point(369, 10)
        Me.dessert2PictureBox.Name = "dessert2PictureBox"
        Me.dessert2PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.dessert2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.dessert2PictureBox.TabIndex = 194
        Me.dessert2PictureBox.TabStop = False
        '
        'dessert4PictureBox
        '
        Me.dessert4PictureBox.Image = CType(resources.GetObject("dessert4PictureBox.Image"), System.Drawing.Image)
        Me.dessert4PictureBox.Location = New System.Drawing.Point(1056, 10)
        Me.dessert4PictureBox.Name = "dessert4PictureBox"
        Me.dessert4PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.dessert4PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.dessert4PictureBox.TabIndex = 196
        Me.dessert4PictureBox.TabStop = False
        '
        'dessert3PictureBox
        '
        Me.dessert3PictureBox.Image = CType(resources.GetObject("dessert3PictureBox.Image"), System.Drawing.Image)
        Me.dessert3PictureBox.Location = New System.Drawing.Point(719, 10)
        Me.dessert3PictureBox.Name = "dessert3PictureBox"
        Me.dessert3PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.dessert3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.dessert3PictureBox.TabIndex = 195
        Me.dessert3PictureBox.TabStop = False
        '
        'Dessert
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.dessertPanel)
        Me.Controls.Add(Me.dessertLabel)
        Me.Name = "Dessert"
        Me.Size = New System.Drawing.Size(1676, 1038)
        Me.dessertPanel.ResumeLayout(False)
        Me.dessertPanel.PerformLayout()
        CType(Me.dessert5PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dessert8PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dessert7PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dessert6PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dessert1PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dessert2PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dessert4PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dessert3PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents dessertLabel As Label
    Friend WithEvents dessertPanel As Panel
    Friend WithEvents dessert5PictureBox As PictureBox
    Friend WithEvents dessert6priceLabel As Label
    Friend WithEvents dessert2Label As Label
    Friend WithEvents dessert8PictureBox As PictureBox
    Friend WithEvents dessert2priceLabel As Label
    Friend WithEvents dessert7PictureBox As PictureBox
    Friend WithEvents dessert3Label As Label
    Friend WithEvents dessert6PictureBox As PictureBox
    Friend WithEvents dessert6Label As Label
    Friend WithEvents dessert3priceLabel As Label
    Friend WithEvents dessert8priceLabel As Label
    Friend WithEvents desert1Label As Label
    Friend WithEvents dessert8Label As Label
    Friend WithEvents dessert4Label As Label
    Friend WithEvents dessert7priceLabel As Label
    Friend WithEvents dessert4priceLabel As Label
    Friend WithEvents dessert7Label As Label
    Friend WithEvents dessert5Label As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents dessert1priceLabel As Label
    Friend WithEvents dessert1PictureBox As PictureBox
    Friend WithEvents dessert2PictureBox As PictureBox
    Friend WithEvents dessert4PictureBox As PictureBox
    Friend WithEvents dessert3PictureBox As PictureBox
End Class
