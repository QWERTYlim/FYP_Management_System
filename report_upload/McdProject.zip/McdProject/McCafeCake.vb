﻿Public Class McCafeCake
    Private Sub exitButton_Click(sender As Object, e As EventArgs) 
        Application.Exit()
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles mcCafeCakePanel.Paint

    End Sub
    Public Sub quantitys(ByVal setnum As Integer)
        Dim picture() = {mcCafeCake1PictureBox, mcCafeCake2PictureBox, mcCafeCake3PictureBox, mcCafeCake4PictureBox, mcCafeCake5PictureBox, mcCafeCake6PictureBox, mcCafeCake7PictureBox, mcCafeCake8PictureBox, mcCafeCake9PictureBox, mcCafeCake10PictureBox, mcCafeCake11PictureBox}
        Dim price() = {12.25, 12.25, 12.25, 12.25, 6.13, 6.13, 11.31, 11.31, 11.31, 11.31, 11.31}
        Dim setname() = {mcCafeCake1Label.Text, mcCafeCake2Label.Text, mcCafeCake3Label.Text, mcCafeCake4Label.Text, mcCafeCake5Label.Text, mcCafeCake6Label.Text, mcCafeCake7Label.Text, mcCafeCake8Label.Text, mcCafeCake9Label.Text, mcCafeCake10Label.Text, mcCafeCake11Label.Text}
        Quantity.SetPictureBox.Image = picture(setnum).Image
        Quantity.Label2.Text = price(setnum)
        Quantity.Label1.Text = setname(setnum)
        Quantity.one_set_price = price(setnum)
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles mcCafeCake1PictureBox.Click
        quantitys(0)
        Quantity.Show()
        Quantity.set_choosen = 51
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles mcCafeCake2PictureBox.Click
        quantitys(1)
        Quantity.Show()
        Quantity.set_choosen = 52
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles mcCafeCake3PictureBox.Click
        quantitys(2)
        Quantity.Show()
        Quantity.set_choosen = 53
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles mcCafeCake4PictureBox.Click
        quantitys(3)
        Quantity.Show()
        Quantity.set_choosen = 54
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles mcCafeCake5PictureBox.Click
        quantitys(4)
        Quantity.Show()
        Quantity.set_choosen = 55
    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles mcCafeCake6PictureBox.Click
        quantitys(5)
        Quantity.Show()
        Quantity.set_choosen = 56
    End Sub

    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles mcCafeCake7PictureBox.Click
        quantitys(6)
        Quantity.Show()
        Quantity.set_choosen = 57
    End Sub

    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles mcCafeCake8PictureBox.Click
        quantitys(7)
        Quantity.Show()
        Quantity.set_choosen = 58
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles mcCafeCake9PictureBox.Click
        quantitys(8)
        Quantity.Show()
        Quantity.set_choosen = 59
    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles mcCafeCake10PictureBox.Click
        quantitys(9)
        Quantity.Show()
        Quantity.set_choosen = 60
    End Sub

    Private Sub PictureBox11_Click(sender As Object, e As EventArgs) Handles mcCafeCake11PictureBox.Click
        quantitys(10)
        Quantity.Show()
        Quantity.set_choosen = 61
    End Sub
End Class
