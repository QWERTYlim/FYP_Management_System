﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Eatin_takeaway
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Eatin_takeaway))
        Me.takeOutLabel = New System.Windows.Forms.Label()
        Me.eatInLabel = New System.Windows.Forms.Label()
        Me.takeOutPictureBox = New System.Windows.Forms.PictureBox()
        Me.eatInPictureBox = New System.Windows.Forms.PictureBox()
        Me.chooseLabel = New System.Windows.Forms.Label()
        Me.mcdLogoPictureBox = New System.Windows.Forms.PictureBox()
        CType(Me.takeOutPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.eatInPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mcdLogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'takeOutLabel
        '
        Me.takeOutLabel.AutoSize = True
        Me.takeOutLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.takeOutLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.takeOutLabel.Location = New System.Drawing.Point(1100, 654)
        Me.takeOutLabel.Name = "takeOutLabel"
        Me.takeOutLabel.Size = New System.Drawing.Size(102, 25)
        Me.takeOutLabel.TabIndex = 14
        Me.takeOutLabel.Text = "Take Out"
        '
        'eatInLabel
        '
        Me.eatInLabel.AutoSize = True
        Me.eatInLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.eatInLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.eatInLabel.Location = New System.Drawing.Point(723, 654)
        Me.eatInLabel.Name = "eatInLabel"
        Me.eatInLabel.Size = New System.Drawing.Size(68, 25)
        Me.eatInLabel.TabIndex = 13
        Me.eatInLabel.Text = "Eat In"
        '
        'takeOutPictureBox
        '
        Me.takeOutPictureBox.Image = CType(resources.GetObject("takeOutPictureBox.Image"), System.Drawing.Image)
        Me.takeOutPictureBox.Location = New System.Drawing.Point(1058, 426)
        Me.takeOutPictureBox.Name = "takeOutPictureBox"
        Me.takeOutPictureBox.Size = New System.Drawing.Size(196, 208)
        Me.takeOutPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.takeOutPictureBox.TabIndex = 12
        Me.takeOutPictureBox.TabStop = False
        '
        'eatInPictureBox
        '
        Me.eatInPictureBox.Image = CType(resources.GetObject("eatInPictureBox.Image"), System.Drawing.Image)
        Me.eatInPictureBox.Location = New System.Drawing.Point(671, 426)
        Me.eatInPictureBox.Name = "eatInPictureBox"
        Me.eatInPictureBox.Size = New System.Drawing.Size(196, 208)
        Me.eatInPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.eatInPictureBox.TabIndex = 11
        Me.eatInPictureBox.TabStop = False
        '
        'chooseLabel
        '
        Me.chooseLabel.AutoSize = True
        Me.chooseLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chooseLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.chooseLabel.Location = New System.Drawing.Point(895, 261)
        Me.chooseLabel.Name = "chooseLabel"
        Me.chooseLabel.Size = New System.Drawing.Size(165, 46)
        Me.chooseLabel.TabIndex = 10
        Me.chooseLabel.Text = "Choose"
        '
        'mcdLogoPictureBox
        '
        Me.mcdLogoPictureBox.Image = CType(resources.GetObject("mcdLogoPictureBox.Image"), System.Drawing.Image)
        Me.mcdLogoPictureBox.Location = New System.Drawing.Point(778, 45)
        Me.mcdLogoPictureBox.Name = "mcdLogoPictureBox"
        Me.mcdLogoPictureBox.Size = New System.Drawing.Size(389, 195)
        Me.mcdLogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcdLogoPictureBox.TabIndex = 9
        Me.mcdLogoPictureBox.TabStop = False
        '
        'Eatin_takeaway
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1924, 1055)
        Me.Controls.Add(Me.takeOutLabel)
        Me.Controls.Add(Me.eatInLabel)
        Me.Controls.Add(Me.takeOutPictureBox)
        Me.Controls.Add(Me.eatInPictureBox)
        Me.Controls.Add(Me.chooseLabel)
        Me.Controls.Add(Me.mcdLogoPictureBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Eatin_takeaway"
        Me.Text = "Choose"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.takeOutPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.eatInPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mcdLogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents takeOutLabel As Label
    Friend WithEvents eatInLabel As Label
    Friend WithEvents takeOutPictureBox As PictureBox
    Friend WithEvents eatInPictureBox As PictureBox
    Friend WithEvents chooseLabel As Label
    Friend WithEvents mcdLogoPictureBox As PictureBox
End Class
