﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FamilyMeal
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FamilyMeal))
        Me.familyMealLabel = New System.Windows.Forms.Label()
        Me.familyMealPanel = New System.Windows.Forms.Panel()
        Me.familyMeal1PictureBox = New System.Windows.Forms.PictureBox()
        Me.familyMeal3PictureBox = New System.Windows.Forms.PictureBox()
        Me.familyMeal3PriceLabel = New System.Windows.Forms.Label()
        Me.familyMeal2PictureBox = New System.Windows.Forms.PictureBox()
        Me.familyMeal3Label = New System.Windows.Forms.Label()
        Me.familyMeal2PriceLabel = New System.Windows.Forms.Label()
        Me.familyMeal1PriceLabel = New System.Windows.Forms.Label()
        Me.familyMeal2Label = New System.Windows.Forms.Label()
        Me.familyMeal1Label = New System.Windows.Forms.Label()
        Me.familyMealPanel.SuspendLayout()
        CType(Me.familyMeal1PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.familyMeal3PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.familyMeal2PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'familyMealLabel
        '
        Me.familyMealLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.familyMealLabel.Font = New System.Drawing.Font("Segoe UI", 25.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.familyMealLabel.Location = New System.Drawing.Point(3, 10)
        Me.familyMealLabel.Name = "familyMealLabel"
        Me.familyMealLabel.Size = New System.Drawing.Size(1670, 99)
        Me.familyMealLabel.TabIndex = 48
        Me.familyMealLabel.Text = "Family Meal"
        '
        'familyMealPanel
        '
        Me.familyMealPanel.Controls.Add(Me.familyMeal1PictureBox)
        Me.familyMealPanel.Controls.Add(Me.familyMeal3PictureBox)
        Me.familyMealPanel.Controls.Add(Me.familyMeal3PriceLabel)
        Me.familyMealPanel.Controls.Add(Me.familyMeal2PictureBox)
        Me.familyMealPanel.Controls.Add(Me.familyMeal3Label)
        Me.familyMealPanel.Controls.Add(Me.familyMeal2PriceLabel)
        Me.familyMealPanel.Controls.Add(Me.familyMeal1PriceLabel)
        Me.familyMealPanel.Controls.Add(Me.familyMeal2Label)
        Me.familyMealPanel.Controls.Add(Me.familyMeal1Label)
        Me.familyMealPanel.Location = New System.Drawing.Point(12, 112)
        Me.familyMealPanel.Name = "familyMealPanel"
        Me.familyMealPanel.Size = New System.Drawing.Size(1650, 521)
        Me.familyMealPanel.TabIndex = 50
        '
        'familyMeal1PictureBox
        '
        Me.familyMeal1PictureBox.Image = CType(resources.GetObject("familyMeal1PictureBox.Image"), System.Drawing.Image)
        Me.familyMeal1PictureBox.Location = New System.Drawing.Point(16, 10)
        Me.familyMeal1PictureBox.Name = "familyMeal1PictureBox"
        Me.familyMeal1PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.familyMeal1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.familyMeal1PictureBox.TabIndex = 33
        Me.familyMeal1PictureBox.TabStop = False
        '
        'familyMeal3PictureBox
        '
        Me.familyMeal3PictureBox.Image = CType(resources.GetObject("familyMeal3PictureBox.Image"), System.Drawing.Image)
        Me.familyMeal3PictureBox.Location = New System.Drawing.Point(722, 10)
        Me.familyMeal3PictureBox.Name = "familyMeal3PictureBox"
        Me.familyMeal3PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.familyMeal3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.familyMeal3PictureBox.TabIndex = 35
        Me.familyMeal3PictureBox.TabStop = False
        '
        'familyMeal3PriceLabel
        '
        Me.familyMeal3PriceLabel.AutoSize = True
        Me.familyMeal3PriceLabel.Location = New System.Drawing.Point(719, 197)
        Me.familyMeal3PriceLabel.Name = "familyMeal3PriceLabel"
        Me.familyMeal3PriceLabel.Size = New System.Drawing.Size(101, 17)
        Me.familyMeal3PriceLabel.TabIndex = 47
        Me.familyMeal3PriceLabel.Text = "From RM37.73"
        '
        'familyMeal2PictureBox
        '
        Me.familyMeal2PictureBox.Image = CType(resources.GetObject("familyMeal2PictureBox.Image"), System.Drawing.Image)
        Me.familyMeal2PictureBox.Location = New System.Drawing.Point(369, 10)
        Me.familyMeal2PictureBox.Name = "familyMeal2PictureBox"
        Me.familyMeal2PictureBox.Size = New System.Drawing.Size(237, 166)
        Me.familyMeal2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.familyMeal2PictureBox.TabIndex = 34
        Me.familyMeal2PictureBox.TabStop = False
        '
        'familyMeal3Label
        '
        Me.familyMeal3Label.AutoSize = True
        Me.familyMeal3Label.Location = New System.Drawing.Point(719, 179)
        Me.familyMeal3Label.Name = "familyMeal3Label"
        Me.familyMeal3Label.Size = New System.Drawing.Size(131, 17)
        Me.familyMeal3Label.TabIndex = 44
        Me.familyMeal3Label.Text = "Family Meal - Mixed"
        '
        'familyMeal2PriceLabel
        '
        Me.familyMeal2PriceLabel.AutoSize = True
        Me.familyMeal2PriceLabel.Location = New System.Drawing.Point(367, 197)
        Me.familyMeal2PriceLabel.Name = "familyMeal2PriceLabel"
        Me.familyMeal2PriceLabel.Size = New System.Drawing.Size(101, 17)
        Me.familyMeal2PriceLabel.TabIndex = 43
        Me.familyMeal2PriceLabel.Text = "From RM37.73"
        '
        'familyMeal1PriceLabel
        '
        Me.familyMeal1PriceLabel.AutoSize = True
        Me.familyMeal1PriceLabel.Location = New System.Drawing.Point(17, 196)
        Me.familyMeal1PriceLabel.Name = "familyMeal1PriceLabel"
        Me.familyMeal1PriceLabel.Size = New System.Drawing.Size(101, 17)
        Me.familyMeal1PriceLabel.TabIndex = 46
        Me.familyMeal1PriceLabel.Text = "From RM37.73"
        '
        'familyMeal2Label
        '
        Me.familyMeal2Label.AutoSize = True
        Me.familyMeal2Label.Location = New System.Drawing.Point(367, 179)
        Me.familyMeal2Label.Name = "familyMeal2Label"
        Me.familyMeal2Label.Size = New System.Drawing.Size(145, 17)
        Me.familyMeal2Label.TabIndex = 42
        Me.familyMeal2Label.Text = "Family Meal - Regular"
        '
        'familyMeal1Label
        '
        Me.familyMeal1Label.AutoSize = True
        Me.familyMeal1Label.Location = New System.Drawing.Point(17, 179)
        Me.familyMeal1Label.Name = "familyMeal1Label"
        Me.familyMeal1Label.Size = New System.Drawing.Size(129, 17)
        Me.familyMeal1Label.TabIndex = 41
        Me.familyMeal1Label.Text = "Family Meal - Spicy"
        '
        'FamilyMeal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.familyMealPanel)
        Me.Controls.Add(Me.familyMealLabel)
        Me.Name = "FamilyMeal"
        Me.Size = New System.Drawing.Size(1676, 1038)
        Me.familyMealPanel.ResumeLayout(False)
        Me.familyMealPanel.PerformLayout()
        CType(Me.familyMeal1PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.familyMeal3PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.familyMeal2PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents familyMealLabel As Label
    Friend WithEvents familyMealPanel As Panel
    Friend WithEvents familyMeal1PictureBox As PictureBox
    Friend WithEvents familyMeal3PictureBox As PictureBox
    Friend WithEvents familyMeal3PriceLabel As Label
    Friend WithEvents familyMeal2PictureBox As PictureBox
    Friend WithEvents familyMeal3Label As Label
    Friend WithEvents familyMeal2PriceLabel As Label
    Friend WithEvents familyMeal1PriceLabel As Label
    Friend WithEvents familyMeal2Label As Label
    Friend WithEvents familyMeal1Label As Label
End Class
