﻿Public Class ViewOrder
    Dim taxtomenu
    Dim totaltomenu
    Dim totalsettomenu
    Dim doit As Boolean = False

    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles backButton.Click
        If doit = True Then
            taxtomenu = Math.Round(taxtomenu, 2)
            menus.taxLabel.Text = taxtomenu.ToString
            menus.TotalPriceLabel.Text = totaltomenu.ToString
            menus.TotalItemLabel.Text = totalsettomenu.ToString
        End If

        Me.Close()
    End Sub
    Dim buttons(90) As Button
    Private Sub ViewOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For i As Integer = 0 To 90
            buttons(i) = New Button
            buttons(i).Width = 80
            buttons(i).Height = 30
            buttons(i).Left = 720

            buttons(i).Text = "Remove"
            buttons(i).Tag = i
            AddHandler buttons(i).Click, AddressOf buttonHandler
        Next
        Dim top As Integer = 0
        For i As Integer = 0 To 90
            If menus.set_detail(i, 2) <> 0 Then
                buttons(i).Top = top
                top += 51
                foodPanel.Controls.Add(buttons(i))
            End If
        Next
    End Sub
    Sub buttonHandler(sender As Button, e As EventArgs)
        doit = True
        Dim top As Integer = 0
        Dim id As Integer = Integer.Parse(sender.Tag)
        menus.set_detail(id, 2) = 0
        For i As Integer = 0 To 90
            If menus.set_detail(i, 2) = 0 Then
                foodPanel.Controls.Remove(buttons(i))
            End If
        Next
        For i As Integer = 0 To 90
            If menus.set_detail(i, 2) <> 0 Then
                buttons(i).Top = top
                top += 51
                foodPanel.Controls.Add(buttons(i))
            End If
        Next

        Dim setnameoutput As String
        Dim quantityoutput As String
        Dim priceoutput As String
        Dim alreadyexist As Boolean = True
        Dim temp As Double

        For i As Integer = 0 To 90
            If menus.set_detail(i, 2) <> 0 Then
                temp = (menus.set_detail(i, 1) * menus.set_detail(i, 2))
                If alreadyexist = True Then
                    setnameoutput = menus.set_detail(i, 0).ToString
                    quantityoutput = menus.set_detail(i, 2).ToString
                    priceoutput = temp.ToString("f2")
                    alreadyexist = False
                Else
                    setnameoutput = setnameoutput + vbNewLine + vbNewLine + menus.set_detail(i, 0).ToString
                    quantityoutput = quantityoutput + vbNewLine + vbNewLine + menus.set_detail(i, 2).ToString
                    priceoutput = priceoutput + vbNewLine + vbNewLine + temp.ToString("f2")
                End If
            End If
        Next
        Dim total_price As Double
        Dim totalpricewithtax As Double
        Dim totalset As Integer
        For i As Integer = 0 To 90
            If menus.set_detail(i, 2) <> 0 Then
                total_price += (menus.set_detail(i, 1) * menus.set_detail(i, 2))
                totalset += menus.set_detail(i, 2)
            End If
        Next
        totalsettomenu = totalset
        totalpricewithtax = total_price * 1.06
        taxtomenu = total_price * 0.06
        totaltomenu = total_price
        setnameoutput = setnameoutput + vbNewLine + vbNewLine + "Tax 6%"
        priceoutput = priceoutput + vbNewLine + vbNewLine + (total_price * 0.06).ToString("f2")
        If menus.takeaway = True Then
            setnameoutput = setnameoutput + vbNewLine + vbNewLine + "Takeaway Fee"
            priceoutput = priceoutput + vbNewLine + vbNewLine + "1.20"
            totaltomenu += 1.2
            totalpricewithtax += 1.2
        End If

        FoodNameLabel.Text = setnameoutput
        FoodsPriceLabel.Text = priceoutput
        FoodsQuantityLabel.Text = quantityoutput
        totalPriceLabel.Text = totalpricewithtax.ToString("f2")
        If totalsettomenu = 0 Then
            Me.Close()
            menus.orderCartLabel.Visible = True
            menus.Label18.Visible = False
            menus.taxLabel.Visible = False
            menus.Label13.Visible = False
            menus.Label17.Visible = False
            menus.TotalPriceLabel.Visible = False
            menus.Label12.Visible = False
            menus.Label15.Visible = False
            menus.TotalItemLabel.Visible = False
            menus.viewOrderLabel.Visible = False
            menus.nextButton.Enabled = False
            menus.cancelsButton.BackColor = Color.FromArgb(247, 94, 100)
            menus.nextButton.BackColor = Color.FromArgb(80, 97, 77)
        End If

    End Sub
End Class