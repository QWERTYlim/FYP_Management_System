﻿Public Class McCafeDrink
    Private Sub Label18_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub exitButton_Click(sender As Object, e As EventArgs) 
        Application.Exit()
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles mcCafeDrinkPanel.Paint

    End Sub
    Public Sub quantitys(ByVal setnum As Integer)
        Dim picture() = {mcCafeDrink1PictureBox, mcCafeDrink2PictureBox, mcCafeDrink3PictureBox, mcCafeDrink4PictureBox, mcCafeDrink5PictureBox, mcCafeDrink6PictureBox, mcCafeDrink7PictureBox, mcCafeDrink8PictureBox, mcCafeDrink9PictureBox, mcCafeDrink10PictureBox, mcCafeDrink11PictureBox, mcCafeDrink12PictureBox, mcCafeDrink13PictureBox}
        Dim price() = {10.37, 10.37, 8.96, 8.96, 7.54, 7.54, 7.54, 7.54, 4.72, 12.25, 12.25, 12.25, 12.25}
        Dim setname() = {mcCafeDrink1Label.Text, mcCafeDrink2Label.Text, mcCafeDrink3Label.Text, mcCafeDrink4Label.Text, mcCafeDrink5Label.Text, mcCafeDrink6Label.Text, mcCafeDrink7Label.Text, mcCafeDrink8Label.Text, mcCafeDrink9Label.Text, mcCafeDrink10Label.Text, mcCafeDrink11Label.Text, mcCafeDrink12Label.Text, mcCafeDrink13Label.Text}
        Quantity.SetPictureBox.Image = picture(setnum).Image
        Quantity.Label2.Text = price(setnum)
        Quantity.Label1.Text = setname(setnum)
        Quantity.one_set_price = price(setnum)
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles mcCafeDrink1PictureBox.Click
        quantitys(0)
        Quantity.Show()
        Quantity.set_choosen = 38
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles mcCafeDrink2PictureBox.Click
        quantitys(1)
        Quantity.Show()
        Quantity.set_choosen = 39
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles mcCafeDrink3PictureBox.Click
        quantitys(2)
        Quantity.Show()
        Quantity.set_choosen = 40
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles mcCafeDrink4PictureBox.Click
        quantitys(3)
        Quantity.Show()
        Quantity.set_choosen = 41
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles mcCafeDrink5PictureBox.Click
        quantitys(4)
        Quantity.Show()
        Quantity.set_choosen = 42
    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles mcCafeDrink6PictureBox.Click
        quantitys(5)
        Quantity.Show()
        Quantity.set_choosen = 43
    End Sub

    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles mcCafeDrink7PictureBox.Click
        quantitys(6)
        Quantity.Show()
        Quantity.set_choosen = 44
    End Sub

    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles mcCafeDrink8PictureBox.Click
        quantitys(7)
        Quantity.Show()
        Quantity.set_choosen = 45
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles mcCafeDrink9PictureBox.Click
        quantitys(8)
        Quantity.Show()
        Quantity.set_choosen = 46
    End Sub

    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles mcCafeDrink10PictureBox.Click
        quantitys(9)
        Quantity.Show()
        Quantity.set_choosen = 47
    End Sub

    Private Sub PictureBox11_Click(sender As Object, e As EventArgs) Handles mcCafeDrink11PictureBox.Click
        quantitys(10)
        Quantity.Show()
        Quantity.set_choosen = 48
    End Sub

    Private Sub PictureBox12_Click(sender As Object, e As EventArgs) Handles mcCafeDrink12PictureBox.Click
        quantitys(11)
        Quantity.Show()
        Quantity.set_choosen = 49
    End Sub

    Private Sub PictureBox13_Click(sender As Object, e As EventArgs) Handles mcCafeDrink13PictureBox.Click
        quantitys(12)
        Quantity.Show()
        Quantity.set_choosen = 50
    End Sub
End Class
