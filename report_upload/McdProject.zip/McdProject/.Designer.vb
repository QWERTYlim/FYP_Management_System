﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Quantity
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Quantity))
        Me.mcdLogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.foodDetailPanel = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.numLabel = New System.Windows.Forms.Label()
        Me.minusButton = New System.Windows.Forms.Button()
        Me.plusButton = New System.Windows.Forms.Button()
        Me.wordLabel = New System.Windows.Forms.Label()
        Me.priceLabel = New System.Windows.Forms.Label()
        Me.nameLabel = New System.Windows.Forms.Label()
        Me.SetPictureBox = New System.Windows.Forms.PictureBox()
        Me.detailLabel = New System.Windows.Forms.Label()
        Me.yesButton = New System.Windows.Forms.Button()
        Me.noButton = New System.Windows.Forms.Button()
        CType(Me.mcdLogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.foodDetailPanel.SuspendLayout()
        CType(Me.SetPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mcdLogoPictureBox
        '
        Me.mcdLogoPictureBox.Image = CType(resources.GetObject("mcdLogoPictureBox.Image"), System.Drawing.Image)
        Me.mcdLogoPictureBox.Location = New System.Drawing.Point(759, 42)
        Me.mcdLogoPictureBox.Name = "mcdLogoPictureBox"
        Me.mcdLogoPictureBox.Size = New System.Drawing.Size(389, 195)
        Me.mcdLogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcdLogoPictureBox.TabIndex = 10
        Me.mcdLogoPictureBox.TabStop = False
        '
        'foodDetailPanel
        '
        Me.foodDetailPanel.Controls.Add(Me.Label2)
        Me.foodDetailPanel.Controls.Add(Me.Label1)
        Me.foodDetailPanel.Controls.Add(Me.numLabel)
        Me.foodDetailPanel.Controls.Add(Me.minusButton)
        Me.foodDetailPanel.Controls.Add(Me.plusButton)
        Me.foodDetailPanel.Controls.Add(Me.wordLabel)
        Me.foodDetailPanel.Controls.Add(Me.priceLabel)
        Me.foodDetailPanel.Controls.Add(Me.nameLabel)
        Me.foodDetailPanel.Controls.Add(Me.SetPictureBox)
        Me.foodDetailPanel.Location = New System.Drawing.Point(465, 334)
        Me.foodDetailPanel.Name = "foodDetailPanel"
        Me.foodDetailPanel.Size = New System.Drawing.Size(1709, 507)
        Me.foodDetailPanel.TabIndex = 15
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(732, 155)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 45)
        Me.Label2.TabIndex = 25
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(654, 87)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 45)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = " "
        '
        'numLabel
        '
        Me.numLabel.BackColor = System.Drawing.Color.White
        Me.numLabel.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.numLabel.ForeColor = System.Drawing.Color.Black
        Me.numLabel.Location = New System.Drawing.Point(553, 299)
        Me.numLabel.Name = "numLabel"
        Me.numLabel.Size = New System.Drawing.Size(95, 45)
        Me.numLabel.TabIndex = 23
        Me.numLabel.Text = "1"
        Me.numLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'minusButton
        '
        Me.minusButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.minusButton.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.minusButton.ForeColor = System.Drawing.Color.Silver
        Me.minusButton.Location = New System.Drawing.Point(440, 294)
        Me.minusButton.Name = "minusButton"
        Me.minusButton.Size = New System.Drawing.Size(86, 55)
        Me.minusButton.TabIndex = 22
        Me.minusButton.Text = "-"
        Me.minusButton.UseVisualStyleBackColor = False
        '
        'plusButton
        '
        Me.plusButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.plusButton.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.plusButton.ForeColor = System.Drawing.Color.Silver
        Me.plusButton.Location = New System.Drawing.Point(666, 294)
        Me.plusButton.Name = "plusButton"
        Me.plusButton.Size = New System.Drawing.Size(86, 55)
        Me.plusButton.TabIndex = 21
        Me.plusButton.Text = "+"
        Me.plusButton.UseVisualStyleBackColor = False
        '
        'wordLabel
        '
        Me.wordLabel.AutoSize = True
        Me.wordLabel.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.wordLabel.ForeColor = System.Drawing.Color.White
        Me.wordLabel.Location = New System.Drawing.Point(432, 223)
        Me.wordLabel.Name = "wordLabel"
        Me.wordLabel.Size = New System.Drawing.Size(165, 45)
        Me.wordLabel.TabIndex = 20
        Me.wordLabel.Text = "Quantity:"
        '
        'priceLabel
        '
        Me.priceLabel.AutoSize = True
        Me.priceLabel.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.priceLabel.ForeColor = System.Drawing.Color.White
        Me.priceLabel.Location = New System.Drawing.Point(432, 155)
        Me.priceLabel.Name = "priceLabel"
        Me.priceLabel.Size = New System.Drawing.Size(285, 45)
        Me.priceLabel.TabIndex = 19
        Me.priceLabel.Text = "Price            :  RM"
        '
        'nameLabel
        '
        Me.nameLabel.AutoSize = True
        Me.nameLabel.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.nameLabel.ForeColor = System.Drawing.Color.White
        Me.nameLabel.Location = New System.Drawing.Point(432, 87)
        Me.nameLabel.Name = "nameLabel"
        Me.nameLabel.Size = New System.Drawing.Size(216, 45)
        Me.nameLabel.TabIndex = 18
        Me.nameLabel.Text = "Food Name: "
        '
        'SetPictureBox
        '
        Me.SetPictureBox.Location = New System.Drawing.Point(61, 87)
        Me.SetPictureBox.Name = "SetPictureBox"
        Me.SetPictureBox.Size = New System.Drawing.Size(320, 332)
        Me.SetPictureBox.TabIndex = 15
        Me.SetPictureBox.TabStop = False
        '
        'detailLabel
        '
        Me.detailLabel.AutoSize = True
        Me.detailLabel.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.detailLabel.ForeColor = System.Drawing.Color.White
        Me.detailLabel.Location = New System.Drawing.Point(849, 265)
        Me.detailLabel.Name = "detailLabel"
        Me.detailLabel.Size = New System.Drawing.Size(209, 45)
        Me.detailLabel.TabIndex = 20
        Me.detailLabel.Text = "Order Detail"
        '
        'yesButton
        '
        Me.yesButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.yesButton.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.yesButton.ForeColor = System.Drawing.Color.Silver
        Me.yesButton.Location = New System.Drawing.Point(1130, 893)
        Me.yesButton.Name = "yesButton"
        Me.yesButton.Size = New System.Drawing.Size(311, 55)
        Me.yesButton.TabIndex = 21
        Me.yesButton.Text = "Yes"
        Me.yesButton.UseVisualStyleBackColor = False
        '
        'noButton
        '
        Me.noButton.BackColor = System.Drawing.Color.FromArgb(CType(CType(80, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.noButton.Font = New System.Drawing.Font("Segoe UI", 19.8!, System.Drawing.FontStyle.Bold)
        Me.noButton.ForeColor = System.Drawing.Color.Silver
        Me.noButton.Location = New System.Drawing.Point(465, 893)
        Me.noButton.Name = "noButton"
        Me.noButton.Size = New System.Drawing.Size(311, 55)
        Me.noButton.TabIndex = 22
        Me.noButton.Text = "No"
        Me.noButton.UseVisualStyleBackColor = False
        '
        'Quantity
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1906, 1006)
        Me.Controls.Add(Me.noButton)
        Me.Controls.Add(Me.yesButton)
        Me.Controls.Add(Me.detailLabel)
        Me.Controls.Add(Me.foodDetailPanel)
        Me.Controls.Add(Me.mcdLogoPictureBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Quantity"
        Me.Text = "Form2"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.mcdLogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.foodDetailPanel.ResumeLayout(False)
        Me.foodDetailPanel.PerformLayout()
        CType(Me.SetPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mcdLogoPictureBox As PictureBox
    Friend WithEvents foodDetailPanel As Panel
    Friend WithEvents priceLabel As Label
    Friend WithEvents nameLabel As Label
    Friend WithEvents SetPictureBox As PictureBox
    Friend WithEvents wordLabel As Label
    Friend WithEvents detailLabel As Label
    Friend WithEvents plusButton As Button
    Friend WithEvents numLabel As Label
    Friend WithEvents minusButton As Button
    Friend WithEvents yesButton As Button
    Friend WithEvents noButton As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
