﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Pay
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Pay))
        Me.mcdLogoPictureBox = New System.Windows.Forms.PictureBox()
        Me.text1Label = New System.Windows.Forms.Label()
        Me.text2Label = New System.Windows.Forms.Label()
        Me.totalFeeLabel = New System.Windows.Forms.Label()
        Me.feeLabel = New System.Windows.Forms.Label()
        Me.back = New System.Windows.Forms.Timer(Me.components)
        CType(Me.mcdLogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mcdLogoPictureBox
        '
        Me.mcdLogoPictureBox.Image = CType(resources.GetObject("mcdLogoPictureBox.Image"), System.Drawing.Image)
        Me.mcdLogoPictureBox.Location = New System.Drawing.Point(778, 45)
        Me.mcdLogoPictureBox.Name = "mcdLogoPictureBox"
        Me.mcdLogoPictureBox.Size = New System.Drawing.Size(389, 195)
        Me.mcdLogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.mcdLogoPictureBox.TabIndex = 0
        Me.mcdLogoPictureBox.TabStop = False
        '
        'text1Label
        '
        Me.text1Label.AutoSize = True
        Me.text1Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.text1Label.ForeColor = System.Drawing.SystemColors.Control
        Me.text1Label.Location = New System.Drawing.Point(473, 377)
        Me.text1Label.Name = "text1Label"
        Me.text1Label.Size = New System.Drawing.Size(994, 46)
        Me.text1Label.TabIndex = 11
        Me.text1Label.Text = "Please Take Your Receipt && Go To Counter To Pay "
        '
        'text2Label
        '
        Me.text2Label.AutoSize = True
        Me.text2Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.text2Label.ForeColor = System.Drawing.SystemColors.Control
        Me.text2Label.Location = New System.Drawing.Point(730, 463)
        Me.text2Label.Name = "text2Label"
        Me.text2Label.Size = New System.Drawing.Size(480, 46)
        Me.text2Label.TabIndex = 12
        Me.text2Label.Text = "Thanks For Your Visiting"
        '
        'totalFeeLabel
        '
        Me.totalFeeLabel.AutoSize = True
        Me.totalFeeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalFeeLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.totalFeeLabel.Location = New System.Drawing.Point(753, 297)
        Me.totalFeeLabel.Name = "totalFeeLabel"
        Me.totalFeeLabel.Size = New System.Drawing.Size(328, 46)
        Me.totalFeeLabel.TabIndex = 13
        Me.totalFeeLabel.Text = "Total Fee is RM:"
        '
        'feeLabel
        '
        Me.feeLabel.AutoSize = True
        Me.feeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.feeLabel.ForeColor = System.Drawing.SystemColors.Control
        Me.feeLabel.Location = New System.Drawing.Point(1099, 297)
        Me.feeLabel.Name = "feeLabel"
        Me.feeLabel.Size = New System.Drawing.Size(0, 46)
        Me.feeLabel.TabIndex = 14
        '
        'back
        '
        Me.back.Interval = 3000
        '
        'Pay
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(71, Byte), Integer), CType(CType(17, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1924, 1053)
        Me.Controls.Add(Me.feeLabel)
        Me.Controls.Add(Me.totalFeeLabel)
        Me.Controls.Add(Me.text2Label)
        Me.Controls.Add(Me.text1Label)
        Me.Controls.Add(Me.mcdLogoPictureBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Pay"
        Me.Text = "Form2"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.mcdLogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents mcdLogoPictureBox As PictureBox
    Friend WithEvents text1Label As Label
    Friend WithEvents text2Label As Label
    Friend WithEvents totalFeeLabel As Label
    Friend WithEvents feeLabel As Label
    Friend WithEvents back As Timer
End Class
