﻿Public Class Eatin_takeaway

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)
        eatInPictureBox.BackColor = Color.SeaGreen
    End Sub

    Private Sub PictureBox1_Click_1(sender As Object, e As EventArgs) Handles eatInPictureBox.Click
        menus.takeaway = False
        menus.Show()
        Me.Close()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles takeOutPictureBox.Click
        menus.takeaway = True
        menus.Show()
        Me.Close()
    End Sub
End Class