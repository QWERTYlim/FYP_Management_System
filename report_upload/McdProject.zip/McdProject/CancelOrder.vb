﻿Public Class CancelOrder
    Private Sub noButton_Click(sender As Object, e As EventArgs) Handles noButton.Click
        menus.Show()
        Me.Close()

    End Sub

    Private Sub yesButton_Click(sender As Object, e As EventArgs) Handles yesButton.Click
        menus.Close()
        yesButton.Visible = False
        noButton.Visible = False
        questionLabel.Text = "Thanks For Your Visiting After 5's MACDONALD."
        menus.orderCartLabel.Visible = True
        menus.Label18.Visible = False
        menus.taxLabel.Visible = False
        menus.Label13.Visible = False
        menus.Label17.Visible = False
        menus.TotalPriceLabel.Visible = False
        menus.Label12.Visible = False
        menus.Label15.Visible = False
        menus.TotalItemLabel.Visible = False
        menus.viewOrderLabel.Visible = False
        menus.nextButton.Enabled = False
        menus.cancelsButton.BackColor = Color.FromArgb(247, 94, 100)
        menus.nextButton.BackColor = Color.FromArgb(80, 97, 77)
        For i As Integer = 0 To 90
            menus.set_detail(i, 2) = 0
        Next
        delay.Start()
    End Sub

    Private Sub delay_Tick(sender As Object, e As EventArgs) Handles delay.Tick
        delay.Stop()
        Intro.Show()
        Me.Close()
    End Sub
End Class