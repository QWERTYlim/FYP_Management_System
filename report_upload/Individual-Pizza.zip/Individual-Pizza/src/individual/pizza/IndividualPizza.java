/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package individual.pizza;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author Acer
 */
public class IndividualPizza {

    /**
     * @param args the command line arguments
     */
   public static double price=0;
    public static void main(String[] args) {
        // TODO code application logic here
        
        ImageIcon p = new ImageIcon("pizza.jpg");
        
        
        boolean n= true;
        
        customer cus = new customer("ng","011123456","jalan abc",200);
        
        String name = JOptionPane.showInputDialog("Please enter your name:");
        while(n!=false){
            if(name.isEmpty()){
            name = JOptionPane.showInputDialog("Please enter your name:");
        }else{
                n=false;
            }
        }
        n= true;
        String con = JOptionPane.showInputDialog("Please enter your Contact Number:");
       while(n!=false){
            if(con.isEmpty()){
          con = JOptionPane.showInputDialog("Please enter your Contact Number:");
        }else {
                for(int a=0;a<con.length();a++){
                     if( !Character.isDigit(con.charAt(a))){
                        con = JOptionPane.showInputDialog("Please enter your Contact Number:");
                     }else{
                         n=false;
                     }
                }
               
                         
               
            }
        }
        n= true;
        String add = JOptionPane.showInputDialog("Please enter your address:");
         while(n!=false){
            if(add.isEmpty()){
          add = JOptionPane.showInputDialog("Please enter your address:");
        }else{
                n=false;
            }
        }
       boolean w=true;
        while(w!=false){
            Object[] size = { "Small", "Medium", "Large" };
        String sizes = "Size";
        Object selection = JOptionPane.showInputDialog(null, "Please select size of pizza:","Size", JOptionPane.QUESTION_MESSAGE, null, size, sizes);
        double brr = 0;
        if(selection.toString() =="Small"){
           brr+=8;
        }else if(selection.toString() =="Medium"){
            brr+=10;
        }else if(selection.toString() == "Large"){
            brr+=12;
        }
        
        int top = JOptionPane.showConfirmDialog(null,"Do u want pepperoni?","",JOptionPane.YES_NO_OPTION);
        if(top==0){
            brr+=2;
        }
        
        int top2 = JOptionPane.showConfirmDialog(null,"Do u want sausage?","",JOptionPane.YES_NO_OPTION);
         if(top2==0){
            brr+=2;
        }
         
         int top3 = JOptionPane.showConfirmDialog(null,"Do u want mushroom?","",JOptionPane.YES_NO_OPTION);
        if(top3==0){
            brr+=2;
        }
        
         int coo = JOptionPane.showConfirmDialog(null,"Continue to buy?","",JOptionPane.YES_NO_OPTION);
        if(coo==0){
            
        }else{
            w=false;
        }
        price+=brr;
        }
        
       
        String a;
        if(name.equals(cus.getname())){
            a="Name: "+name+"\nContact Number: "+con+"\nAddress: "+add+"\nTotal: "+price+"\nPoint: "+(cus.getpoint()+price);
        }else{
            a="Name: "+name+"\nContact Number: "+con+"\nAddress: "+add+"\nTotal:"+price;
        }
       
        
        JOptionPane.showMessageDialog(null, a, "Receipt", JOptionPane.QUESTION_MESSAGE,p);
    }
    
}
