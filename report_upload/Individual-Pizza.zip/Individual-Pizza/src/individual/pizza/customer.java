package individual.pizza;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer
 */
public class customer {

    String name;
    String contact;
    String address;
    double point;
    
    public customer(String n,String c,String a,double p){
        name=n;
        contact=c;
        address=a;
        point =p;
    }

    public void setpoint(double amount){
        point=amount;
    }
    
    public double getpoint(){
        return point;
    }
    
    public void setname(String n){
        name = n;
    }
    
    public String getname(){
        return name;
    }
    
    public void setcontact(String c){
        contact = c;
    }
    
    public String getcontact(){
        return contact;
    }
    
    public void setaddress(String a){
        address = a;
    }
    
    public String getaddress(){
        return address;
    }
}
